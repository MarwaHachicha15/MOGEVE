package CoordinatedControlProfile.diagram.edit.helpers;

/**
 * @generated
 */
public class AdaptationActionsEditHelper
		extends
		CoordinatedControlProfile.diagram.edit.helpers.CoordinatedControlBaseEditHelper {
}
