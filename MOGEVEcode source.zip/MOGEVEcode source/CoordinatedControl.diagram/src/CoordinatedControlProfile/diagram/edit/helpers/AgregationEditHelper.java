package CoordinatedControlProfile.diagram.edit.helpers;

/**
 * @generated
 */
public class AgregationEditHelper
		extends
		CoordinatedControlProfile.diagram.edit.helpers.CoordinatedControlBaseEditHelper {
}
