/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Executor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.Executor#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Executor#getAdaction <em>Adaction</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Executor#getReceiver <em>Receiver</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Executor#getProcessor <em>Processor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Executor#getSender <em>Sender</em>}</li>
 * </ul>
 * </p>
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getExecutor()
 * @model
 * @generated
 */
public interface Executor extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getExecutor_Name()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Executor#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Adaction</b></em>' attribute.
	 * The literals are from the enumeration {@link CoordinatedControlProfile.AdaptationActionType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Adaction</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Adaction</em>' attribute.
	 * @see CoordinatedControlProfile.AdaptationActionType
	 * @see #setAdaction(AdaptationActionType)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getExecutor_Adaction()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	AdaptationActionType getAdaction();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Executor#getAdaction <em>Adaction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Adaction</em>' attribute.
	 * @see CoordinatedControlProfile.AdaptationActionType
	 * @see #getAdaction()
	 * @generated
	 */
	void setAdaction(AdaptationActionType value);

	/**
	 * Returns the value of the '<em><b>Receiver</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Receiver</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Receiver</em>' containment reference.
	 * @see #setReceiver(Receiver)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getExecutor_Receiver()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Receiver getReceiver();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Executor#getReceiver <em>Receiver</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Receiver</em>' containment reference.
	 * @see #getReceiver()
	 * @generated
	 */
	void setReceiver(Receiver value);

	/**
	 * Returns the value of the '<em><b>Processor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Processor</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Processor</em>' containment reference.
	 * @see #setProcessor(Processor)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getExecutor_Processor()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Processor getProcessor();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Executor#getProcessor <em>Processor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Processor</em>' containment reference.
	 * @see #getProcessor()
	 * @generated
	 */
	void setProcessor(Processor value);

	/**
	 * Returns the value of the '<em><b>Sender</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sender</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sender</em>' containment reference.
	 * @see #setSender(Sender)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getExecutor_Sender()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Sender getSender();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Executor#getSender <em>Sender</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sender</em>' containment reference.
	 * @see #getSender()
	 * @generated
	 */
	void setSender(Sender value);

} // Executor
