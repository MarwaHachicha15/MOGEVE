/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Coordinated Control</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getManager <em>Manager</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getManagedElement <em>Managed Element</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getProbes <em>Probes</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getContextElement <em>Context Element</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getEffector <em>Effector</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getMonitor <em>Monitor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getAnalyzer <em>Analyzer</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getPlanner <em>Planner</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getExecutor <em>Executor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getIntracmpInteraction <em>Intracmp Interaction</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getReceiver <em>Receiver</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getProcessor <em>Processor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getSender <em>Sender</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getPS <em>PS</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getRP <em>RP</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getMonitoringData <em>Monitoring Data</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getAdaptationActions <em>Adaptation Actions</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getCommands <em>Commands</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getRFC <em>RFC</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getObservedProperty <em>Observed Property</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getSymptom <em>Symptom</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getAgregation <em>Agregation</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getRequiredInterface <em>Required Interface</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getProvidedInterface <em>Provided Interface</em>}</li>
 *   <li>{@link CoordinatedControlProfile.CoordinatedControl#getEventPort <em>Event Port</em>}</li>
 * </ul>
 * </p>
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl()
 * @model
 * @generated
 */
public interface CoordinatedControl extends EObject {
	/**
	 * Returns the value of the '<em><b>Manager</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.Manager}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Manager</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Manager</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_Manager()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<Manager> getManager();

	/**
	 * Returns the value of the '<em><b>Managed Element</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.ManagedElement}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Managed Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Managed Element</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_ManagedElement()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<ManagedElement> getManagedElement();

	/**
	 * Returns the value of the '<em><b>Probes</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.Probes}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Probes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Probes</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_Probes()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<Probes> getProbes();

	/**
	 * Returns the value of the '<em><b>Context Element</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.ContextElement}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Context Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Context Element</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_ContextElement()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<ContextElement> getContextElement();

	/**
	 * Returns the value of the '<em><b>Effector</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.Effector}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Effector</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Effector</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_Effector()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<Effector> getEffector();

	/**
	 * Returns the value of the '<em><b>Monitor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Monitor</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Monitor</em>' containment reference.
	 * @see #setMonitor(Monitor)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_Monitor()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Monitor getMonitor();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.CoordinatedControl#getMonitor <em>Monitor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Monitor</em>' containment reference.
	 * @see #getMonitor()
	 * @generated
	 */
	void setMonitor(Monitor value);

	/**
	 * Returns the value of the '<em><b>Analyzer</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Analyzer</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Analyzer</em>' containment reference.
	 * @see #setAnalyzer(Analyzer)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_Analyzer()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Analyzer getAnalyzer();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.CoordinatedControl#getAnalyzer <em>Analyzer</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Analyzer</em>' containment reference.
	 * @see #getAnalyzer()
	 * @generated
	 */
	void setAnalyzer(Analyzer value);

	/**
	 * Returns the value of the '<em><b>Planner</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Planner</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Planner</em>' containment reference.
	 * @see #setPlanner(Planner)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_Planner()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Planner getPlanner();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.CoordinatedControl#getPlanner <em>Planner</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Planner</em>' containment reference.
	 * @see #getPlanner()
	 * @generated
	 */
	void setPlanner(Planner value);

	/**
	 * Returns the value of the '<em><b>Executor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Executor</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Executor</em>' containment reference.
	 * @see #setExecutor(Executor)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_Executor()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Executor getExecutor();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.CoordinatedControl#getExecutor <em>Executor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Executor</em>' containment reference.
	 * @see #getExecutor()
	 * @generated
	 */
	void setExecutor(Executor value);

	/**
	 * Returns the value of the '<em><b>Intracmp Interaction</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.IntracmpInteraction}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Intracmp Interaction</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Intracmp Interaction</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_IntracmpInteraction()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<IntracmpInteraction> getIntracmpInteraction();

	/**
	 * Returns the value of the '<em><b>Receiver</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Receiver</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Receiver</em>' containment reference.
	 * @see #setReceiver(Receiver)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_Receiver()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Receiver getReceiver();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.CoordinatedControl#getReceiver <em>Receiver</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Receiver</em>' containment reference.
	 * @see #getReceiver()
	 * @generated
	 */
	void setReceiver(Receiver value);

	/**
	 * Returns the value of the '<em><b>Processor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Processor</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Processor</em>' containment reference.
	 * @see #setProcessor(Processor)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_Processor()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Processor getProcessor();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.CoordinatedControl#getProcessor <em>Processor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Processor</em>' containment reference.
	 * @see #getProcessor()
	 * @generated
	 */
	void setProcessor(Processor value);

	/**
	 * Returns the value of the '<em><b>Sender</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sender</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sender</em>' containment reference.
	 * @see #setSender(Sender)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_Sender()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Sender getSender();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.CoordinatedControl#getSender <em>Sender</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sender</em>' containment reference.
	 * @see #getSender()
	 * @generated
	 */
	void setSender(Sender value);

	/**
	 * Returns the value of the '<em><b>PS</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.PS}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>PS</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>PS</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_PS()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<PS> getPS();

	/**
	 * Returns the value of the '<em><b>RP</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.RP}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>RP</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>RP</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_RP()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<RP> getRP();

	/**
	 * Returns the value of the '<em><b>Monitoring Data</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.MonitoringData}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Monitoring Data</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Monitoring Data</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_MonitoringData()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<MonitoringData> getMonitoringData();

	/**
	 * Returns the value of the '<em><b>Adaptation Actions</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.AdaptationActions}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Adaptation Actions</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Adaptation Actions</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_AdaptationActions()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<AdaptationActions> getAdaptationActions();

	/**
	 * Returns the value of the '<em><b>Commands</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.Commands}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Commands</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Commands</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_Commands()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<Commands> getCommands();

	/**
	 * Returns the value of the '<em><b>RFC</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.RFC}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>RFC</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>RFC</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_RFC()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<RFC> getRFC();

	/**
	 * Returns the value of the '<em><b>Observed Property</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.ObservedProperty}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Observed Property</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Observed Property</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_ObservedProperty()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<ObservedProperty> getObservedProperty();

	/**
	 * Returns the value of the '<em><b>Symptom</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.Symptom}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Symptom</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Symptom</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_Symptom()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<Symptom> getSymptom();

	/**
	 * Returns the value of the '<em><b>Agregation</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.Agregation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agregation</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agregation</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_Agregation()
	 * @model containment="true" ordered="false"
	 * @generated
	 */
	EList<Agregation> getAgregation();

	/**
	 * Returns the value of the '<em><b>Required Interface</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.RequiredInterface}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Required Interface</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Required Interface</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_RequiredInterface()
	 * @model containment="true" ordered="false"
	 * @generated
	 */
	EList<RequiredInterface> getRequiredInterface();

	/**
	 * Returns the value of the '<em><b>Provided Interface</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.ProvidedInterface}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Provided Interface</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Provided Interface</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_ProvidedInterface()
	 * @model containment="true" ordered="false"
	 * @generated
	 */
	EList<ProvidedInterface> getProvidedInterface();

	/**
	 * Returns the value of the '<em><b>Event Port</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.EventPort}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event Port</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event Port</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getCoordinatedControl_EventPort()
	 * @model containment="true" ordered="false"
	 * @generated
	 */
	EList<EventPort> getEventPort();

} // CoordinatedControl
