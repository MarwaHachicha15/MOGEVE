/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see CoordinatedControlProfile.CoordinatedControlProfileFactory
 * @model kind="package"
 * @generated
 */
public interface CoordinatedControlProfilePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "CoordinatedControlProfile";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http:///CoordinatedControlProfile.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "CoordinatedControlProfile";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CoordinatedControlProfilePackage eINSTANCE = CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl.init();

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.CoordinatedControlImpl <em>Coordinated Control</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.CoordinatedControlImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getCoordinatedControl()
	 * @generated
	 */
	int COORDINATED_CONTROL = 0;

	/**
	 * The feature id for the '<em><b>Manager</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__MANAGER = 0;

	/**
	 * The feature id for the '<em><b>Managed Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__MANAGED_ELEMENT = 1;

	/**
	 * The feature id for the '<em><b>Probes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__PROBES = 2;

	/**
	 * The feature id for the '<em><b>Context Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__CONTEXT_ELEMENT = 3;

	/**
	 * The feature id for the '<em><b>Effector</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__EFFECTOR = 4;

	/**
	 * The feature id for the '<em><b>Monitor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__MONITOR = 5;

	/**
	 * The feature id for the '<em><b>Analyzer</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__ANALYZER = 6;

	/**
	 * The feature id for the '<em><b>Planner</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__PLANNER = 7;

	/**
	 * The feature id for the '<em><b>Executor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__EXECUTOR = 8;

	/**
	 * The feature id for the '<em><b>Intracmp Interaction</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__INTRACMP_INTERACTION = 9;

	/**
	 * The feature id for the '<em><b>Receiver</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__RECEIVER = 10;

	/**
	 * The feature id for the '<em><b>Processor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__PROCESSOR = 11;

	/**
	 * The feature id for the '<em><b>Sender</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__SENDER = 12;

	/**
	 * The feature id for the '<em><b>PS</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__PS = 13;

	/**
	 * The feature id for the '<em><b>RP</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__RP = 14;

	/**
	 * The feature id for the '<em><b>Monitoring Data</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__MONITORING_DATA = 15;

	/**
	 * The feature id for the '<em><b>Adaptation Actions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__ADAPTATION_ACTIONS = 16;

	/**
	 * The feature id for the '<em><b>Commands</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__COMMANDS = 17;

	/**
	 * The feature id for the '<em><b>RFC</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__RFC = 18;

	/**
	 * The feature id for the '<em><b>Observed Property</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__OBSERVED_PROPERTY = 19;

	/**
	 * The feature id for the '<em><b>Symptom</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__SYMPTOM = 20;

	/**
	 * The feature id for the '<em><b>Agregation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__AGREGATION = 21;

	/**
	 * The feature id for the '<em><b>Required Interface</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__REQUIRED_INTERFACE = 22;

	/**
	 * The feature id for the '<em><b>Provided Interface</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__PROVIDED_INTERFACE = 23;

	/**
	 * The feature id for the '<em><b>Event Port</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL__EVENT_PORT = 24;

	/**
	 * The number of structural features of the '<em>Coordinated Control</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL_FEATURE_COUNT = 25;

	/**
	 * The number of operations of the '<em>Coordinated Control</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDINATED_CONTROL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.ManagerImpl <em>Manager</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.ManagerImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getManager()
	 * @generated
	 */
	int MANAGER = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGER__NAME = 0;

	/**
	 * The feature id for the '<em><b>Monitor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGER__MONITOR = 1;

	/**
	 * The feature id for the '<em><b>Analyzer</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGER__ANALYZER = 2;

	/**
	 * The feature id for the '<em><b>Planner</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGER__PLANNER = 3;

	/**
	 * The feature id for the '<em><b>Executor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGER__EXECUTOR = 4;

	/**
	 * The feature id for the '<em><b>Adaptation Actions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGER__ADAPTATION_ACTIONS = 5;

	/**
	 * The feature id for the '<em><b>RFC</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGER__RFC = 6;

	/**
	 * The feature id for the '<em><b>Symptom</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGER__SYMPTOM = 7;

	/**
	 * The feature id for the '<em><b>Event Port</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGER__EVENT_PORT = 8;

	/**
	 * The feature id for the '<em><b>Agregation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGER__AGREGATION = 9;

	/**
	 * The number of structural features of the '<em>Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGER_FEATURE_COUNT = 10;

	/**
	 * The number of operations of the '<em>Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.MonitorImpl <em>Monitor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.MonitorImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getMonitor()
	 * @generated
	 */
	int MONITOR = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITOR__NAME = 0;

	/**
	 * The feature id for the '<em><b>Data</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITOR__DATA = 1;

	/**
	 * The feature id for the '<em><b>Receiver</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITOR__RECEIVER = 2;

	/**
	 * The feature id for the '<em><b>Processor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITOR__PROCESSOR = 3;

	/**
	 * The feature id for the '<em><b>Sender</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITOR__SENDER = 4;

	/**
	 * The number of structural features of the '<em>Monitor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITOR_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Monitor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.ReceiverImpl <em>Receiver</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.ReceiverImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getReceiver()
	 * @generated
	 */
	int RECEIVER = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECEIVER__NAME = 0;

	/**
	 * The number of structural features of the '<em>Receiver</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECEIVER_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Receiver</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECEIVER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.ProcessorImpl <em>Processor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.ProcessorImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getProcessor()
	 * @generated
	 */
	int PROCESSOR = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESSOR__NAME = 0;

	/**
	 * The number of structural features of the '<em>Processor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESSOR_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Processor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESSOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.SenderImpl <em>Sender</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.SenderImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getSender()
	 * @generated
	 */
	int SENDER = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENDER__NAME = 0;

	/**
	 * The number of structural features of the '<em>Sender</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENDER_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Sender</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENDER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.AnalyzerImpl <em>Analyzer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.AnalyzerImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getAnalyzer()
	 * @generated
	 */
	int ANALYZER = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYZER__NAME = 0;

	/**
	 * The feature id for the '<em><b>Symptom Analysis</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYZER__SYMPTOM_ANALYSIS = 1;

	/**
	 * The feature id for the '<em><b>Thershold MIN</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYZER__THERSHOLD_MIN = 2;

	/**
	 * The feature id for the '<em><b>Thershold MAX</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYZER__THERSHOLD_MAX = 3;

	/**
	 * The feature id for the '<em><b>Receiver</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYZER__RECEIVER = 4;

	/**
	 * The feature id for the '<em><b>Processor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYZER__PROCESSOR = 5;

	/**
	 * The feature id for the '<em><b>Sender</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYZER__SENDER = 6;

	/**
	 * The number of structural features of the '<em>Analyzer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYZER_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>Analyzer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYZER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.PlannerImpl <em>Planner</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.PlannerImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getPlanner()
	 * @generated
	 */
	int PLANNER = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLANNER__NAME = 0;

	/**
	 * The feature id for the '<em><b>RFC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLANNER__RFC = 1;

	/**
	 * The feature id for the '<em><b>Receiver</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLANNER__RECEIVER = 2;

	/**
	 * The feature id for the '<em><b>Processor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLANNER__PROCESSOR = 3;

	/**
	 * The feature id for the '<em><b>Sender</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLANNER__SENDER = 4;

	/**
	 * The number of structural features of the '<em>Planner</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLANNER_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Planner</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLANNER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.ExecutorImpl <em>Executor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.ExecutorImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getExecutor()
	 * @generated
	 */
	int EXECUTOR = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXECUTOR__NAME = 0;

	/**
	 * The feature id for the '<em><b>Adaction</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXECUTOR__ADACTION = 1;

	/**
	 * The feature id for the '<em><b>Receiver</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXECUTOR__RECEIVER = 2;

	/**
	 * The feature id for the '<em><b>Processor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXECUTOR__PROCESSOR = 3;

	/**
	 * The feature id for the '<em><b>Sender</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXECUTOR__SENDER = 4;

	/**
	 * The number of structural features of the '<em>Executor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXECUTOR_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Executor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXECUTOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.ManagedElementImpl <em>Managed Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.ManagedElementImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getManagedElement()
	 * @generated
	 */
	int MANAGED_ELEMENT = 14;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.ProbesImpl <em>Probes</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.ProbesImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getProbes()
	 * @generated
	 */
	int PROBES = 15;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.EffectorImpl <em>Effector</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.EffectorImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getEffector()
	 * @generated
	 */
	int EFFECTOR = 16;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.ContextElementImpl <em>Context Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.ContextElementImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getContextElement()
	 * @generated
	 */
	int CONTEXT_ELEMENT = 17;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.EventPortImpl <em>Event Port</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.EventPortImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getEventPort()
	 * @generated
	 */
	int EVENT_PORT = 12;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.AgregationImpl <em>Agregation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.AgregationImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getAgregation()
	 * @generated
	 */
	int AGREGATION = 13;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.ObservedPropertyImpl <em>Observed Property</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.ObservedPropertyImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getObservedProperty()
	 * @generated
	 */
	int OBSERVED_PROPERTY = 18;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.AdaptationActionsImpl <em>Adaptation Actions</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.AdaptationActionsImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getAdaptationActions()
	 * @generated
	 */
	int ADAPTATION_ACTIONS = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTATION_ACTIONS__NAME = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTATION_ACTIONS__SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Destinataire</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTATION_ACTIONS__DESTINATAIRE = 2;

	/**
	 * The number of structural features of the '<em>Adaptation Actions</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTATION_ACTIONS_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Publish Plan</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTATION_ACTIONS___PUBLISH_PLAN = 0;

	/**
	 * The number of operations of the '<em>Adaptation Actions</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTATION_ACTIONS_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.RFCImpl <em>RFC</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.RFCImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getRFC()
	 * @generated
	 */
	int RFC = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RFC__NAME = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RFC__SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Destinataire</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RFC__DESTINATAIRE = 2;

	/**
	 * The number of structural features of the '<em>RFC</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RFC_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Send RFC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RFC___SEND_RFC = 0;

	/**
	 * The number of operations of the '<em>RFC</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RFC_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.SymptomImpl <em>Symptom</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.SymptomImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getSymptom()
	 * @generated
	 */
	int SYMPTOM = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYMPTOM__NAME = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYMPTOM__SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Destinataire</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYMPTOM__DESTINATAIRE = 2;

	/**
	 * The number of structural features of the '<em>Symptom</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYMPTOM_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Publish Symptom</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYMPTOM___PUBLISH_SYMPTOM = 0;

	/**
	 * The number of operations of the '<em>Symptom</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYMPTOM_OPERATION_COUNT = 1;

	/**
	 * The number of structural features of the '<em>Event Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_PORT_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Event Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_PORT_OPERATION_COUNT = 0;

	/**
	 * The number of structural features of the '<em>Agregation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGREGATION_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Agregation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGREGATION_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGED_ELEMENT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Probes</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGED_ELEMENT__PROBES = 1;

	/**
	 * The feature id for the '<em><b>Effector</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGED_ELEMENT__EFFECTOR = 2;

	/**
	 * The feature id for the '<em><b>Context Element</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGED_ELEMENT__CONTEXT_ELEMENT = 3;

	/**
	 * The feature id for the '<em><b>Event Port</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGED_ELEMENT__EVENT_PORT = 4;

	/**
	 * The feature id for the '<em><b>Agregation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGED_ELEMENT__AGREGATION = 5;

	/**
	 * The feature id for the '<em><b>Observed Property</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGED_ELEMENT__OBSERVED_PROPERTY = 6;

	/**
	 * The feature id for the '<em><b>Manager</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGED_ELEMENT__MANAGER = 7;

	/**
	 * The number of structural features of the '<em>Managed Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGED_ELEMENT_FEATURE_COUNT = 8;

	/**
	 * The number of operations of the '<em>Managed Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANAGED_ELEMENT_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROBES__NAME = 0;

	/**
	 * The feature id for the '<em><b>Probe State</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROBES__PROBE_STATE = 1;

	/**
	 * The number of structural features of the '<em>Probes</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROBES_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Probes</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROBES_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECTOR__NAME = 0;

	/**
	 * The feature id for the '<em><b>Eff State</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECTOR__EFF_STATE = 1;

	/**
	 * The number of structural features of the '<em>Effector</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECTOR_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Effector</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECTOR_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_ELEMENT__NAME = 0;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_ELEMENT__ID = 1;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_ELEMENT__VALUE = 2;

	/**
	 * The number of structural features of the '<em>Context Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_ELEMENT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Context Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_ELEMENT_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBSERVED_PROPERTY__NAME = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBSERVED_PROPERTY__SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Destinataire</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBSERVED_PROPERTY__DESTINATAIRE = 2;

	/**
	 * The number of structural features of the '<em>Observed Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBSERVED_PROPERTY_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Carrying Property</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBSERVED_PROPERTY___CARRYING_PROPERTY = 0;

	/**
	 * The number of operations of the '<em>Observed Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBSERVED_PROPERTY_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.IntracmpInteractionImpl <em>Intracmp Interaction</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.IntracmpInteractionImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getIntracmpInteraction()
	 * @generated
	 */
	int INTRACMP_INTERACTION = 19;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTRACMP_INTERACTION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Source M</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTRACMP_INTERACTION__SOURCE_M = 1;

	/**
	 * The feature id for the '<em><b>Destinataire M</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTRACMP_INTERACTION__DESTINATAIRE_M = 2;

	/**
	 * The feature id for the '<em><b>Source A</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTRACMP_INTERACTION__SOURCE_A = 3;

	/**
	 * The feature id for the '<em><b>Destinataire A</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTRACMP_INTERACTION__DESTINATAIRE_A = 4;

	/**
	 * The feature id for the '<em><b>Source P</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTRACMP_INTERACTION__SOURCE_P = 5;

	/**
	 * The feature id for the '<em><b>Destinataire P</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTRACMP_INTERACTION__DESTINATAIRE_P = 6;

	/**
	 * The feature id for the '<em><b>Source E</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTRACMP_INTERACTION__SOURCE_E = 7;

	/**
	 * The feature id for the '<em><b>Destinataire E</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTRACMP_INTERACTION__DESTINATAIRE_E = 8;

	/**
	 * The number of structural features of the '<em>Intracmp Interaction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTRACMP_INTERACTION_FEATURE_COUNT = 9;

	/**
	 * The number of operations of the '<em>Intracmp Interaction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTRACMP_INTERACTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.PSImpl <em>PS</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.PSImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getPS()
	 * @generated
	 */
	int PS = 20;

	/**
	 * The feature id for the '<em><b>Sender</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PS__SENDER = 0;

	/**
	 * The feature id for the '<em><b>Processor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PS__PROCESSOR = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PS__NAME = 2;

	/**
	 * The number of structural features of the '<em>PS</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PS_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>PS</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.RPImpl <em>RP</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.RPImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getRP()
	 * @generated
	 */
	int RP = 21;

	/**
	 * The feature id for the '<em><b>Receiver</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RP__RECEIVER = 0;

	/**
	 * The feature id for the '<em><b>Processor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RP__PROCESSOR = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RP__NAME = 2;

	/**
	 * The number of structural features of the '<em>RP</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RP_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>RP</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RP_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.MonitoringDataImpl <em>Monitoring Data</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.MonitoringDataImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getMonitoringData()
	 * @generated
	 */
	int MONITORING_DATA = 22;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING_DATA__NAME = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING_DATA__SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Destinataire</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING_DATA__DESTINATAIRE = 2;

	/**
	 * The number of structural features of the '<em>Monitoring Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING_DATA_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Send Monitoring Data</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING_DATA___SEND_MONITORING_DATA = 0;

	/**
	 * The number of operations of the '<em>Monitoring Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING_DATA_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.CommandsImpl <em>Commands</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.CommandsImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getCommands()
	 * @generated
	 */
	int COMMANDS = 23;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMANDS__NAME = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMANDS__SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Destinataire</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMANDS__DESTINATAIRE = 2;

	/**
	 * The number of structural features of the '<em>Commands</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMANDS_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Make Change</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMANDS___MAKE_CHANGE = 0;

	/**
	 * The number of operations of the '<em>Commands</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMANDS_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.RequiredInterfaceImpl <em>Required Interface</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.RequiredInterfaceImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getRequiredInterface()
	 * @generated
	 */
	int REQUIRED_INTERFACE = 24;

	/**
	 * The feature id for the '<em><b>Agregation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIRED_INTERFACE__AGREGATION = 0;

	/**
	 * The feature id for the '<em><b>Event Port</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIRED_INTERFACE__EVENT_PORT = 1;

	/**
	 * The number of structural features of the '<em>Required Interface</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIRED_INTERFACE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Required Interface</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIRED_INTERFACE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.impl.ProvidedInterfaceImpl <em>Provided Interface</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.impl.ProvidedInterfaceImpl
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getProvidedInterface()
	 * @generated
	 */
	int PROVIDED_INTERFACE = 25;

	/**
	 * The feature id for the '<em><b>Agregation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROVIDED_INTERFACE__AGREGATION = 0;

	/**
	 * The feature id for the '<em><b>Event Port</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROVIDED_INTERFACE__EVENT_PORT = 1;

	/**
	 * The number of structural features of the '<em>Provided Interface</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROVIDED_INTERFACE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Provided Interface</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROVIDED_INTERFACE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.SymptomAnalysis <em>Symptom Analysis</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.SymptomAnalysis
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getSymptomAnalysis()
	 * @generated
	 */
	int SYMPTOM_ANALYSIS = 26;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.AdaptationActionType <em>Adaptation Action Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.AdaptationActionType
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getAdaptationActionType()
	 * @generated
	 */
	int ADAPTATION_ACTION_TYPE = 27;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.ProbesState <em>Probes State</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.ProbesState
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getProbesState()
	 * @generated
	 */
	int PROBES_STATE = 28;

	/**
	 * The meta object id for the '{@link CoordinatedControlProfile.Effectorstate <em>Effectorstate</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CoordinatedControlProfile.Effectorstate
	 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getEffectorstate()
	 * @generated
	 */
	int EFFECTORSTATE = 29;


	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.CoordinatedControl <em>Coordinated Control</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Coordinated Control</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl
	 * @generated
	 */
	EClass getCoordinatedControl();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getManager <em>Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Manager</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getManager()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_Manager();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getManagedElement <em>Managed Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Managed Element</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getManagedElement()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_ManagedElement();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getProbes <em>Probes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Probes</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getProbes()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_Probes();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getContextElement <em>Context Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Context Element</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getContextElement()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_ContextElement();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getEffector <em>Effector</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Effector</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getEffector()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_Effector();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.CoordinatedControl#getMonitor <em>Monitor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Monitor</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getMonitor()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_Monitor();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.CoordinatedControl#getAnalyzer <em>Analyzer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Analyzer</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getAnalyzer()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_Analyzer();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.CoordinatedControl#getPlanner <em>Planner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Planner</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getPlanner()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_Planner();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.CoordinatedControl#getExecutor <em>Executor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Executor</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getExecutor()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_Executor();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getIntracmpInteraction <em>Intracmp Interaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Intracmp Interaction</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getIntracmpInteraction()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_IntracmpInteraction();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.CoordinatedControl#getReceiver <em>Receiver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Receiver</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getReceiver()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_Receiver();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.CoordinatedControl#getProcessor <em>Processor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Processor</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getProcessor()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_Processor();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.CoordinatedControl#getSender <em>Sender</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Sender</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getSender()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_Sender();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getPS <em>PS</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>PS</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getPS()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_PS();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getRP <em>RP</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>RP</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getRP()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_RP();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getMonitoringData <em>Monitoring Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Monitoring Data</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getMonitoringData()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_MonitoringData();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getAdaptationActions <em>Adaptation Actions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Adaptation Actions</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getAdaptationActions()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_AdaptationActions();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getCommands <em>Commands</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Commands</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getCommands()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_Commands();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getRFC <em>RFC</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>RFC</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getRFC()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_RFC();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getObservedProperty <em>Observed Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Observed Property</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getObservedProperty()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_ObservedProperty();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getSymptom <em>Symptom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Symptom</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getSymptom()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_Symptom();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getAgregation <em>Agregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Agregation</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getAgregation()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_Agregation();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getRequiredInterface <em>Required Interface</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Required Interface</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getRequiredInterface()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_RequiredInterface();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getProvidedInterface <em>Provided Interface</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Provided Interface</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getProvidedInterface()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_ProvidedInterface();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.CoordinatedControl#getEventPort <em>Event Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Event Port</em>'.
	 * @see CoordinatedControlProfile.CoordinatedControl#getEventPort()
	 * @see #getCoordinatedControl()
	 * @generated
	 */
	EReference getCoordinatedControl_EventPort();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.Manager <em>Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Manager</em>'.
	 * @see CoordinatedControlProfile.Manager
	 * @generated
	 */
	EClass getManager();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Manager#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.Manager#getName()
	 * @see #getManager()
	 * @generated
	 */
	EAttribute getManager_Name();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Manager#getMonitor <em>Monitor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Monitor</em>'.
	 * @see CoordinatedControlProfile.Manager#getMonitor()
	 * @see #getManager()
	 * @generated
	 */
	EReference getManager_Monitor();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Manager#getAnalyzer <em>Analyzer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Analyzer</em>'.
	 * @see CoordinatedControlProfile.Manager#getAnalyzer()
	 * @see #getManager()
	 * @generated
	 */
	EReference getManager_Analyzer();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Manager#getPlanner <em>Planner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Planner</em>'.
	 * @see CoordinatedControlProfile.Manager#getPlanner()
	 * @see #getManager()
	 * @generated
	 */
	EReference getManager_Planner();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Manager#getExecutor <em>Executor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Executor</em>'.
	 * @see CoordinatedControlProfile.Manager#getExecutor()
	 * @see #getManager()
	 * @generated
	 */
	EReference getManager_Executor();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.Manager#getAdaptationActions <em>Adaptation Actions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Adaptation Actions</em>'.
	 * @see CoordinatedControlProfile.Manager#getAdaptationActions()
	 * @see #getManager()
	 * @generated
	 */
	EReference getManager_AdaptationActions();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.Manager#getRFC <em>RFC</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>RFC</em>'.
	 * @see CoordinatedControlProfile.Manager#getRFC()
	 * @see #getManager()
	 * @generated
	 */
	EReference getManager_RFC();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.Manager#getSymptom <em>Symptom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Symptom</em>'.
	 * @see CoordinatedControlProfile.Manager#getSymptom()
	 * @see #getManager()
	 * @generated
	 */
	EReference getManager_Symptom();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.Manager#getEventPort <em>Event Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Event Port</em>'.
	 * @see CoordinatedControlProfile.Manager#getEventPort()
	 * @see #getManager()
	 * @generated
	 */
	EReference getManager_EventPort();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.Manager#getAgregation <em>Agregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Agregation</em>'.
	 * @see CoordinatedControlProfile.Manager#getAgregation()
	 * @see #getManager()
	 * @generated
	 */
	EReference getManager_Agregation();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.Monitor <em>Monitor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Monitor</em>'.
	 * @see CoordinatedControlProfile.Monitor
	 * @generated
	 */
	EClass getMonitor();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Monitor#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.Monitor#getName()
	 * @see #getMonitor()
	 * @generated
	 */
	EAttribute getMonitor_Name();

	/**
	 * Returns the meta object for the attribute list '{@link CoordinatedControlProfile.Monitor#getData <em>Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Data</em>'.
	 * @see CoordinatedControlProfile.Monitor#getData()
	 * @see #getMonitor()
	 * @generated
	 */
	EAttribute getMonitor_Data();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Monitor#getReceiver <em>Receiver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Receiver</em>'.
	 * @see CoordinatedControlProfile.Monitor#getReceiver()
	 * @see #getMonitor()
	 * @generated
	 */
	EReference getMonitor_Receiver();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Monitor#getProcessor <em>Processor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Processor</em>'.
	 * @see CoordinatedControlProfile.Monitor#getProcessor()
	 * @see #getMonitor()
	 * @generated
	 */
	EReference getMonitor_Processor();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Monitor#getSender <em>Sender</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Sender</em>'.
	 * @see CoordinatedControlProfile.Monitor#getSender()
	 * @see #getMonitor()
	 * @generated
	 */
	EReference getMonitor_Sender();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.Receiver <em>Receiver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Receiver</em>'.
	 * @see CoordinatedControlProfile.Receiver
	 * @generated
	 */
	EClass getReceiver();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Receiver#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.Receiver#getName()
	 * @see #getReceiver()
	 * @generated
	 */
	EAttribute getReceiver_Name();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.Processor <em>Processor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Processor</em>'.
	 * @see CoordinatedControlProfile.Processor
	 * @generated
	 */
	EClass getProcessor();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Processor#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.Processor#getName()
	 * @see #getProcessor()
	 * @generated
	 */
	EAttribute getProcessor_Name();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.Sender <em>Sender</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sender</em>'.
	 * @see CoordinatedControlProfile.Sender
	 * @generated
	 */
	EClass getSender();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Sender#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.Sender#getName()
	 * @see #getSender()
	 * @generated
	 */
	EAttribute getSender_Name();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.Analyzer <em>Analyzer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Analyzer</em>'.
	 * @see CoordinatedControlProfile.Analyzer
	 * @generated
	 */
	EClass getAnalyzer();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Analyzer#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.Analyzer#getName()
	 * @see #getAnalyzer()
	 * @generated
	 */
	EAttribute getAnalyzer_Name();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Analyzer#getSymptomAnalysis <em>Symptom Analysis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Symptom Analysis</em>'.
	 * @see CoordinatedControlProfile.Analyzer#getSymptomAnalysis()
	 * @see #getAnalyzer()
	 * @generated
	 */
	EAttribute getAnalyzer_SymptomAnalysis();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Analyzer#getThersholdMIN <em>Thershold MIN</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Thershold MIN</em>'.
	 * @see CoordinatedControlProfile.Analyzer#getThersholdMIN()
	 * @see #getAnalyzer()
	 * @generated
	 */
	EAttribute getAnalyzer_ThersholdMIN();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Analyzer#getThersholdMAX <em>Thershold MAX</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Thershold MAX</em>'.
	 * @see CoordinatedControlProfile.Analyzer#getThersholdMAX()
	 * @see #getAnalyzer()
	 * @generated
	 */
	EAttribute getAnalyzer_ThersholdMAX();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Analyzer#getReceiver <em>Receiver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Receiver</em>'.
	 * @see CoordinatedControlProfile.Analyzer#getReceiver()
	 * @see #getAnalyzer()
	 * @generated
	 */
	EReference getAnalyzer_Receiver();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Analyzer#getProcessor <em>Processor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Processor</em>'.
	 * @see CoordinatedControlProfile.Analyzer#getProcessor()
	 * @see #getAnalyzer()
	 * @generated
	 */
	EReference getAnalyzer_Processor();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Analyzer#getSender <em>Sender</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Sender</em>'.
	 * @see CoordinatedControlProfile.Analyzer#getSender()
	 * @see #getAnalyzer()
	 * @generated
	 */
	EReference getAnalyzer_Sender();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.Planner <em>Planner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Planner</em>'.
	 * @see CoordinatedControlProfile.Planner
	 * @generated
	 */
	EClass getPlanner();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Planner#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.Planner#getName()
	 * @see #getPlanner()
	 * @generated
	 */
	EAttribute getPlanner_Name();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Planner#isRFC <em>RFC</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>RFC</em>'.
	 * @see CoordinatedControlProfile.Planner#isRFC()
	 * @see #getPlanner()
	 * @generated
	 */
	EAttribute getPlanner_RFC();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Planner#getReceiver <em>Receiver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Receiver</em>'.
	 * @see CoordinatedControlProfile.Planner#getReceiver()
	 * @see #getPlanner()
	 * @generated
	 */
	EReference getPlanner_Receiver();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Planner#getProcessor <em>Processor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Processor</em>'.
	 * @see CoordinatedControlProfile.Planner#getProcessor()
	 * @see #getPlanner()
	 * @generated
	 */
	EReference getPlanner_Processor();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Planner#getSender <em>Sender</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Sender</em>'.
	 * @see CoordinatedControlProfile.Planner#getSender()
	 * @see #getPlanner()
	 * @generated
	 */
	EReference getPlanner_Sender();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.Executor <em>Executor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Executor</em>'.
	 * @see CoordinatedControlProfile.Executor
	 * @generated
	 */
	EClass getExecutor();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Executor#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.Executor#getName()
	 * @see #getExecutor()
	 * @generated
	 */
	EAttribute getExecutor_Name();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Executor#getAdaction <em>Adaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Adaction</em>'.
	 * @see CoordinatedControlProfile.Executor#getAdaction()
	 * @see #getExecutor()
	 * @generated
	 */
	EAttribute getExecutor_Adaction();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Executor#getReceiver <em>Receiver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Receiver</em>'.
	 * @see CoordinatedControlProfile.Executor#getReceiver()
	 * @see #getExecutor()
	 * @generated
	 */
	EReference getExecutor_Receiver();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Executor#getProcessor <em>Processor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Processor</em>'.
	 * @see CoordinatedControlProfile.Executor#getProcessor()
	 * @see #getExecutor()
	 * @generated
	 */
	EReference getExecutor_Processor();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.Executor#getSender <em>Sender</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Sender</em>'.
	 * @see CoordinatedControlProfile.Executor#getSender()
	 * @see #getExecutor()
	 * @generated
	 */
	EReference getExecutor_Sender();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.ManagedElement <em>Managed Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Managed Element</em>'.
	 * @see CoordinatedControlProfile.ManagedElement
	 * @generated
	 */
	EClass getManagedElement();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.ManagedElement#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.ManagedElement#getName()
	 * @see #getManagedElement()
	 * @generated
	 */
	EAttribute getManagedElement_Name();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.ManagedElement#getProbes <em>Probes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Probes</em>'.
	 * @see CoordinatedControlProfile.ManagedElement#getProbes()
	 * @see #getManagedElement()
	 * @generated
	 */
	EReference getManagedElement_Probes();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.ManagedElement#getEffector <em>Effector</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Effector</em>'.
	 * @see CoordinatedControlProfile.ManagedElement#getEffector()
	 * @see #getManagedElement()
	 * @generated
	 */
	EReference getManagedElement_Effector();

	/**
	 * Returns the meta object for the containment reference '{@link CoordinatedControlProfile.ManagedElement#getContextElement <em>Context Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Context Element</em>'.
	 * @see CoordinatedControlProfile.ManagedElement#getContextElement()
	 * @see #getManagedElement()
	 * @generated
	 */
	EReference getManagedElement_ContextElement();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.ManagedElement#getEventPort <em>Event Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Event Port</em>'.
	 * @see CoordinatedControlProfile.ManagedElement#getEventPort()
	 * @see #getManagedElement()
	 * @generated
	 */
	EReference getManagedElement_EventPort();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.ManagedElement#getAgregation <em>Agregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Agregation</em>'.
	 * @see CoordinatedControlProfile.ManagedElement#getAgregation()
	 * @see #getManagedElement()
	 * @generated
	 */
	EReference getManagedElement_Agregation();

	/**
	 * Returns the meta object for the containment reference list '{@link CoordinatedControlProfile.ManagedElement#getObservedProperty <em>Observed Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Observed Property</em>'.
	 * @see CoordinatedControlProfile.ManagedElement#getObservedProperty()
	 * @see #getManagedElement()
	 * @generated
	 */
	EReference getManagedElement_ObservedProperty();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.ManagedElement#getManager <em>Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Manager</em>'.
	 * @see CoordinatedControlProfile.ManagedElement#getManager()
	 * @see #getManagedElement()
	 * @generated
	 */
	EReference getManagedElement_Manager();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.Probes <em>Probes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Probes</em>'.
	 * @see CoordinatedControlProfile.Probes
	 * @generated
	 */
	EClass getProbes();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Probes#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.Probes#getName()
	 * @see #getProbes()
	 * @generated
	 */
	EAttribute getProbes_Name();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Probes#getProbeState <em>Probe State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Probe State</em>'.
	 * @see CoordinatedControlProfile.Probes#getProbeState()
	 * @see #getProbes()
	 * @generated
	 */
	EAttribute getProbes_ProbeState();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.Effector <em>Effector</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Effector</em>'.
	 * @see CoordinatedControlProfile.Effector
	 * @generated
	 */
	EClass getEffector();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Effector#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.Effector#getName()
	 * @see #getEffector()
	 * @generated
	 */
	EAttribute getEffector_Name();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Effector#getEffState <em>Eff State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Eff State</em>'.
	 * @see CoordinatedControlProfile.Effector#getEffState()
	 * @see #getEffector()
	 * @generated
	 */
	EAttribute getEffector_EffState();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.ContextElement <em>Context Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Context Element</em>'.
	 * @see CoordinatedControlProfile.ContextElement
	 * @generated
	 */
	EClass getContextElement();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.ContextElement#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.ContextElement#getName()
	 * @see #getContextElement()
	 * @generated
	 */
	EAttribute getContextElement_Name();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.ContextElement#getID <em>ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>ID</em>'.
	 * @see CoordinatedControlProfile.ContextElement#getID()
	 * @see #getContextElement()
	 * @generated
	 */
	EAttribute getContextElement_ID();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.ContextElement#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see CoordinatedControlProfile.ContextElement#getValue()
	 * @see #getContextElement()
	 * @generated
	 */
	EAttribute getContextElement_Value();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.EventPort <em>Event Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Event Port</em>'.
	 * @see CoordinatedControlProfile.EventPort
	 * @generated
	 */
	EClass getEventPort();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.Agregation <em>Agregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Agregation</em>'.
	 * @see CoordinatedControlProfile.Agregation
	 * @generated
	 */
	EClass getAgregation();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.ObservedProperty <em>Observed Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Observed Property</em>'.
	 * @see CoordinatedControlProfile.ObservedProperty
	 * @generated
	 */
	EClass getObservedProperty();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.ObservedProperty#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.ObservedProperty#getName()
	 * @see #getObservedProperty()
	 * @generated
	 */
	EAttribute getObservedProperty_Name();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.ObservedProperty#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see CoordinatedControlProfile.ObservedProperty#getSource()
	 * @see #getObservedProperty()
	 * @generated
	 */
	EReference getObservedProperty_Source();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.ObservedProperty#getDestinataire <em>Destinataire</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Destinataire</em>'.
	 * @see CoordinatedControlProfile.ObservedProperty#getDestinataire()
	 * @see #getObservedProperty()
	 * @generated
	 */
	EReference getObservedProperty_Destinataire();

	/**
	 * Returns the meta object for the '{@link CoordinatedControlProfile.ObservedProperty#CarryingProperty() <em>Carrying Property</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Carrying Property</em>' operation.
	 * @see CoordinatedControlProfile.ObservedProperty#CarryingProperty()
	 * @generated
	 */
	EOperation getObservedProperty__CarryingProperty();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.AdaptationActions <em>Adaptation Actions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Adaptation Actions</em>'.
	 * @see CoordinatedControlProfile.AdaptationActions
	 * @generated
	 */
	EClass getAdaptationActions();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.AdaptationActions#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.AdaptationActions#getName()
	 * @see #getAdaptationActions()
	 * @generated
	 */
	EAttribute getAdaptationActions_Name();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.AdaptationActions#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see CoordinatedControlProfile.AdaptationActions#getSource()
	 * @see #getAdaptationActions()
	 * @generated
	 */
	EReference getAdaptationActions_Source();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.AdaptationActions#getDestinataire <em>Destinataire</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Destinataire</em>'.
	 * @see CoordinatedControlProfile.AdaptationActions#getDestinataire()
	 * @see #getAdaptationActions()
	 * @generated
	 */
	EReference getAdaptationActions_Destinataire();

	/**
	 * Returns the meta object for the '{@link CoordinatedControlProfile.AdaptationActions#PublishPlan() <em>Publish Plan</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Publish Plan</em>' operation.
	 * @see CoordinatedControlProfile.AdaptationActions#PublishPlan()
	 * @generated
	 */
	EOperation getAdaptationActions__PublishPlan();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.RFC <em>RFC</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>RFC</em>'.
	 * @see CoordinatedControlProfile.RFC
	 * @generated
	 */
	EClass getRFC();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.RFC#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.RFC#getName()
	 * @see #getRFC()
	 * @generated
	 */
	EAttribute getRFC_Name();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.RFC#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see CoordinatedControlProfile.RFC#getSource()
	 * @see #getRFC()
	 * @generated
	 */
	EReference getRFC_Source();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.RFC#getDestinataire <em>Destinataire</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Destinataire</em>'.
	 * @see CoordinatedControlProfile.RFC#getDestinataire()
	 * @see #getRFC()
	 * @generated
	 */
	EReference getRFC_Destinataire();

	/**
	 * Returns the meta object for the '{@link CoordinatedControlProfile.RFC#SendRFC() <em>Send RFC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Send RFC</em>' operation.
	 * @see CoordinatedControlProfile.RFC#SendRFC()
	 * @generated
	 */
	EOperation getRFC__SendRFC();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.Symptom <em>Symptom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Symptom</em>'.
	 * @see CoordinatedControlProfile.Symptom
	 * @generated
	 */
	EClass getSymptom();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Symptom#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.Symptom#getName()
	 * @see #getSymptom()
	 * @generated
	 */
	EAttribute getSymptom_Name();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.Symptom#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see CoordinatedControlProfile.Symptom#getSource()
	 * @see #getSymptom()
	 * @generated
	 */
	EReference getSymptom_Source();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.Symptom#getDestinataire <em>Destinataire</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Destinataire</em>'.
	 * @see CoordinatedControlProfile.Symptom#getDestinataire()
	 * @see #getSymptom()
	 * @generated
	 */
	EReference getSymptom_Destinataire();

	/**
	 * Returns the meta object for the '{@link CoordinatedControlProfile.Symptom#PublishSymptom() <em>Publish Symptom</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Publish Symptom</em>' operation.
	 * @see CoordinatedControlProfile.Symptom#PublishSymptom()
	 * @generated
	 */
	EOperation getSymptom__PublishSymptom();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.IntracmpInteraction <em>Intracmp Interaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Intracmp Interaction</em>'.
	 * @see CoordinatedControlProfile.IntracmpInteraction
	 * @generated
	 */
	EClass getIntracmpInteraction();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.IntracmpInteraction#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.IntracmpInteraction#getName()
	 * @see #getIntracmpInteraction()
	 * @generated
	 */
	EAttribute getIntracmpInteraction_Name();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.IntracmpInteraction#getSourceM <em>Source M</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source M</em>'.
	 * @see CoordinatedControlProfile.IntracmpInteraction#getSourceM()
	 * @see #getIntracmpInteraction()
	 * @generated
	 */
	EReference getIntracmpInteraction_SourceM();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.IntracmpInteraction#getDestinataireM <em>Destinataire M</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Destinataire M</em>'.
	 * @see CoordinatedControlProfile.IntracmpInteraction#getDestinataireM()
	 * @see #getIntracmpInteraction()
	 * @generated
	 */
	EReference getIntracmpInteraction_DestinataireM();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.IntracmpInteraction#getSourceA <em>Source A</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source A</em>'.
	 * @see CoordinatedControlProfile.IntracmpInteraction#getSourceA()
	 * @see #getIntracmpInteraction()
	 * @generated
	 */
	EReference getIntracmpInteraction_SourceA();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.IntracmpInteraction#getDestinataireA <em>Destinataire A</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Destinataire A</em>'.
	 * @see CoordinatedControlProfile.IntracmpInteraction#getDestinataireA()
	 * @see #getIntracmpInteraction()
	 * @generated
	 */
	EReference getIntracmpInteraction_DestinataireA();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.IntracmpInteraction#getSourceP <em>Source P</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source P</em>'.
	 * @see CoordinatedControlProfile.IntracmpInteraction#getSourceP()
	 * @see #getIntracmpInteraction()
	 * @generated
	 */
	EReference getIntracmpInteraction_SourceP();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.IntracmpInteraction#getDestinataireP <em>Destinataire P</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Destinataire P</em>'.
	 * @see CoordinatedControlProfile.IntracmpInteraction#getDestinataireP()
	 * @see #getIntracmpInteraction()
	 * @generated
	 */
	EReference getIntracmpInteraction_DestinataireP();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.IntracmpInteraction#getSourceE <em>Source E</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source E</em>'.
	 * @see CoordinatedControlProfile.IntracmpInteraction#getSourceE()
	 * @see #getIntracmpInteraction()
	 * @generated
	 */
	EReference getIntracmpInteraction_SourceE();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.IntracmpInteraction#getDestinataireE <em>Destinataire E</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Destinataire E</em>'.
	 * @see CoordinatedControlProfile.IntracmpInteraction#getDestinataireE()
	 * @see #getIntracmpInteraction()
	 * @generated
	 */
	EReference getIntracmpInteraction_DestinataireE();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.PS <em>PS</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>PS</em>'.
	 * @see CoordinatedControlProfile.PS
	 * @generated
	 */
	EClass getPS();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.PS#getSender <em>Sender</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Sender</em>'.
	 * @see CoordinatedControlProfile.PS#getSender()
	 * @see #getPS()
	 * @generated
	 */
	EReference getPS_Sender();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.PS#getProcessor <em>Processor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Processor</em>'.
	 * @see CoordinatedControlProfile.PS#getProcessor()
	 * @see #getPS()
	 * @generated
	 */
	EReference getPS_Processor();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.PS#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.PS#getName()
	 * @see #getPS()
	 * @generated
	 */
	EAttribute getPS_Name();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.RP <em>RP</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>RP</em>'.
	 * @see CoordinatedControlProfile.RP
	 * @generated
	 */
	EClass getRP();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.RP#getReceiver <em>Receiver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Receiver</em>'.
	 * @see CoordinatedControlProfile.RP#getReceiver()
	 * @see #getRP()
	 * @generated
	 */
	EReference getRP_Receiver();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.RP#getProcessor <em>Processor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Processor</em>'.
	 * @see CoordinatedControlProfile.RP#getProcessor()
	 * @see #getRP()
	 * @generated
	 */
	EReference getRP_Processor();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.RP#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.RP#getName()
	 * @see #getRP()
	 * @generated
	 */
	EAttribute getRP_Name();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.MonitoringData <em>Monitoring Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Monitoring Data</em>'.
	 * @see CoordinatedControlProfile.MonitoringData
	 * @generated
	 */
	EClass getMonitoringData();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.MonitoringData#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.MonitoringData#getName()
	 * @see #getMonitoringData()
	 * @generated
	 */
	EAttribute getMonitoringData_Name();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.MonitoringData#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see CoordinatedControlProfile.MonitoringData#getSource()
	 * @see #getMonitoringData()
	 * @generated
	 */
	EReference getMonitoringData_Source();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.MonitoringData#getDestinataire <em>Destinataire</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Destinataire</em>'.
	 * @see CoordinatedControlProfile.MonitoringData#getDestinataire()
	 * @see #getMonitoringData()
	 * @generated
	 */
	EReference getMonitoringData_Destinataire();

	/**
	 * Returns the meta object for the '{@link CoordinatedControlProfile.MonitoringData#SendMonitoringData() <em>Send Monitoring Data</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Send Monitoring Data</em>' operation.
	 * @see CoordinatedControlProfile.MonitoringData#SendMonitoringData()
	 * @generated
	 */
	EOperation getMonitoringData__SendMonitoringData();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.Commands <em>Commands</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Commands</em>'.
	 * @see CoordinatedControlProfile.Commands
	 * @generated
	 */
	EClass getCommands();

	/**
	 * Returns the meta object for the attribute '{@link CoordinatedControlProfile.Commands#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CoordinatedControlProfile.Commands#getName()
	 * @see #getCommands()
	 * @generated
	 */
	EAttribute getCommands_Name();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.Commands#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see CoordinatedControlProfile.Commands#getSource()
	 * @see #getCommands()
	 * @generated
	 */
	EReference getCommands_Source();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.Commands#getDestinataire <em>Destinataire</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Destinataire</em>'.
	 * @see CoordinatedControlProfile.Commands#getDestinataire()
	 * @see #getCommands()
	 * @generated
	 */
	EReference getCommands_Destinataire();

	/**
	 * Returns the meta object for the '{@link CoordinatedControlProfile.Commands#MakeChange() <em>Make Change</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Make Change</em>' operation.
	 * @see CoordinatedControlProfile.Commands#MakeChange()
	 * @generated
	 */
	EOperation getCommands__MakeChange();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.RequiredInterface <em>Required Interface</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Required Interface</em>'.
	 * @see CoordinatedControlProfile.RequiredInterface
	 * @generated
	 */
	EClass getRequiredInterface();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.RequiredInterface#getAgregation <em>Agregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Agregation</em>'.
	 * @see CoordinatedControlProfile.RequiredInterface#getAgregation()
	 * @see #getRequiredInterface()
	 * @generated
	 */
	EReference getRequiredInterface_Agregation();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.RequiredInterface#getEventPort <em>Event Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Event Port</em>'.
	 * @see CoordinatedControlProfile.RequiredInterface#getEventPort()
	 * @see #getRequiredInterface()
	 * @generated
	 */
	EReference getRequiredInterface_EventPort();

	/**
	 * Returns the meta object for class '{@link CoordinatedControlProfile.ProvidedInterface <em>Provided Interface</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Provided Interface</em>'.
	 * @see CoordinatedControlProfile.ProvidedInterface
	 * @generated
	 */
	EClass getProvidedInterface();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.ProvidedInterface#getAgregation <em>Agregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Agregation</em>'.
	 * @see CoordinatedControlProfile.ProvidedInterface#getAgregation()
	 * @see #getProvidedInterface()
	 * @generated
	 */
	EReference getProvidedInterface_Agregation();

	/**
	 * Returns the meta object for the reference '{@link CoordinatedControlProfile.ProvidedInterface#getEventPort <em>Event Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Event Port</em>'.
	 * @see CoordinatedControlProfile.ProvidedInterface#getEventPort()
	 * @see #getProvidedInterface()
	 * @generated
	 */
	EReference getProvidedInterface_EventPort();

	/**
	 * Returns the meta object for enum '{@link CoordinatedControlProfile.SymptomAnalysis <em>Symptom Analysis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Symptom Analysis</em>'.
	 * @see CoordinatedControlProfile.SymptomAnalysis
	 * @generated
	 */
	EEnum getSymptomAnalysis();

	/**
	 * Returns the meta object for enum '{@link CoordinatedControlProfile.AdaptationActionType <em>Adaptation Action Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Adaptation Action Type</em>'.
	 * @see CoordinatedControlProfile.AdaptationActionType
	 * @generated
	 */
	EEnum getAdaptationActionType();

	/**
	 * Returns the meta object for enum '{@link CoordinatedControlProfile.ProbesState <em>Probes State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Probes State</em>'.
	 * @see CoordinatedControlProfile.ProbesState
	 * @generated
	 */
	EEnum getProbesState();

	/**
	 * Returns the meta object for enum '{@link CoordinatedControlProfile.Effectorstate <em>Effectorstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Effectorstate</em>'.
	 * @see CoordinatedControlProfile.Effectorstate
	 * @generated
	 */
	EEnum getEffectorstate();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	CoordinatedControlProfileFactory getCoordinatedControlProfileFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.CoordinatedControlImpl <em>Coordinated Control</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.CoordinatedControlImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getCoordinatedControl()
		 * @generated
		 */
		EClass COORDINATED_CONTROL = eINSTANCE.getCoordinatedControl();

		/**
		 * The meta object literal for the '<em><b>Manager</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__MANAGER = eINSTANCE.getCoordinatedControl_Manager();

		/**
		 * The meta object literal for the '<em><b>Managed Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__MANAGED_ELEMENT = eINSTANCE.getCoordinatedControl_ManagedElement();

		/**
		 * The meta object literal for the '<em><b>Probes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__PROBES = eINSTANCE.getCoordinatedControl_Probes();

		/**
		 * The meta object literal for the '<em><b>Context Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__CONTEXT_ELEMENT = eINSTANCE.getCoordinatedControl_ContextElement();

		/**
		 * The meta object literal for the '<em><b>Effector</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__EFFECTOR = eINSTANCE.getCoordinatedControl_Effector();

		/**
		 * The meta object literal for the '<em><b>Monitor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__MONITOR = eINSTANCE.getCoordinatedControl_Monitor();

		/**
		 * The meta object literal for the '<em><b>Analyzer</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__ANALYZER = eINSTANCE.getCoordinatedControl_Analyzer();

		/**
		 * The meta object literal for the '<em><b>Planner</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__PLANNER = eINSTANCE.getCoordinatedControl_Planner();

		/**
		 * The meta object literal for the '<em><b>Executor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__EXECUTOR = eINSTANCE.getCoordinatedControl_Executor();

		/**
		 * The meta object literal for the '<em><b>Intracmp Interaction</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__INTRACMP_INTERACTION = eINSTANCE.getCoordinatedControl_IntracmpInteraction();

		/**
		 * The meta object literal for the '<em><b>Receiver</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__RECEIVER = eINSTANCE.getCoordinatedControl_Receiver();

		/**
		 * The meta object literal for the '<em><b>Processor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__PROCESSOR = eINSTANCE.getCoordinatedControl_Processor();

		/**
		 * The meta object literal for the '<em><b>Sender</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__SENDER = eINSTANCE.getCoordinatedControl_Sender();

		/**
		 * The meta object literal for the '<em><b>PS</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__PS = eINSTANCE.getCoordinatedControl_PS();

		/**
		 * The meta object literal for the '<em><b>RP</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__RP = eINSTANCE.getCoordinatedControl_RP();

		/**
		 * The meta object literal for the '<em><b>Monitoring Data</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__MONITORING_DATA = eINSTANCE.getCoordinatedControl_MonitoringData();

		/**
		 * The meta object literal for the '<em><b>Adaptation Actions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__ADAPTATION_ACTIONS = eINSTANCE.getCoordinatedControl_AdaptationActions();

		/**
		 * The meta object literal for the '<em><b>Commands</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__COMMANDS = eINSTANCE.getCoordinatedControl_Commands();

		/**
		 * The meta object literal for the '<em><b>RFC</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__RFC = eINSTANCE.getCoordinatedControl_RFC();

		/**
		 * The meta object literal for the '<em><b>Observed Property</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__OBSERVED_PROPERTY = eINSTANCE.getCoordinatedControl_ObservedProperty();

		/**
		 * The meta object literal for the '<em><b>Symptom</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__SYMPTOM = eINSTANCE.getCoordinatedControl_Symptom();

		/**
		 * The meta object literal for the '<em><b>Agregation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__AGREGATION = eINSTANCE.getCoordinatedControl_Agregation();

		/**
		 * The meta object literal for the '<em><b>Required Interface</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__REQUIRED_INTERFACE = eINSTANCE.getCoordinatedControl_RequiredInterface();

		/**
		 * The meta object literal for the '<em><b>Provided Interface</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__PROVIDED_INTERFACE = eINSTANCE.getCoordinatedControl_ProvidedInterface();

		/**
		 * The meta object literal for the '<em><b>Event Port</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COORDINATED_CONTROL__EVENT_PORT = eINSTANCE.getCoordinatedControl_EventPort();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.ManagerImpl <em>Manager</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.ManagerImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getManager()
		 * @generated
		 */
		EClass MANAGER = eINSTANCE.getManager();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MANAGER__NAME = eINSTANCE.getManager_Name();

		/**
		 * The meta object literal for the '<em><b>Monitor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGER__MONITOR = eINSTANCE.getManager_Monitor();

		/**
		 * The meta object literal for the '<em><b>Analyzer</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGER__ANALYZER = eINSTANCE.getManager_Analyzer();

		/**
		 * The meta object literal for the '<em><b>Planner</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGER__PLANNER = eINSTANCE.getManager_Planner();

		/**
		 * The meta object literal for the '<em><b>Executor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGER__EXECUTOR = eINSTANCE.getManager_Executor();

		/**
		 * The meta object literal for the '<em><b>Adaptation Actions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGER__ADAPTATION_ACTIONS = eINSTANCE.getManager_AdaptationActions();

		/**
		 * The meta object literal for the '<em><b>RFC</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGER__RFC = eINSTANCE.getManager_RFC();

		/**
		 * The meta object literal for the '<em><b>Symptom</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGER__SYMPTOM = eINSTANCE.getManager_Symptom();

		/**
		 * The meta object literal for the '<em><b>Event Port</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGER__EVENT_PORT = eINSTANCE.getManager_EventPort();

		/**
		 * The meta object literal for the '<em><b>Agregation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGER__AGREGATION = eINSTANCE.getManager_Agregation();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.MonitorImpl <em>Monitor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.MonitorImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getMonitor()
		 * @generated
		 */
		EClass MONITOR = eINSTANCE.getMonitor();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MONITOR__NAME = eINSTANCE.getMonitor_Name();

		/**
		 * The meta object literal for the '<em><b>Data</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MONITOR__DATA = eINSTANCE.getMonitor_Data();

		/**
		 * The meta object literal for the '<em><b>Receiver</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MONITOR__RECEIVER = eINSTANCE.getMonitor_Receiver();

		/**
		 * The meta object literal for the '<em><b>Processor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MONITOR__PROCESSOR = eINSTANCE.getMonitor_Processor();

		/**
		 * The meta object literal for the '<em><b>Sender</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MONITOR__SENDER = eINSTANCE.getMonitor_Sender();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.ReceiverImpl <em>Receiver</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.ReceiverImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getReceiver()
		 * @generated
		 */
		EClass RECEIVER = eINSTANCE.getReceiver();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RECEIVER__NAME = eINSTANCE.getReceiver_Name();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.ProcessorImpl <em>Processor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.ProcessorImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getProcessor()
		 * @generated
		 */
		EClass PROCESSOR = eINSTANCE.getProcessor();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROCESSOR__NAME = eINSTANCE.getProcessor_Name();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.SenderImpl <em>Sender</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.SenderImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getSender()
		 * @generated
		 */
		EClass SENDER = eINSTANCE.getSender();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENDER__NAME = eINSTANCE.getSender_Name();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.AnalyzerImpl <em>Analyzer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.AnalyzerImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getAnalyzer()
		 * @generated
		 */
		EClass ANALYZER = eINSTANCE.getAnalyzer();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYZER__NAME = eINSTANCE.getAnalyzer_Name();

		/**
		 * The meta object literal for the '<em><b>Symptom Analysis</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYZER__SYMPTOM_ANALYSIS = eINSTANCE.getAnalyzer_SymptomAnalysis();

		/**
		 * The meta object literal for the '<em><b>Thershold MIN</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYZER__THERSHOLD_MIN = eINSTANCE.getAnalyzer_ThersholdMIN();

		/**
		 * The meta object literal for the '<em><b>Thershold MAX</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYZER__THERSHOLD_MAX = eINSTANCE.getAnalyzer_ThersholdMAX();

		/**
		 * The meta object literal for the '<em><b>Receiver</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ANALYZER__RECEIVER = eINSTANCE.getAnalyzer_Receiver();

		/**
		 * The meta object literal for the '<em><b>Processor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ANALYZER__PROCESSOR = eINSTANCE.getAnalyzer_Processor();

		/**
		 * The meta object literal for the '<em><b>Sender</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ANALYZER__SENDER = eINSTANCE.getAnalyzer_Sender();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.PlannerImpl <em>Planner</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.PlannerImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getPlanner()
		 * @generated
		 */
		EClass PLANNER = eINSTANCE.getPlanner();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PLANNER__NAME = eINSTANCE.getPlanner_Name();

		/**
		 * The meta object literal for the '<em><b>RFC</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PLANNER__RFC = eINSTANCE.getPlanner_RFC();

		/**
		 * The meta object literal for the '<em><b>Receiver</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLANNER__RECEIVER = eINSTANCE.getPlanner_Receiver();

		/**
		 * The meta object literal for the '<em><b>Processor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLANNER__PROCESSOR = eINSTANCE.getPlanner_Processor();

		/**
		 * The meta object literal for the '<em><b>Sender</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLANNER__SENDER = eINSTANCE.getPlanner_Sender();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.ExecutorImpl <em>Executor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.ExecutorImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getExecutor()
		 * @generated
		 */
		EClass EXECUTOR = eINSTANCE.getExecutor();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXECUTOR__NAME = eINSTANCE.getExecutor_Name();

		/**
		 * The meta object literal for the '<em><b>Adaction</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXECUTOR__ADACTION = eINSTANCE.getExecutor_Adaction();

		/**
		 * The meta object literal for the '<em><b>Receiver</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EXECUTOR__RECEIVER = eINSTANCE.getExecutor_Receiver();

		/**
		 * The meta object literal for the '<em><b>Processor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EXECUTOR__PROCESSOR = eINSTANCE.getExecutor_Processor();

		/**
		 * The meta object literal for the '<em><b>Sender</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EXECUTOR__SENDER = eINSTANCE.getExecutor_Sender();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.ManagedElementImpl <em>Managed Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.ManagedElementImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getManagedElement()
		 * @generated
		 */
		EClass MANAGED_ELEMENT = eINSTANCE.getManagedElement();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MANAGED_ELEMENT__NAME = eINSTANCE.getManagedElement_Name();

		/**
		 * The meta object literal for the '<em><b>Probes</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGED_ELEMENT__PROBES = eINSTANCE.getManagedElement_Probes();

		/**
		 * The meta object literal for the '<em><b>Effector</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGED_ELEMENT__EFFECTOR = eINSTANCE.getManagedElement_Effector();

		/**
		 * The meta object literal for the '<em><b>Context Element</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGED_ELEMENT__CONTEXT_ELEMENT = eINSTANCE.getManagedElement_ContextElement();

		/**
		 * The meta object literal for the '<em><b>Event Port</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGED_ELEMENT__EVENT_PORT = eINSTANCE.getManagedElement_EventPort();

		/**
		 * The meta object literal for the '<em><b>Agregation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGED_ELEMENT__AGREGATION = eINSTANCE.getManagedElement_Agregation();

		/**
		 * The meta object literal for the '<em><b>Observed Property</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGED_ELEMENT__OBSERVED_PROPERTY = eINSTANCE.getManagedElement_ObservedProperty();

		/**
		 * The meta object literal for the '<em><b>Manager</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MANAGED_ELEMENT__MANAGER = eINSTANCE.getManagedElement_Manager();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.ProbesImpl <em>Probes</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.ProbesImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getProbes()
		 * @generated
		 */
		EClass PROBES = eINSTANCE.getProbes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROBES__NAME = eINSTANCE.getProbes_Name();

		/**
		 * The meta object literal for the '<em><b>Probe State</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROBES__PROBE_STATE = eINSTANCE.getProbes_ProbeState();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.EffectorImpl <em>Effector</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.EffectorImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getEffector()
		 * @generated
		 */
		EClass EFFECTOR = eINSTANCE.getEffector();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EFFECTOR__NAME = eINSTANCE.getEffector_Name();

		/**
		 * The meta object literal for the '<em><b>Eff State</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EFFECTOR__EFF_STATE = eINSTANCE.getEffector_EffState();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.ContextElementImpl <em>Context Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.ContextElementImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getContextElement()
		 * @generated
		 */
		EClass CONTEXT_ELEMENT = eINSTANCE.getContextElement();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTEXT_ELEMENT__NAME = eINSTANCE.getContextElement_Name();

		/**
		 * The meta object literal for the '<em><b>ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTEXT_ELEMENT__ID = eINSTANCE.getContextElement_ID();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTEXT_ELEMENT__VALUE = eINSTANCE.getContextElement_Value();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.EventPortImpl <em>Event Port</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.EventPortImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getEventPort()
		 * @generated
		 */
		EClass EVENT_PORT = eINSTANCE.getEventPort();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.AgregationImpl <em>Agregation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.AgregationImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getAgregation()
		 * @generated
		 */
		EClass AGREGATION = eINSTANCE.getAgregation();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.ObservedPropertyImpl <em>Observed Property</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.ObservedPropertyImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getObservedProperty()
		 * @generated
		 */
		EClass OBSERVED_PROPERTY = eINSTANCE.getObservedProperty();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBSERVED_PROPERTY__NAME = eINSTANCE.getObservedProperty_Name();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBSERVED_PROPERTY__SOURCE = eINSTANCE.getObservedProperty_Source();

		/**
		 * The meta object literal for the '<em><b>Destinataire</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBSERVED_PROPERTY__DESTINATAIRE = eINSTANCE.getObservedProperty_Destinataire();

		/**
		 * The meta object literal for the '<em><b>Carrying Property</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation OBSERVED_PROPERTY___CARRYING_PROPERTY = eINSTANCE.getObservedProperty__CarryingProperty();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.AdaptationActionsImpl <em>Adaptation Actions</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.AdaptationActionsImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getAdaptationActions()
		 * @generated
		 */
		EClass ADAPTATION_ACTIONS = eINSTANCE.getAdaptationActions();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ADAPTATION_ACTIONS__NAME = eINSTANCE.getAdaptationActions_Name();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADAPTATION_ACTIONS__SOURCE = eINSTANCE.getAdaptationActions_Source();

		/**
		 * The meta object literal for the '<em><b>Destinataire</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADAPTATION_ACTIONS__DESTINATAIRE = eINSTANCE.getAdaptationActions_Destinataire();

		/**
		 * The meta object literal for the '<em><b>Publish Plan</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ADAPTATION_ACTIONS___PUBLISH_PLAN = eINSTANCE.getAdaptationActions__PublishPlan();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.RFCImpl <em>RFC</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.RFCImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getRFC()
		 * @generated
		 */
		EClass RFC = eINSTANCE.getRFC();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RFC__NAME = eINSTANCE.getRFC_Name();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RFC__SOURCE = eINSTANCE.getRFC_Source();

		/**
		 * The meta object literal for the '<em><b>Destinataire</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RFC__DESTINATAIRE = eINSTANCE.getRFC_Destinataire();

		/**
		 * The meta object literal for the '<em><b>Send RFC</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation RFC___SEND_RFC = eINSTANCE.getRFC__SendRFC();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.SymptomImpl <em>Symptom</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.SymptomImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getSymptom()
		 * @generated
		 */
		EClass SYMPTOM = eINSTANCE.getSymptom();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYMPTOM__NAME = eINSTANCE.getSymptom_Name();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYMPTOM__SOURCE = eINSTANCE.getSymptom_Source();

		/**
		 * The meta object literal for the '<em><b>Destinataire</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYMPTOM__DESTINATAIRE = eINSTANCE.getSymptom_Destinataire();

		/**
		 * The meta object literal for the '<em><b>Publish Symptom</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SYMPTOM___PUBLISH_SYMPTOM = eINSTANCE.getSymptom__PublishSymptom();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.IntracmpInteractionImpl <em>Intracmp Interaction</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.IntracmpInteractionImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getIntracmpInteraction()
		 * @generated
		 */
		EClass INTRACMP_INTERACTION = eINSTANCE.getIntracmpInteraction();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTRACMP_INTERACTION__NAME = eINSTANCE.getIntracmpInteraction_Name();

		/**
		 * The meta object literal for the '<em><b>Source M</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTRACMP_INTERACTION__SOURCE_M = eINSTANCE.getIntracmpInteraction_SourceM();

		/**
		 * The meta object literal for the '<em><b>Destinataire M</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTRACMP_INTERACTION__DESTINATAIRE_M = eINSTANCE.getIntracmpInteraction_DestinataireM();

		/**
		 * The meta object literal for the '<em><b>Source A</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTRACMP_INTERACTION__SOURCE_A = eINSTANCE.getIntracmpInteraction_SourceA();

		/**
		 * The meta object literal for the '<em><b>Destinataire A</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTRACMP_INTERACTION__DESTINATAIRE_A = eINSTANCE.getIntracmpInteraction_DestinataireA();

		/**
		 * The meta object literal for the '<em><b>Source P</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTRACMP_INTERACTION__SOURCE_P = eINSTANCE.getIntracmpInteraction_SourceP();

		/**
		 * The meta object literal for the '<em><b>Destinataire P</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTRACMP_INTERACTION__DESTINATAIRE_P = eINSTANCE.getIntracmpInteraction_DestinataireP();

		/**
		 * The meta object literal for the '<em><b>Source E</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTRACMP_INTERACTION__SOURCE_E = eINSTANCE.getIntracmpInteraction_SourceE();

		/**
		 * The meta object literal for the '<em><b>Destinataire E</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTRACMP_INTERACTION__DESTINATAIRE_E = eINSTANCE.getIntracmpInteraction_DestinataireE();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.PSImpl <em>PS</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.PSImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getPS()
		 * @generated
		 */
		EClass PS = eINSTANCE.getPS();

		/**
		 * The meta object literal for the '<em><b>Sender</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PS__SENDER = eINSTANCE.getPS_Sender();

		/**
		 * The meta object literal for the '<em><b>Processor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PS__PROCESSOR = eINSTANCE.getPS_Processor();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PS__NAME = eINSTANCE.getPS_Name();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.RPImpl <em>RP</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.RPImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getRP()
		 * @generated
		 */
		EClass RP = eINSTANCE.getRP();

		/**
		 * The meta object literal for the '<em><b>Receiver</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RP__RECEIVER = eINSTANCE.getRP_Receiver();

		/**
		 * The meta object literal for the '<em><b>Processor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RP__PROCESSOR = eINSTANCE.getRP_Processor();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RP__NAME = eINSTANCE.getRP_Name();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.MonitoringDataImpl <em>Monitoring Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.MonitoringDataImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getMonitoringData()
		 * @generated
		 */
		EClass MONITORING_DATA = eINSTANCE.getMonitoringData();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MONITORING_DATA__NAME = eINSTANCE.getMonitoringData_Name();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MONITORING_DATA__SOURCE = eINSTANCE.getMonitoringData_Source();

		/**
		 * The meta object literal for the '<em><b>Destinataire</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MONITORING_DATA__DESTINATAIRE = eINSTANCE.getMonitoringData_Destinataire();

		/**
		 * The meta object literal for the '<em><b>Send Monitoring Data</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation MONITORING_DATA___SEND_MONITORING_DATA = eINSTANCE.getMonitoringData__SendMonitoringData();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.CommandsImpl <em>Commands</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.CommandsImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getCommands()
		 * @generated
		 */
		EClass COMMANDS = eINSTANCE.getCommands();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMMANDS__NAME = eINSTANCE.getCommands_Name();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMMANDS__SOURCE = eINSTANCE.getCommands_Source();

		/**
		 * The meta object literal for the '<em><b>Destinataire</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMMANDS__DESTINATAIRE = eINSTANCE.getCommands_Destinataire();

		/**
		 * The meta object literal for the '<em><b>Make Change</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation COMMANDS___MAKE_CHANGE = eINSTANCE.getCommands__MakeChange();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.RequiredInterfaceImpl <em>Required Interface</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.RequiredInterfaceImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getRequiredInterface()
		 * @generated
		 */
		EClass REQUIRED_INTERFACE = eINSTANCE.getRequiredInterface();

		/**
		 * The meta object literal for the '<em><b>Agregation</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REQUIRED_INTERFACE__AGREGATION = eINSTANCE.getRequiredInterface_Agregation();

		/**
		 * The meta object literal for the '<em><b>Event Port</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REQUIRED_INTERFACE__EVENT_PORT = eINSTANCE.getRequiredInterface_EventPort();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.impl.ProvidedInterfaceImpl <em>Provided Interface</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.impl.ProvidedInterfaceImpl
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getProvidedInterface()
		 * @generated
		 */
		EClass PROVIDED_INTERFACE = eINSTANCE.getProvidedInterface();

		/**
		 * The meta object literal for the '<em><b>Agregation</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROVIDED_INTERFACE__AGREGATION = eINSTANCE.getProvidedInterface_Agregation();

		/**
		 * The meta object literal for the '<em><b>Event Port</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROVIDED_INTERFACE__EVENT_PORT = eINSTANCE.getProvidedInterface_EventPort();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.SymptomAnalysis <em>Symptom Analysis</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.SymptomAnalysis
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getSymptomAnalysis()
		 * @generated
		 */
		EEnum SYMPTOM_ANALYSIS = eINSTANCE.getSymptomAnalysis();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.AdaptationActionType <em>Adaptation Action Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.AdaptationActionType
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getAdaptationActionType()
		 * @generated
		 */
		EEnum ADAPTATION_ACTION_TYPE = eINSTANCE.getAdaptationActionType();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.ProbesState <em>Probes State</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.ProbesState
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getProbesState()
		 * @generated
		 */
		EEnum PROBES_STATE = eINSTANCE.getProbesState();

		/**
		 * The meta object literal for the '{@link CoordinatedControlProfile.Effectorstate <em>Effectorstate</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CoordinatedControlProfile.Effectorstate
		 * @see CoordinatedControlProfile.impl.CoordinatedControlProfilePackageImpl#getEffectorstate()
		 * @generated
		 */
		EEnum EFFECTORSTATE = eINSTANCE.getEffectorstate();

	}

} //CoordinatedControlProfilePackage
