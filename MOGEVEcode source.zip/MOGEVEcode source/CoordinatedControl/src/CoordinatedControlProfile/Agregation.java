/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Agregation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getAgregation()
 * @model
 * @generated
 */
public interface Agregation extends EObject {
} // Agregation
