/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Analyzer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.Analyzer#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Analyzer#getSymptomAnalysis <em>Symptom Analysis</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Analyzer#getThersholdMIN <em>Thershold MIN</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Analyzer#getThersholdMAX <em>Thershold MAX</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Analyzer#getReceiver <em>Receiver</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Analyzer#getProcessor <em>Processor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Analyzer#getSender <em>Sender</em>}</li>
 * </ul>
 * </p>
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getAnalyzer()
 * @model
 * @generated
 */
public interface Analyzer extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getAnalyzer_Name()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Analyzer#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Symptom Analysis</b></em>' attribute.
	 * The literals are from the enumeration {@link CoordinatedControlProfile.SymptomAnalysis}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Symptom Analysis</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Symptom Analysis</em>' attribute.
	 * @see CoordinatedControlProfile.SymptomAnalysis
	 * @see #setSymptomAnalysis(SymptomAnalysis)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getAnalyzer_SymptomAnalysis()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	SymptomAnalysis getSymptomAnalysis();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Analyzer#getSymptomAnalysis <em>Symptom Analysis</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Symptom Analysis</em>' attribute.
	 * @see CoordinatedControlProfile.SymptomAnalysis
	 * @see #getSymptomAnalysis()
	 * @generated
	 */
	void setSymptomAnalysis(SymptomAnalysis value);

	/**
	 * Returns the value of the '<em><b>Thershold MIN</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Thershold MIN</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Thershold MIN</em>' attribute.
	 * @see #setThersholdMIN(int)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getAnalyzer_ThersholdMIN()
	 * @model dataType="org.eclipse.uml2.types.Integer" required="true" ordered="false"
	 * @generated
	 */
	int getThersholdMIN();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Analyzer#getThersholdMIN <em>Thershold MIN</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Thershold MIN</em>' attribute.
	 * @see #getThersholdMIN()
	 * @generated
	 */
	void setThersholdMIN(int value);

	/**
	 * Returns the value of the '<em><b>Thershold MAX</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Thershold MAX</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Thershold MAX</em>' attribute.
	 * @see #setThersholdMAX(int)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getAnalyzer_ThersholdMAX()
	 * @model dataType="org.eclipse.uml2.types.Integer" required="true" ordered="false"
	 * @generated
	 */
	int getThersholdMAX();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Analyzer#getThersholdMAX <em>Thershold MAX</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Thershold MAX</em>' attribute.
	 * @see #getThersholdMAX()
	 * @generated
	 */
	void setThersholdMAX(int value);

	/**
	 * Returns the value of the '<em><b>Receiver</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Receiver</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Receiver</em>' containment reference.
	 * @see #setReceiver(Receiver)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getAnalyzer_Receiver()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Receiver getReceiver();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Analyzer#getReceiver <em>Receiver</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Receiver</em>' containment reference.
	 * @see #getReceiver()
	 * @generated
	 */
	void setReceiver(Receiver value);

	/**
	 * Returns the value of the '<em><b>Processor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Processor</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Processor</em>' containment reference.
	 * @see #setProcessor(Processor)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getAnalyzer_Processor()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Processor getProcessor();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Analyzer#getProcessor <em>Processor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Processor</em>' containment reference.
	 * @see #getProcessor()
	 * @generated
	 */
	void setProcessor(Processor value);

	/**
	 * Returns the value of the '<em><b>Sender</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sender</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sender</em>' containment reference.
	 * @see #setSender(Sender)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getAnalyzer_Sender()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Sender getSender();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Analyzer#getSender <em>Sender</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sender</em>' containment reference.
	 * @see #getSender()
	 * @generated
	 */
	void setSender(Sender value);

} // Analyzer
