/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Monitor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.Monitor#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Monitor#getData <em>Data</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Monitor#getReceiver <em>Receiver</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Monitor#getProcessor <em>Processor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Monitor#getSender <em>Sender</em>}</li>
 * </ul>
 * </p>
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getMonitor()
 * @model
 * @generated
 */
public interface Monitor extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getMonitor_Name()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Monitor#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Data</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Data</em>' attribute list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data</em>' attribute list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getMonitor_Data()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	EList<String> getData();

	/**
	 * Returns the value of the '<em><b>Receiver</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Receiver</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Receiver</em>' containment reference.
	 * @see #setReceiver(Receiver)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getMonitor_Receiver()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Receiver getReceiver();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Monitor#getReceiver <em>Receiver</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Receiver</em>' containment reference.
	 * @see #getReceiver()
	 * @generated
	 */
	void setReceiver(Receiver value);

	/**
	 * Returns the value of the '<em><b>Processor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Processor</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Processor</em>' containment reference.
	 * @see #setProcessor(Processor)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getMonitor_Processor()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Processor getProcessor();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Monitor#getProcessor <em>Processor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Processor</em>' containment reference.
	 * @see #getProcessor()
	 * @generated
	 */
	void setProcessor(Processor value);

	/**
	 * Returns the value of the '<em><b>Sender</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sender</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sender</em>' containment reference.
	 * @see #setSender(Sender)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getMonitor_Sender()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Sender getSender();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Monitor#getSender <em>Sender</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sender</em>' containment reference.
	 * @see #getSender()
	 * @generated
	 */
	void setSender(Sender value);

} // Monitor
