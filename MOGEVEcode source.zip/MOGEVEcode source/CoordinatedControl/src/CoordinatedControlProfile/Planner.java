/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Planner</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.Planner#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Planner#isRFC <em>RFC</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Planner#getReceiver <em>Receiver</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Planner#getProcessor <em>Processor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Planner#getSender <em>Sender</em>}</li>
 * </ul>
 * </p>
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getPlanner()
 * @model
 * @generated
 */
public interface Planner extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getPlanner_Name()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Planner#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>RFC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>RFC</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>RFC</em>' attribute.
	 * @see #setRFC(boolean)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getPlanner_RFC()
	 * @model dataType="org.eclipse.uml2.types.Boolean" required="true" ordered="false"
	 * @generated
	 */
	boolean isRFC();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Planner#isRFC <em>RFC</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>RFC</em>' attribute.
	 * @see #isRFC()
	 * @generated
	 */
	void setRFC(boolean value);

	/**
	 * Returns the value of the '<em><b>Receiver</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Receiver</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Receiver</em>' containment reference.
	 * @see #setReceiver(Receiver)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getPlanner_Receiver()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Receiver getReceiver();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Planner#getReceiver <em>Receiver</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Receiver</em>' containment reference.
	 * @see #getReceiver()
	 * @generated
	 */
	void setReceiver(Receiver value);

	/**
	 * Returns the value of the '<em><b>Processor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Processor</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Processor</em>' containment reference.
	 * @see #setProcessor(Processor)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getPlanner_Processor()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Processor getProcessor();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Planner#getProcessor <em>Processor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Processor</em>' containment reference.
	 * @see #getProcessor()
	 * @generated
	 */
	void setProcessor(Processor value);

	/**
	 * Returns the value of the '<em><b>Sender</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sender</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sender</em>' containment reference.
	 * @see #setSender(Sender)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getPlanner_Sender()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Sender getSender();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Planner#getSender <em>Sender</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sender</em>' containment reference.
	 * @see #getSender()
	 * @generated
	 */
	void setSender(Sender value);

} // Planner
