/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Effector</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.Effector#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Effector#getEffState <em>Eff State</em>}</li>
 * </ul>
 * </p>
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getEffector()
 * @model
 * @generated
 */
public interface Effector extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getEffector_Name()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Effector#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Eff State</b></em>' attribute.
	 * The literals are from the enumeration {@link CoordinatedControlProfile.Effectorstate}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Eff State</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Eff State</em>' attribute.
	 * @see CoordinatedControlProfile.Effectorstate
	 * @see #setEffState(Effectorstate)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getEffector_EffState()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Effectorstate getEffState();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Effector#getEffState <em>Eff State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Eff State</em>' attribute.
	 * @see CoordinatedControlProfile.Effectorstate
	 * @see #getEffState()
	 * @generated
	 */
	void setEffState(Effectorstate value);

} // Effector
