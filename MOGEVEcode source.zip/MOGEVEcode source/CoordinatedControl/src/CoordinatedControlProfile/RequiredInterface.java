/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Required Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.RequiredInterface#getAgregation <em>Agregation</em>}</li>
 *   <li>{@link CoordinatedControlProfile.RequiredInterface#getEventPort <em>Event Port</em>}</li>
 * </ul>
 * </p>
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getRequiredInterface()
 * @model
 * @generated
 */
public interface RequiredInterface extends EObject {
	/**
	 * Returns the value of the '<em><b>Agregation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agregation</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agregation</em>' reference.
	 * @see #setAgregation(Agregation)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getRequiredInterface_Agregation()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Agregation getAgregation();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.RequiredInterface#getAgregation <em>Agregation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Agregation</em>' reference.
	 * @see #getAgregation()
	 * @generated
	 */
	void setAgregation(Agregation value);

	/**
	 * Returns the value of the '<em><b>Event Port</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event Port</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event Port</em>' reference.
	 * @see #setEventPort(EventPort)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getRequiredInterface_EventPort()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	EventPort getEventPort();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.RequiredInterface#getEventPort <em>Event Port</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Event Port</em>' reference.
	 * @see #getEventPort()
	 * @generated
	 */
	void setEventPort(EventPort value);

} // RequiredInterface
