/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Adaptation Actions</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.AdaptationActions#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.AdaptationActions#getSource <em>Source</em>}</li>
 *   <li>{@link CoordinatedControlProfile.AdaptationActions#getDestinataire <em>Destinataire</em>}</li>
 * </ul>
 * </p>
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getAdaptationActions()
 * @model
 * @generated
 */
public interface AdaptationActions extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getAdaptationActions_Name()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.AdaptationActions#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(Sender)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getAdaptationActions_Source()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Sender getSource();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.AdaptationActions#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(Sender value);

	/**
	 * Returns the value of the '<em><b>Destinataire</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Destinataire</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destinataire</em>' reference.
	 * @see #setDestinataire(Receiver)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getAdaptationActions_Destinataire()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Receiver getDestinataire();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.AdaptationActions#getDestinataire <em>Destinataire</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Destinataire</em>' reference.
	 * @see #getDestinataire()
	 * @generated
	 */
	void setDestinataire(Receiver value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void PublishPlan();

} // AdaptationActions
