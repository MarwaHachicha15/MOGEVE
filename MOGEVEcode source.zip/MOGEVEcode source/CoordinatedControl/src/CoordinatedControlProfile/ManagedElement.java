/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Managed Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.ManagedElement#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.ManagedElement#getProbes <em>Probes</em>}</li>
 *   <li>{@link CoordinatedControlProfile.ManagedElement#getEffector <em>Effector</em>}</li>
 *   <li>{@link CoordinatedControlProfile.ManagedElement#getContextElement <em>Context Element</em>}</li>
 *   <li>{@link CoordinatedControlProfile.ManagedElement#getEventPort <em>Event Port</em>}</li>
 *   <li>{@link CoordinatedControlProfile.ManagedElement#getAgregation <em>Agregation</em>}</li>
 *   <li>{@link CoordinatedControlProfile.ManagedElement#getObservedProperty <em>Observed Property</em>}</li>
 *   <li>{@link CoordinatedControlProfile.ManagedElement#getManager <em>Manager</em>}</li>
 * </ul>
 * </p>
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManagedElement()
 * @model
 * @generated
 */
public interface ManagedElement extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManagedElement_Name()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.ManagedElement#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Probes</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Probes</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Probes</em>' containment reference.
	 * @see #setProbes(Probes)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManagedElement_Probes()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Probes getProbes();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.ManagedElement#getProbes <em>Probes</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Probes</em>' containment reference.
	 * @see #getProbes()
	 * @generated
	 */
	void setProbes(Probes value);

	/**
	 * Returns the value of the '<em><b>Effector</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Effector</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Effector</em>' containment reference.
	 * @see #setEffector(Effector)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManagedElement_Effector()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Effector getEffector();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.ManagedElement#getEffector <em>Effector</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Effector</em>' containment reference.
	 * @see #getEffector()
	 * @generated
	 */
	void setEffector(Effector value);

	/**
	 * Returns the value of the '<em><b>Context Element</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Context Element</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Context Element</em>' containment reference.
	 * @see #setContextElement(ContextElement)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManagedElement_ContextElement()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	ContextElement getContextElement();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.ManagedElement#getContextElement <em>Context Element</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Context Element</em>' containment reference.
	 * @see #getContextElement()
	 * @generated
	 */
	void setContextElement(ContextElement value);

	/**
	 * Returns the value of the '<em><b>Event Port</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.EventPort}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event Port</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event Port</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManagedElement_EventPort()
	 * @model containment="true" ordered="false"
	 * @generated
	 */
	EList<EventPort> getEventPort();

	/**
	 * Returns the value of the '<em><b>Agregation</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.Agregation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agregation</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agregation</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManagedElement_Agregation()
	 * @model containment="true" ordered="false"
	 * @generated
	 */
	EList<Agregation> getAgregation();

	/**
	 * Returns the value of the '<em><b>Observed Property</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.ObservedProperty}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Observed Property</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Observed Property</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManagedElement_ObservedProperty()
	 * @model containment="true" ordered="false"
	 * @generated
	 */
	EList<ObservedProperty> getObservedProperty();

	/**
	 * Returns the value of the '<em><b>Manager</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Manager</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Manager</em>' reference.
	 * @see #setManager(Manager)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManagedElement_Manager()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Manager getManager();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.ManagedElement#getManager <em>Manager</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Manager</em>' reference.
	 * @see #getManager()
	 * @generated
	 */
	void setManager(Manager value);

} // ManagedElement
