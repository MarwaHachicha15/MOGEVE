/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Port</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getEventPort()
 * @model
 * @generated
 */
public interface EventPort extends EObject {
} // EventPort
