/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Observed Property</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.ObservedProperty#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.ObservedProperty#getSource <em>Source</em>}</li>
 *   <li>{@link CoordinatedControlProfile.ObservedProperty#getDestinataire <em>Destinataire</em>}</li>
 * </ul>
 * </p>
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getObservedProperty()
 * @model
 * @generated
 */
public interface ObservedProperty extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getObservedProperty_Name()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.ObservedProperty#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(ContextElement)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getObservedProperty_Source()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	ContextElement getSource();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.ObservedProperty#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(ContextElement value);

	/**
	 * Returns the value of the '<em><b>Destinataire</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Destinataire</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destinataire</em>' reference.
	 * @see #setDestinataire(Probes)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getObservedProperty_Destinataire()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Probes getDestinataire();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.ObservedProperty#getDestinataire <em>Destinataire</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Destinataire</em>' reference.
	 * @see #getDestinataire()
	 * @generated
	 */
	void setDestinataire(Probes value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void CarryingProperty();

} // ObservedProperty
