/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Probes</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.Probes#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Probes#getProbeState <em>Probe State</em>}</li>
 * </ul>
 * </p>
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getProbes()
 * @model
 * @generated
 */
public interface Probes extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getProbes_Name()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Probes#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Probe State</b></em>' attribute.
	 * The literals are from the enumeration {@link CoordinatedControlProfile.ProbesState}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Probe State</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Probe State</em>' attribute.
	 * @see CoordinatedControlProfile.ProbesState
	 * @see #setProbeState(ProbesState)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getProbes_ProbeState()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	ProbesState getProbeState();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Probes#getProbeState <em>Probe State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Probe State</em>' attribute.
	 * @see CoordinatedControlProfile.ProbesState
	 * @see #getProbeState()
	 * @generated
	 */
	void setProbeState(ProbesState value);

} // Probes
