/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Manager</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.Manager#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Manager#getMonitor <em>Monitor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Manager#getAnalyzer <em>Analyzer</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Manager#getPlanner <em>Planner</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Manager#getExecutor <em>Executor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Manager#getAdaptationActions <em>Adaptation Actions</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Manager#getRFC <em>RFC</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Manager#getSymptom <em>Symptom</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Manager#getEventPort <em>Event Port</em>}</li>
 *   <li>{@link CoordinatedControlProfile.Manager#getAgregation <em>Agregation</em>}</li>
 * </ul>
 * </p>
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManager()
 * @model
 * @generated
 */
public interface Manager extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManager_Name()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Manager#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Monitor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Monitor</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Monitor</em>' containment reference.
	 * @see #setMonitor(Monitor)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManager_Monitor()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Monitor getMonitor();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Manager#getMonitor <em>Monitor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Monitor</em>' containment reference.
	 * @see #getMonitor()
	 * @generated
	 */
	void setMonitor(Monitor value);

	/**
	 * Returns the value of the '<em><b>Analyzer</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Analyzer</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Analyzer</em>' containment reference.
	 * @see #setAnalyzer(Analyzer)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManager_Analyzer()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Analyzer getAnalyzer();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Manager#getAnalyzer <em>Analyzer</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Analyzer</em>' containment reference.
	 * @see #getAnalyzer()
	 * @generated
	 */
	void setAnalyzer(Analyzer value);

	/**
	 * Returns the value of the '<em><b>Planner</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Planner</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Planner</em>' containment reference.
	 * @see #setPlanner(Planner)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManager_Planner()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Planner getPlanner();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Manager#getPlanner <em>Planner</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Planner</em>' containment reference.
	 * @see #getPlanner()
	 * @generated
	 */
	void setPlanner(Planner value);

	/**
	 * Returns the value of the '<em><b>Executor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Executor</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Executor</em>' containment reference.
	 * @see #setExecutor(Executor)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManager_Executor()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Executor getExecutor();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.Manager#getExecutor <em>Executor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Executor</em>' containment reference.
	 * @see #getExecutor()
	 * @generated
	 */
	void setExecutor(Executor value);

	/**
	 * Returns the value of the '<em><b>Adaptation Actions</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.AdaptationActions}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Adaptation Actions</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Adaptation Actions</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManager_AdaptationActions()
	 * @model containment="true" ordered="false"
	 * @generated
	 */
	EList<AdaptationActions> getAdaptationActions();

	/**
	 * Returns the value of the '<em><b>RFC</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.RFC}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>RFC</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>RFC</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManager_RFC()
	 * @model containment="true" ordered="false"
	 * @generated
	 */
	EList<RFC> getRFC();

	/**
	 * Returns the value of the '<em><b>Symptom</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.Symptom}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Symptom</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Symptom</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManager_Symptom()
	 * @model containment="true" ordered="false"
	 * @generated
	 */
	EList<Symptom> getSymptom();

	/**
	 * Returns the value of the '<em><b>Event Port</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.EventPort}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event Port</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event Port</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManager_EventPort()
	 * @model containment="true" ordered="false"
	 * @generated
	 */
	EList<EventPort> getEventPort();

	/**
	 * Returns the value of the '<em><b>Agregation</b></em>' containment reference list.
	 * The list contents are of type {@link CoordinatedControlProfile.Agregation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agregation</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agregation</em>' containment reference list.
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getManager_Agregation()
	 * @model containment="true" ordered="false"
	 * @generated
	 */
	EList<Agregation> getAgregation();

} // Manager
