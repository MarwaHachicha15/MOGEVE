/**
 */
package CoordinatedControlProfile.impl;

import CoordinatedControlProfile.Agregation;
import CoordinatedControlProfile.CoordinatedControlProfilePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Agregation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class AgregationImpl extends MinimalEObjectImpl.Container implements Agregation {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AgregationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CoordinatedControlProfilePackage.Literals.AGREGATION;
	}

} //AgregationImpl
