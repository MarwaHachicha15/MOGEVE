/**
 */
package CoordinatedControlProfile.impl;

import CoordinatedControlProfile.CoordinatedControlProfilePackage;
import CoordinatedControlProfile.Effector;
import CoordinatedControlProfile.Effectorstate;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Effector</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.impl.EffectorImpl#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.EffectorImpl#getEffState <em>Eff State</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EffectorImpl extends MinimalEObjectImpl.Container implements Effector {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getEffState() <em>Eff State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEffState()
	 * @generated
	 * @ordered
	 */
	protected static final Effectorstate EFF_STATE_EDEFAULT = Effectorstate.ACTIVE;

	/**
	 * The cached value of the '{@link #getEffState() <em>Eff State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEffState()
	 * @generated
	 * @ordered
	 */
	protected Effectorstate effState = EFF_STATE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EffectorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CoordinatedControlProfilePackage.Literals.EFFECTOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.EFFECTOR__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Effectorstate getEffState() {
		return effState;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEffState(Effectorstate newEffState) {
		Effectorstate oldEffState = effState;
		effState = newEffState == null ? EFF_STATE_EDEFAULT : newEffState;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.EFFECTOR__EFF_STATE, oldEffState, effState));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.EFFECTOR__NAME:
				return getName();
			case CoordinatedControlProfilePackage.EFFECTOR__EFF_STATE:
				return getEffState();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.EFFECTOR__NAME:
				setName((String)newValue);
				return;
			case CoordinatedControlProfilePackage.EFFECTOR__EFF_STATE:
				setEffState((Effectorstate)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.EFFECTOR__NAME:
				setName(NAME_EDEFAULT);
				return;
			case CoordinatedControlProfilePackage.EFFECTOR__EFF_STATE:
				setEffState(EFF_STATE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.EFFECTOR__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case CoordinatedControlProfilePackage.EFFECTOR__EFF_STATE:
				return effState != EFF_STATE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", EffState: ");
		result.append(effState);
		result.append(')');
		return result.toString();
	}

} //EffectorImpl
