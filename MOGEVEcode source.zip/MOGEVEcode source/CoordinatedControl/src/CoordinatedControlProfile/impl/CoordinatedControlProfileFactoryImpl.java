/**
 */
package CoordinatedControlProfile.impl;

import CoordinatedControlProfile.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CoordinatedControlProfileFactoryImpl extends EFactoryImpl implements CoordinatedControlProfileFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static CoordinatedControlProfileFactory init() {
		try {
			CoordinatedControlProfileFactory theCoordinatedControlProfileFactory = (CoordinatedControlProfileFactory)EPackage.Registry.INSTANCE.getEFactory(CoordinatedControlProfilePackage.eNS_URI);
			if (theCoordinatedControlProfileFactory != null) {
				return theCoordinatedControlProfileFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new CoordinatedControlProfileFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CoordinatedControlProfileFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL: return createCoordinatedControl();
			case CoordinatedControlProfilePackage.MANAGER: return createManager();
			case CoordinatedControlProfilePackage.MONITOR: return createMonitor();
			case CoordinatedControlProfilePackage.RECEIVER: return createReceiver();
			case CoordinatedControlProfilePackage.PROCESSOR: return createProcessor();
			case CoordinatedControlProfilePackage.SENDER: return createSender();
			case CoordinatedControlProfilePackage.ANALYZER: return createAnalyzer();
			case CoordinatedControlProfilePackage.PLANNER: return createPlanner();
			case CoordinatedControlProfilePackage.EXECUTOR: return createExecutor();
			case CoordinatedControlProfilePackage.ADAPTATION_ACTIONS: return createAdaptationActions();
			case CoordinatedControlProfilePackage.RFC: return createRFC();
			case CoordinatedControlProfilePackage.SYMPTOM: return createSymptom();
			case CoordinatedControlProfilePackage.EVENT_PORT: return createEventPort();
			case CoordinatedControlProfilePackage.AGREGATION: return createAgregation();
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT: return createManagedElement();
			case CoordinatedControlProfilePackage.PROBES: return createProbes();
			case CoordinatedControlProfilePackage.EFFECTOR: return createEffector();
			case CoordinatedControlProfilePackage.CONTEXT_ELEMENT: return createContextElement();
			case CoordinatedControlProfilePackage.OBSERVED_PROPERTY: return createObservedProperty();
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION: return createIntracmpInteraction();
			case CoordinatedControlProfilePackage.PS: return createPS();
			case CoordinatedControlProfilePackage.RP: return createRP();
			case CoordinatedControlProfilePackage.MONITORING_DATA: return createMonitoringData();
			case CoordinatedControlProfilePackage.COMMANDS: return createCommands();
			case CoordinatedControlProfilePackage.REQUIRED_INTERFACE: return createRequiredInterface();
			case CoordinatedControlProfilePackage.PROVIDED_INTERFACE: return createProvidedInterface();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case CoordinatedControlProfilePackage.SYMPTOM_ANALYSIS:
				return createSymptomAnalysisFromString(eDataType, initialValue);
			case CoordinatedControlProfilePackage.ADAPTATION_ACTION_TYPE:
				return createAdaptationActionTypeFromString(eDataType, initialValue);
			case CoordinatedControlProfilePackage.PROBES_STATE:
				return createProbesStateFromString(eDataType, initialValue);
			case CoordinatedControlProfilePackage.EFFECTORSTATE:
				return createEffectorstateFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case CoordinatedControlProfilePackage.SYMPTOM_ANALYSIS:
				return convertSymptomAnalysisToString(eDataType, instanceValue);
			case CoordinatedControlProfilePackage.ADAPTATION_ACTION_TYPE:
				return convertAdaptationActionTypeToString(eDataType, instanceValue);
			case CoordinatedControlProfilePackage.PROBES_STATE:
				return convertProbesStateToString(eDataType, instanceValue);
			case CoordinatedControlProfilePackage.EFFECTORSTATE:
				return convertEffectorstateToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CoordinatedControl createCoordinatedControl() {
		CoordinatedControlImpl coordinatedControl = new CoordinatedControlImpl();
		return coordinatedControl;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Manager createManager() {
		ManagerImpl manager = new ManagerImpl();
		return manager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Monitor createMonitor() {
		MonitorImpl monitor = new MonitorImpl();
		return monitor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Receiver createReceiver() {
		ReceiverImpl receiver = new ReceiverImpl();
		return receiver;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Processor createProcessor() {
		ProcessorImpl processor = new ProcessorImpl();
		return processor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Sender createSender() {
		SenderImpl sender = new SenderImpl();
		return sender;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Analyzer createAnalyzer() {
		AnalyzerImpl analyzer = new AnalyzerImpl();
		return analyzer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Planner createPlanner() {
		PlannerImpl planner = new PlannerImpl();
		return planner;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Executor createExecutor() {
		ExecutorImpl executor = new ExecutorImpl();
		return executor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ManagedElement createManagedElement() {
		ManagedElementImpl managedElement = new ManagedElementImpl();
		return managedElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Probes createProbes() {
		ProbesImpl probes = new ProbesImpl();
		return probes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Effector createEffector() {
		EffectorImpl effector = new EffectorImpl();
		return effector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContextElement createContextElement() {
		ContextElementImpl contextElement = new ContextElementImpl();
		return contextElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EventPort createEventPort() {
		EventPortImpl eventPort = new EventPortImpl();
		return eventPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Agregation createAgregation() {
		AgregationImpl agregation = new AgregationImpl();
		return agregation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ObservedProperty createObservedProperty() {
		ObservedPropertyImpl observedProperty = new ObservedPropertyImpl();
		return observedProperty;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AdaptationActions createAdaptationActions() {
		AdaptationActionsImpl adaptationActions = new AdaptationActionsImpl();
		return adaptationActions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RFC createRFC() {
		RFCImpl rfc = new RFCImpl();
		return rfc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Symptom createSymptom() {
		SymptomImpl symptom = new SymptomImpl();
		return symptom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IntracmpInteraction createIntracmpInteraction() {
		IntracmpInteractionImpl intracmpInteraction = new IntracmpInteractionImpl();
		return intracmpInteraction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PS createPS() {
		PSImpl ps = new PSImpl();
		return ps;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RP createRP() {
		RPImpl rp = new RPImpl();
		return rp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MonitoringData createMonitoringData() {
		MonitoringDataImpl monitoringData = new MonitoringDataImpl();
		return monitoringData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Commands createCommands() {
		CommandsImpl commands = new CommandsImpl();
		return commands;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RequiredInterface createRequiredInterface() {
		RequiredInterfaceImpl requiredInterface = new RequiredInterfaceImpl();
		return requiredInterface;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProvidedInterface createProvidedInterface() {
		ProvidedInterfaceImpl providedInterface = new ProvidedInterfaceImpl();
		return providedInterface;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SymptomAnalysis createSymptomAnalysisFromString(EDataType eDataType, String initialValue) {
		SymptomAnalysis result = SymptomAnalysis.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertSymptomAnalysisToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AdaptationActionType createAdaptationActionTypeFromString(EDataType eDataType, String initialValue) {
		AdaptationActionType result = AdaptationActionType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertAdaptationActionTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProbesState createProbesStateFromString(EDataType eDataType, String initialValue) {
		ProbesState result = ProbesState.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertProbesStateToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Effectorstate createEffectorstateFromString(EDataType eDataType, String initialValue) {
		Effectorstate result = Effectorstate.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertEffectorstateToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CoordinatedControlProfilePackage getCoordinatedControlProfilePackage() {
		return (CoordinatedControlProfilePackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static CoordinatedControlProfilePackage getPackage() {
		return CoordinatedControlProfilePackage.eINSTANCE;
	}

} //CoordinatedControlProfileFactoryImpl
