/**
 */
package CoordinatedControlProfile.impl;

import CoordinatedControlProfile.Analyzer;
import CoordinatedControlProfile.CoordinatedControlProfilePackage;
import CoordinatedControlProfile.Executor;
import CoordinatedControlProfile.IntracmpInteraction;
import CoordinatedControlProfile.Monitor;
import CoordinatedControlProfile.Planner;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Intracmp Interaction</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.impl.IntracmpInteractionImpl#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.IntracmpInteractionImpl#getSourceM <em>Source M</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.IntracmpInteractionImpl#getDestinataireM <em>Destinataire M</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.IntracmpInteractionImpl#getSourceA <em>Source A</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.IntracmpInteractionImpl#getDestinataireA <em>Destinataire A</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.IntracmpInteractionImpl#getSourceP <em>Source P</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.IntracmpInteractionImpl#getDestinataireP <em>Destinataire P</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.IntracmpInteractionImpl#getSourceE <em>Source E</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.IntracmpInteractionImpl#getDestinataireE <em>Destinataire E</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class IntracmpInteractionImpl extends MinimalEObjectImpl.Container implements IntracmpInteraction {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSourceM() <em>Source M</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceM()
	 * @generated
	 * @ordered
	 */
	protected Monitor sourceM;

	/**
	 * The cached value of the '{@link #getDestinataireM() <em>Destinataire M</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDestinataireM()
	 * @generated
	 * @ordered
	 */
	protected Monitor destinataireM;

	/**
	 * The cached value of the '{@link #getSourceA() <em>Source A</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceA()
	 * @generated
	 * @ordered
	 */
	protected Analyzer sourceA;

	/**
	 * The cached value of the '{@link #getDestinataireA() <em>Destinataire A</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDestinataireA()
	 * @generated
	 * @ordered
	 */
	protected Analyzer destinataireA;

	/**
	 * The cached value of the '{@link #getSourceP() <em>Source P</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceP()
	 * @generated
	 * @ordered
	 */
	protected Planner sourceP;

	/**
	 * The cached value of the '{@link #getDestinataireP() <em>Destinataire P</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDestinataireP()
	 * @generated
	 * @ordered
	 */
	protected Planner destinataireP;

	/**
	 * The cached value of the '{@link #getSourceE() <em>Source E</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceE()
	 * @generated
	 * @ordered
	 */
	protected Executor sourceE;

	/**
	 * The cached value of the '{@link #getDestinataireE() <em>Destinataire E</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDestinataireE()
	 * @generated
	 * @ordered
	 */
	protected Executor destinataireE;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IntracmpInteractionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CoordinatedControlProfilePackage.Literals.INTRACMP_INTERACTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Monitor getSourceM() {
		if (sourceM != null && sourceM.eIsProxy()) {
			InternalEObject oldSourceM = (InternalEObject)sourceM;
			sourceM = (Monitor)eResolveProxy(oldSourceM);
			if (sourceM != oldSourceM) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_M, oldSourceM, sourceM));
			}
		}
		return sourceM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Monitor basicGetSourceM() {
		return sourceM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSourceM(Monitor newSourceM) {
		Monitor oldSourceM = sourceM;
		sourceM = newSourceM;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_M, oldSourceM, sourceM));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Monitor getDestinataireM() {
		if (destinataireM != null && destinataireM.eIsProxy()) {
			InternalEObject oldDestinataireM = (InternalEObject)destinataireM;
			destinataireM = (Monitor)eResolveProxy(oldDestinataireM);
			if (destinataireM != oldDestinataireM) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_M, oldDestinataireM, destinataireM));
			}
		}
		return destinataireM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Monitor basicGetDestinataireM() {
		return destinataireM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDestinataireM(Monitor newDestinataireM) {
		Monitor oldDestinataireM = destinataireM;
		destinataireM = newDestinataireM;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_M, oldDestinataireM, destinataireM));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Analyzer getSourceA() {
		if (sourceA != null && sourceA.eIsProxy()) {
			InternalEObject oldSourceA = (InternalEObject)sourceA;
			sourceA = (Analyzer)eResolveProxy(oldSourceA);
			if (sourceA != oldSourceA) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_A, oldSourceA, sourceA));
			}
		}
		return sourceA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Analyzer basicGetSourceA() {
		return sourceA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSourceA(Analyzer newSourceA) {
		Analyzer oldSourceA = sourceA;
		sourceA = newSourceA;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_A, oldSourceA, sourceA));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Analyzer getDestinataireA() {
		if (destinataireA != null && destinataireA.eIsProxy()) {
			InternalEObject oldDestinataireA = (InternalEObject)destinataireA;
			destinataireA = (Analyzer)eResolveProxy(oldDestinataireA);
			if (destinataireA != oldDestinataireA) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_A, oldDestinataireA, destinataireA));
			}
		}
		return destinataireA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Analyzer basicGetDestinataireA() {
		return destinataireA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDestinataireA(Analyzer newDestinataireA) {
		Analyzer oldDestinataireA = destinataireA;
		destinataireA = newDestinataireA;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_A, oldDestinataireA, destinataireA));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Planner getSourceP() {
		if (sourceP != null && sourceP.eIsProxy()) {
			InternalEObject oldSourceP = (InternalEObject)sourceP;
			sourceP = (Planner)eResolveProxy(oldSourceP);
			if (sourceP != oldSourceP) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_P, oldSourceP, sourceP));
			}
		}
		return sourceP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Planner basicGetSourceP() {
		return sourceP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSourceP(Planner newSourceP) {
		Planner oldSourceP = sourceP;
		sourceP = newSourceP;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_P, oldSourceP, sourceP));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Planner getDestinataireP() {
		if (destinataireP != null && destinataireP.eIsProxy()) {
			InternalEObject oldDestinataireP = (InternalEObject)destinataireP;
			destinataireP = (Planner)eResolveProxy(oldDestinataireP);
			if (destinataireP != oldDestinataireP) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_P, oldDestinataireP, destinataireP));
			}
		}
		return destinataireP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Planner basicGetDestinataireP() {
		return destinataireP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDestinataireP(Planner newDestinataireP) {
		Planner oldDestinataireP = destinataireP;
		destinataireP = newDestinataireP;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_P, oldDestinataireP, destinataireP));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Executor getSourceE() {
		if (sourceE != null && sourceE.eIsProxy()) {
			InternalEObject oldSourceE = (InternalEObject)sourceE;
			sourceE = (Executor)eResolveProxy(oldSourceE);
			if (sourceE != oldSourceE) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_E, oldSourceE, sourceE));
			}
		}
		return sourceE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Executor basicGetSourceE() {
		return sourceE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSourceE(Executor newSourceE) {
		Executor oldSourceE = sourceE;
		sourceE = newSourceE;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_E, oldSourceE, sourceE));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Executor getDestinataireE() {
		if (destinataireE != null && destinataireE.eIsProxy()) {
			InternalEObject oldDestinataireE = (InternalEObject)destinataireE;
			destinataireE = (Executor)eResolveProxy(oldDestinataireE);
			if (destinataireE != oldDestinataireE) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_E, oldDestinataireE, destinataireE));
			}
		}
		return destinataireE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Executor basicGetDestinataireE() {
		return destinataireE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDestinataireE(Executor newDestinataireE) {
		Executor oldDestinataireE = destinataireE;
		destinataireE = newDestinataireE;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_E, oldDestinataireE, destinataireE));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__NAME:
				return getName();
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_M:
				if (resolve) return getSourceM();
				return basicGetSourceM();
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_M:
				if (resolve) return getDestinataireM();
				return basicGetDestinataireM();
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_A:
				if (resolve) return getSourceA();
				return basicGetSourceA();
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_A:
				if (resolve) return getDestinataireA();
				return basicGetDestinataireA();
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_P:
				if (resolve) return getSourceP();
				return basicGetSourceP();
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_P:
				if (resolve) return getDestinataireP();
				return basicGetDestinataireP();
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_E:
				if (resolve) return getSourceE();
				return basicGetSourceE();
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_E:
				if (resolve) return getDestinataireE();
				return basicGetDestinataireE();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__NAME:
				setName((String)newValue);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_M:
				setSourceM((Monitor)newValue);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_M:
				setDestinataireM((Monitor)newValue);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_A:
				setSourceA((Analyzer)newValue);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_A:
				setDestinataireA((Analyzer)newValue);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_P:
				setSourceP((Planner)newValue);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_P:
				setDestinataireP((Planner)newValue);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_E:
				setSourceE((Executor)newValue);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_E:
				setDestinataireE((Executor)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__NAME:
				setName(NAME_EDEFAULT);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_M:
				setSourceM((Monitor)null);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_M:
				setDestinataireM((Monitor)null);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_A:
				setSourceA((Analyzer)null);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_A:
				setDestinataireA((Analyzer)null);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_P:
				setSourceP((Planner)null);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_P:
				setDestinataireP((Planner)null);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_E:
				setSourceE((Executor)null);
				return;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_E:
				setDestinataireE((Executor)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_M:
				return sourceM != null;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_M:
				return destinataireM != null;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_A:
				return sourceA != null;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_A:
				return destinataireA != null;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_P:
				return sourceP != null;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_P:
				return destinataireP != null;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__SOURCE_E:
				return sourceE != null;
			case CoordinatedControlProfilePackage.INTRACMP_INTERACTION__DESTINATAIRE_E:
				return destinataireE != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //IntracmpInteractionImpl
