/**
 */
package CoordinatedControlProfile.impl;

import CoordinatedControlProfile.AdaptationActionType;
import CoordinatedControlProfile.AdaptationActions;
import CoordinatedControlProfile.Agregation;
import CoordinatedControlProfile.Analyzer;
import CoordinatedControlProfile.Commands;
import CoordinatedControlProfile.ContextElement;
import CoordinatedControlProfile.CoordinatedControl;
import CoordinatedControlProfile.CoordinatedControlProfileFactory;
import CoordinatedControlProfile.CoordinatedControlProfilePackage;
import CoordinatedControlProfile.Effector;
import CoordinatedControlProfile.Effectorstate;
import CoordinatedControlProfile.EventPort;
import CoordinatedControlProfile.Executor;
import CoordinatedControlProfile.IntracmpInteraction;
import CoordinatedControlProfile.ManagedElement;
import CoordinatedControlProfile.Manager;
import CoordinatedControlProfile.Monitor;
import CoordinatedControlProfile.MonitoringData;
import CoordinatedControlProfile.ObservedProperty;
import CoordinatedControlProfile.Planner;
import CoordinatedControlProfile.Probes;
import CoordinatedControlProfile.ProbesState;
import CoordinatedControlProfile.Processor;
import CoordinatedControlProfile.ProvidedInterface;
import CoordinatedControlProfile.Receiver;
import CoordinatedControlProfile.RequiredInterface;
import CoordinatedControlProfile.Sender;
import CoordinatedControlProfile.Symptom;
import CoordinatedControlProfile.SymptomAnalysis;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.uml2.types.TypesPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CoordinatedControlProfilePackageImpl extends EPackageImpl implements CoordinatedControlProfilePackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass coordinatedControlEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass managerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass monitorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass receiverEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass processorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass senderEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass analyzerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass plannerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass executorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass managedElementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass probesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass effectorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass contextElementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass eventPortEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass agregationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass observedPropertyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass adaptationActionsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass rfcEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass symptomEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass intracmpInteractionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass psEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass rpEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass monitoringDataEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass commandsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass requiredInterfaceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass providedInterfaceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum symptomAnalysisEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum adaptationActionTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum probesStateEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum effectorstateEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private CoordinatedControlProfilePackageImpl() {
		super(eNS_URI, CoordinatedControlProfileFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link CoordinatedControlProfilePackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static CoordinatedControlProfilePackage init() {
		if (isInited) return (CoordinatedControlProfilePackage)EPackage.Registry.INSTANCE.getEPackage(CoordinatedControlProfilePackage.eNS_URI);

		// Obtain or create and register package
		CoordinatedControlProfilePackageImpl theCoordinatedControlProfilePackage = (CoordinatedControlProfilePackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof CoordinatedControlProfilePackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new CoordinatedControlProfilePackageImpl());

		isInited = true;

		// Initialize simple dependencies
		TypesPackage.eINSTANCE.eClass();

		// Create package meta-data objects
		theCoordinatedControlProfilePackage.createPackageContents();

		// Initialize created meta-data
		theCoordinatedControlProfilePackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theCoordinatedControlProfilePackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(CoordinatedControlProfilePackage.eNS_URI, theCoordinatedControlProfilePackage);
		return theCoordinatedControlProfilePackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCoordinatedControl() {
		return coordinatedControlEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_Manager() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_ManagedElement() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_Probes() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_ContextElement() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_Effector() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_Monitor() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_Analyzer() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_Planner() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_Executor() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_IntracmpInteraction() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_Receiver() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_Processor() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_Sender() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_PS() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_RP() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_MonitoringData() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_AdaptationActions() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_Commands() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_RFC() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_ObservedProperty() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_Symptom() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_Agregation() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(21);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_RequiredInterface() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(22);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_ProvidedInterface() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(23);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCoordinatedControl_EventPort() {
		return (EReference)coordinatedControlEClass.getEStructuralFeatures().get(24);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getManager() {
		return managerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getManager_Name() {
		return (EAttribute)managerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManager_Monitor() {
		return (EReference)managerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManager_Analyzer() {
		return (EReference)managerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManager_Planner() {
		return (EReference)managerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManager_Executor() {
		return (EReference)managerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManager_AdaptationActions() {
		return (EReference)managerEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManager_RFC() {
		return (EReference)managerEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManager_Symptom() {
		return (EReference)managerEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManager_EventPort() {
		return (EReference)managerEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManager_Agregation() {
		return (EReference)managerEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMonitor() {
		return monitorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMonitor_Name() {
		return (EAttribute)monitorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMonitor_Data() {
		return (EAttribute)monitorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMonitor_Receiver() {
		return (EReference)monitorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMonitor_Processor() {
		return (EReference)monitorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMonitor_Sender() {
		return (EReference)monitorEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getReceiver() {
		return receiverEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getReceiver_Name() {
		return (EAttribute)receiverEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getProcessor() {
		return processorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProcessor_Name() {
		return (EAttribute)processorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSender() {
		return senderEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSender_Name() {
		return (EAttribute)senderEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAnalyzer() {
		return analyzerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalyzer_Name() {
		return (EAttribute)analyzerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalyzer_SymptomAnalysis() {
		return (EAttribute)analyzerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalyzer_ThersholdMIN() {
		return (EAttribute)analyzerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalyzer_ThersholdMAX() {
		return (EAttribute)analyzerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAnalyzer_Receiver() {
		return (EReference)analyzerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAnalyzer_Processor() {
		return (EReference)analyzerEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAnalyzer_Sender() {
		return (EReference)analyzerEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPlanner() {
		return plannerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPlanner_Name() {
		return (EAttribute)plannerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPlanner_RFC() {
		return (EAttribute)plannerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlanner_Receiver() {
		return (EReference)plannerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlanner_Processor() {
		return (EReference)plannerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlanner_Sender() {
		return (EReference)plannerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getExecutor() {
		return executorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getExecutor_Name() {
		return (EAttribute)executorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getExecutor_Adaction() {
		return (EAttribute)executorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getExecutor_Receiver() {
		return (EReference)executorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getExecutor_Processor() {
		return (EReference)executorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getExecutor_Sender() {
		return (EReference)executorEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getManagedElement() {
		return managedElementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getManagedElement_Name() {
		return (EAttribute)managedElementEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManagedElement_Probes() {
		return (EReference)managedElementEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManagedElement_Effector() {
		return (EReference)managedElementEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManagedElement_ContextElement() {
		return (EReference)managedElementEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManagedElement_EventPort() {
		return (EReference)managedElementEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManagedElement_Agregation() {
		return (EReference)managedElementEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManagedElement_ObservedProperty() {
		return (EReference)managedElementEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getManagedElement_Manager() {
		return (EReference)managedElementEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getProbes() {
		return probesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProbes_Name() {
		return (EAttribute)probesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProbes_ProbeState() {
		return (EAttribute)probesEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEffector() {
		return effectorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEffector_Name() {
		return (EAttribute)effectorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEffector_EffState() {
		return (EAttribute)effectorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getContextElement() {
		return contextElementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContextElement_Name() {
		return (EAttribute)contextElementEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContextElement_ID() {
		return (EAttribute)contextElementEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContextElement_Value() {
		return (EAttribute)contextElementEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEventPort() {
		return eventPortEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAgregation() {
		return agregationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getObservedProperty() {
		return observedPropertyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObservedProperty_Name() {
		return (EAttribute)observedPropertyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObservedProperty_Source() {
		return (EReference)observedPropertyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObservedProperty_Destinataire() {
		return (EReference)observedPropertyEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getObservedProperty__CarryingProperty() {
		return observedPropertyEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAdaptationActions() {
		return adaptationActionsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAdaptationActions_Name() {
		return (EAttribute)adaptationActionsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAdaptationActions_Source() {
		return (EReference)adaptationActionsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAdaptationActions_Destinataire() {
		return (EReference)adaptationActionsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAdaptationActions__PublishPlan() {
		return adaptationActionsEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRFC() {
		return rfcEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRFC_Name() {
		return (EAttribute)rfcEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRFC_Source() {
		return (EReference)rfcEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRFC_Destinataire() {
		return (EReference)rfcEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRFC__SendRFC() {
		return rfcEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSymptom() {
		return symptomEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSymptom_Name() {
		return (EAttribute)symptomEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSymptom_Source() {
		return (EReference)symptomEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSymptom_Destinataire() {
		return (EReference)symptomEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getSymptom__PublishSymptom() {
		return symptomEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIntracmpInteraction() {
		return intracmpInteractionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getIntracmpInteraction_Name() {
		return (EAttribute)intracmpInteractionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIntracmpInteraction_SourceM() {
		return (EReference)intracmpInteractionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIntracmpInteraction_DestinataireM() {
		return (EReference)intracmpInteractionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIntracmpInteraction_SourceA() {
		return (EReference)intracmpInteractionEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIntracmpInteraction_DestinataireA() {
		return (EReference)intracmpInteractionEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIntracmpInteraction_SourceP() {
		return (EReference)intracmpInteractionEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIntracmpInteraction_DestinataireP() {
		return (EReference)intracmpInteractionEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIntracmpInteraction_SourceE() {
		return (EReference)intracmpInteractionEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIntracmpInteraction_DestinataireE() {
		return (EReference)intracmpInteractionEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPS() {
		return psEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPS_Sender() {
		return (EReference)psEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPS_Processor() {
		return (EReference)psEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPS_Name() {
		return (EAttribute)psEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRP() {
		return rpEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRP_Receiver() {
		return (EReference)rpEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRP_Processor() {
		return (EReference)rpEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRP_Name() {
		return (EAttribute)rpEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMonitoringData() {
		return monitoringDataEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMonitoringData_Name() {
		return (EAttribute)monitoringDataEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMonitoringData_Source() {
		return (EReference)monitoringDataEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMonitoringData_Destinataire() {
		return (EReference)monitoringDataEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getMonitoringData__SendMonitoringData() {
		return monitoringDataEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCommands() {
		return commandsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCommands_Name() {
		return (EAttribute)commandsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCommands_Source() {
		return (EReference)commandsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCommands_Destinataire() {
		return (EReference)commandsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCommands__MakeChange() {
		return commandsEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRequiredInterface() {
		return requiredInterfaceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRequiredInterface_Agregation() {
		return (EReference)requiredInterfaceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRequiredInterface_EventPort() {
		return (EReference)requiredInterfaceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getProvidedInterface() {
		return providedInterfaceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProvidedInterface_Agregation() {
		return (EReference)providedInterfaceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProvidedInterface_EventPort() {
		return (EReference)providedInterfaceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getSymptomAnalysis() {
		return symptomAnalysisEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getAdaptationActionType() {
		return adaptationActionTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getProbesState() {
		return probesStateEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getEffectorstate() {
		return effectorstateEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CoordinatedControlProfileFactory getCoordinatedControlProfileFactory() {
		return (CoordinatedControlProfileFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		coordinatedControlEClass = createEClass(COORDINATED_CONTROL);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__MANAGER);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__MANAGED_ELEMENT);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__PROBES);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__CONTEXT_ELEMENT);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__EFFECTOR);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__MONITOR);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__ANALYZER);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__PLANNER);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__EXECUTOR);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__INTRACMP_INTERACTION);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__RECEIVER);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__PROCESSOR);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__SENDER);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__PS);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__RP);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__MONITORING_DATA);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__ADAPTATION_ACTIONS);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__COMMANDS);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__RFC);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__OBSERVED_PROPERTY);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__SYMPTOM);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__AGREGATION);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__REQUIRED_INTERFACE);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__PROVIDED_INTERFACE);
		createEReference(coordinatedControlEClass, COORDINATED_CONTROL__EVENT_PORT);

		managerEClass = createEClass(MANAGER);
		createEAttribute(managerEClass, MANAGER__NAME);
		createEReference(managerEClass, MANAGER__MONITOR);
		createEReference(managerEClass, MANAGER__ANALYZER);
		createEReference(managerEClass, MANAGER__PLANNER);
		createEReference(managerEClass, MANAGER__EXECUTOR);
		createEReference(managerEClass, MANAGER__ADAPTATION_ACTIONS);
		createEReference(managerEClass, MANAGER__RFC);
		createEReference(managerEClass, MANAGER__SYMPTOM);
		createEReference(managerEClass, MANAGER__EVENT_PORT);
		createEReference(managerEClass, MANAGER__AGREGATION);

		monitorEClass = createEClass(MONITOR);
		createEAttribute(monitorEClass, MONITOR__NAME);
		createEAttribute(monitorEClass, MONITOR__DATA);
		createEReference(monitorEClass, MONITOR__RECEIVER);
		createEReference(monitorEClass, MONITOR__PROCESSOR);
		createEReference(monitorEClass, MONITOR__SENDER);

		receiverEClass = createEClass(RECEIVER);
		createEAttribute(receiverEClass, RECEIVER__NAME);

		processorEClass = createEClass(PROCESSOR);
		createEAttribute(processorEClass, PROCESSOR__NAME);

		senderEClass = createEClass(SENDER);
		createEAttribute(senderEClass, SENDER__NAME);

		analyzerEClass = createEClass(ANALYZER);
		createEAttribute(analyzerEClass, ANALYZER__NAME);
		createEAttribute(analyzerEClass, ANALYZER__SYMPTOM_ANALYSIS);
		createEAttribute(analyzerEClass, ANALYZER__THERSHOLD_MIN);
		createEAttribute(analyzerEClass, ANALYZER__THERSHOLD_MAX);
		createEReference(analyzerEClass, ANALYZER__RECEIVER);
		createEReference(analyzerEClass, ANALYZER__PROCESSOR);
		createEReference(analyzerEClass, ANALYZER__SENDER);

		plannerEClass = createEClass(PLANNER);
		createEAttribute(plannerEClass, PLANNER__NAME);
		createEAttribute(plannerEClass, PLANNER__RFC);
		createEReference(plannerEClass, PLANNER__RECEIVER);
		createEReference(plannerEClass, PLANNER__PROCESSOR);
		createEReference(plannerEClass, PLANNER__SENDER);

		executorEClass = createEClass(EXECUTOR);
		createEAttribute(executorEClass, EXECUTOR__NAME);
		createEAttribute(executorEClass, EXECUTOR__ADACTION);
		createEReference(executorEClass, EXECUTOR__RECEIVER);
		createEReference(executorEClass, EXECUTOR__PROCESSOR);
		createEReference(executorEClass, EXECUTOR__SENDER);

		adaptationActionsEClass = createEClass(ADAPTATION_ACTIONS);
		createEAttribute(adaptationActionsEClass, ADAPTATION_ACTIONS__NAME);
		createEReference(adaptationActionsEClass, ADAPTATION_ACTIONS__SOURCE);
		createEReference(adaptationActionsEClass, ADAPTATION_ACTIONS__DESTINATAIRE);
		createEOperation(adaptationActionsEClass, ADAPTATION_ACTIONS___PUBLISH_PLAN);

		rfcEClass = createEClass(RFC);
		createEAttribute(rfcEClass, RFC__NAME);
		createEReference(rfcEClass, RFC__SOURCE);
		createEReference(rfcEClass, RFC__DESTINATAIRE);
		createEOperation(rfcEClass, RFC___SEND_RFC);

		symptomEClass = createEClass(SYMPTOM);
		createEAttribute(symptomEClass, SYMPTOM__NAME);
		createEReference(symptomEClass, SYMPTOM__SOURCE);
		createEReference(symptomEClass, SYMPTOM__DESTINATAIRE);
		createEOperation(symptomEClass, SYMPTOM___PUBLISH_SYMPTOM);

		eventPortEClass = createEClass(EVENT_PORT);

		agregationEClass = createEClass(AGREGATION);

		managedElementEClass = createEClass(MANAGED_ELEMENT);
		createEAttribute(managedElementEClass, MANAGED_ELEMENT__NAME);
		createEReference(managedElementEClass, MANAGED_ELEMENT__PROBES);
		createEReference(managedElementEClass, MANAGED_ELEMENT__EFFECTOR);
		createEReference(managedElementEClass, MANAGED_ELEMENT__CONTEXT_ELEMENT);
		createEReference(managedElementEClass, MANAGED_ELEMENT__EVENT_PORT);
		createEReference(managedElementEClass, MANAGED_ELEMENT__AGREGATION);
		createEReference(managedElementEClass, MANAGED_ELEMENT__OBSERVED_PROPERTY);
		createEReference(managedElementEClass, MANAGED_ELEMENT__MANAGER);

		probesEClass = createEClass(PROBES);
		createEAttribute(probesEClass, PROBES__NAME);
		createEAttribute(probesEClass, PROBES__PROBE_STATE);

		effectorEClass = createEClass(EFFECTOR);
		createEAttribute(effectorEClass, EFFECTOR__NAME);
		createEAttribute(effectorEClass, EFFECTOR__EFF_STATE);

		contextElementEClass = createEClass(CONTEXT_ELEMENT);
		createEAttribute(contextElementEClass, CONTEXT_ELEMENT__NAME);
		createEAttribute(contextElementEClass, CONTEXT_ELEMENT__ID);
		createEAttribute(contextElementEClass, CONTEXT_ELEMENT__VALUE);

		observedPropertyEClass = createEClass(OBSERVED_PROPERTY);
		createEAttribute(observedPropertyEClass, OBSERVED_PROPERTY__NAME);
		createEReference(observedPropertyEClass, OBSERVED_PROPERTY__SOURCE);
		createEReference(observedPropertyEClass, OBSERVED_PROPERTY__DESTINATAIRE);
		createEOperation(observedPropertyEClass, OBSERVED_PROPERTY___CARRYING_PROPERTY);

		intracmpInteractionEClass = createEClass(INTRACMP_INTERACTION);
		createEAttribute(intracmpInteractionEClass, INTRACMP_INTERACTION__NAME);
		createEReference(intracmpInteractionEClass, INTRACMP_INTERACTION__SOURCE_M);
		createEReference(intracmpInteractionEClass, INTRACMP_INTERACTION__DESTINATAIRE_M);
		createEReference(intracmpInteractionEClass, INTRACMP_INTERACTION__SOURCE_A);
		createEReference(intracmpInteractionEClass, INTRACMP_INTERACTION__DESTINATAIRE_A);
		createEReference(intracmpInteractionEClass, INTRACMP_INTERACTION__SOURCE_P);
		createEReference(intracmpInteractionEClass, INTRACMP_INTERACTION__DESTINATAIRE_P);
		createEReference(intracmpInteractionEClass, INTRACMP_INTERACTION__SOURCE_E);
		createEReference(intracmpInteractionEClass, INTRACMP_INTERACTION__DESTINATAIRE_E);

		psEClass = createEClass(PS);
		createEReference(psEClass, PS__SENDER);
		createEReference(psEClass, PS__PROCESSOR);
		createEAttribute(psEClass, PS__NAME);

		rpEClass = createEClass(RP);
		createEReference(rpEClass, RP__RECEIVER);
		createEReference(rpEClass, RP__PROCESSOR);
		createEAttribute(rpEClass, RP__NAME);

		monitoringDataEClass = createEClass(MONITORING_DATA);
		createEAttribute(monitoringDataEClass, MONITORING_DATA__NAME);
		createEReference(monitoringDataEClass, MONITORING_DATA__SOURCE);
		createEReference(monitoringDataEClass, MONITORING_DATA__DESTINATAIRE);
		createEOperation(monitoringDataEClass, MONITORING_DATA___SEND_MONITORING_DATA);

		commandsEClass = createEClass(COMMANDS);
		createEAttribute(commandsEClass, COMMANDS__NAME);
		createEReference(commandsEClass, COMMANDS__SOURCE);
		createEReference(commandsEClass, COMMANDS__DESTINATAIRE);
		createEOperation(commandsEClass, COMMANDS___MAKE_CHANGE);

		requiredInterfaceEClass = createEClass(REQUIRED_INTERFACE);
		createEReference(requiredInterfaceEClass, REQUIRED_INTERFACE__AGREGATION);
		createEReference(requiredInterfaceEClass, REQUIRED_INTERFACE__EVENT_PORT);

		providedInterfaceEClass = createEClass(PROVIDED_INTERFACE);
		createEReference(providedInterfaceEClass, PROVIDED_INTERFACE__AGREGATION);
		createEReference(providedInterfaceEClass, PROVIDED_INTERFACE__EVENT_PORT);

		// Create enums
		symptomAnalysisEEnum = createEEnum(SYMPTOM_ANALYSIS);
		adaptationActionTypeEEnum = createEEnum(ADAPTATION_ACTION_TYPE);
		probesStateEEnum = createEEnum(PROBES_STATE);
		effectorstateEEnum = createEEnum(EFFECTORSTATE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		TypesPackage theTypesPackage = (TypesPackage)EPackage.Registry.INSTANCE.getEPackage(TypesPackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes, features, and operations; add parameters
		initEClass(coordinatedControlEClass, CoordinatedControl.class, "CoordinatedControl", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCoordinatedControl_Manager(), this.getManager(), null, "manager", null, 1, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_ManagedElement(), this.getManagedElement(), null, "managedElement", null, 1, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_Probes(), this.getProbes(), null, "probes", null, 1, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_ContextElement(), this.getContextElement(), null, "contextElement", null, 1, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_Effector(), this.getEffector(), null, "effector", null, 1, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_Monitor(), this.getMonitor(), null, "monitor", null, 1, 1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_Analyzer(), this.getAnalyzer(), null, "analyzer", null, 1, 1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_Planner(), this.getPlanner(), null, "planner", null, 1, 1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_Executor(), this.getExecutor(), null, "executor", null, 1, 1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_IntracmpInteraction(), this.getIntracmpInteraction(), null, "intracmpInteraction", null, 1, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_Receiver(), this.getReceiver(), null, "receiver", null, 1, 1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_Processor(), this.getProcessor(), null, "processor", null, 1, 1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_Sender(), this.getSender(), null, "sender", null, 1, 1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_PS(), this.getPS(), null, "pS", null, 1, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_RP(), this.getRP(), null, "rP", null, 1, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_MonitoringData(), this.getMonitoringData(), null, "monitoringData", null, 1, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_AdaptationActions(), this.getAdaptationActions(), null, "adaptationActions", null, 1, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_Commands(), this.getCommands(), null, "commands", null, 1, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_RFC(), this.getRFC(), null, "rFC", null, 1, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_ObservedProperty(), this.getObservedProperty(), null, "observedProperty", null, 1, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_Symptom(), this.getSymptom(), null, "symptom", null, 1, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_Agregation(), this.getAgregation(), null, "agregation", null, 0, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_RequiredInterface(), this.getRequiredInterface(), null, "requiredInterface", null, 0, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_ProvidedInterface(), this.getProvidedInterface(), null, "providedInterface", null, 0, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCoordinatedControl_EventPort(), this.getEventPort(), null, "eventPort", null, 0, -1, CoordinatedControl.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(managerEClass, Manager.class, "Manager", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getManager_Name(), theTypesPackage.getString(), "Name", null, 1, 1, Manager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManager_Monitor(), this.getMonitor(), null, "monitor", null, 1, 1, Manager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManager_Analyzer(), this.getAnalyzer(), null, "analyzer", null, 1, 1, Manager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManager_Planner(), this.getPlanner(), null, "planner", null, 1, 1, Manager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManager_Executor(), this.getExecutor(), null, "executor", null, 1, 1, Manager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManager_AdaptationActions(), this.getAdaptationActions(), null, "adaptationActions", null, 0, -1, Manager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManager_RFC(), this.getRFC(), null, "rFC", null, 0, -1, Manager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManager_Symptom(), this.getSymptom(), null, "symptom", null, 0, -1, Manager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManager_EventPort(), this.getEventPort(), null, "eventPort", null, 0, -1, Manager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManager_Agregation(), this.getAgregation(), null, "agregation", null, 0, -1, Manager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(monitorEClass, Monitor.class, "Monitor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMonitor_Name(), theTypesPackage.getString(), "Name", null, 1, 1, Monitor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getMonitor_Data(), theTypesPackage.getString(), "Data", null, 1, -1, Monitor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getMonitor_Receiver(), this.getReceiver(), null, "receiver", null, 1, 1, Monitor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getMonitor_Processor(), this.getProcessor(), null, "processor", null, 1, 1, Monitor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getMonitor_Sender(), this.getSender(), null, "sender", null, 1, 1, Monitor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(receiverEClass, Receiver.class, "Receiver", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getReceiver_Name(), theTypesPackage.getString(), "Name", null, 1, 1, Receiver.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(processorEClass, Processor.class, "Processor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getProcessor_Name(), theTypesPackage.getString(), "Name", null, 1, 1, Processor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(senderEClass, Sender.class, "Sender", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSender_Name(), theTypesPackage.getString(), "Name", null, 1, 1, Sender.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(analyzerEClass, Analyzer.class, "Analyzer", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAnalyzer_Name(), theTypesPackage.getString(), "Name", null, 1, 1, Analyzer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getAnalyzer_SymptomAnalysis(), this.getSymptomAnalysis(), "SymptomAnalysis", null, 1, 1, Analyzer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getAnalyzer_ThersholdMIN(), theTypesPackage.getInteger(), "ThersholdMIN", null, 1, 1, Analyzer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getAnalyzer_ThersholdMAX(), theTypesPackage.getInteger(), "ThersholdMAX", null, 1, 1, Analyzer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getAnalyzer_Receiver(), this.getReceiver(), null, "receiver", null, 1, 1, Analyzer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getAnalyzer_Processor(), this.getProcessor(), null, "processor", null, 1, 1, Analyzer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getAnalyzer_Sender(), this.getSender(), null, "sender", null, 1, 1, Analyzer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(plannerEClass, Planner.class, "Planner", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPlanner_Name(), theTypesPackage.getString(), "Name", null, 1, 1, Planner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getPlanner_RFC(), theTypesPackage.getBoolean(), "RFC", null, 1, 1, Planner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getPlanner_Receiver(), this.getReceiver(), null, "receiver", null, 1, 1, Planner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getPlanner_Processor(), this.getProcessor(), null, "processor", null, 1, 1, Planner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getPlanner_Sender(), this.getSender(), null, "sender", null, 1, 1, Planner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(executorEClass, Executor.class, "Executor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getExecutor_Name(), theTypesPackage.getString(), "Name", null, 1, 1, Executor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getExecutor_Adaction(), this.getAdaptationActionType(), "Adaction", null, 1, 1, Executor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getExecutor_Receiver(), this.getReceiver(), null, "receiver", null, 1, 1, Executor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getExecutor_Processor(), this.getProcessor(), null, "processor", null, 1, 1, Executor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getExecutor_Sender(), this.getSender(), null, "sender", null, 1, 1, Executor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(adaptationActionsEClass, AdaptationActions.class, "AdaptationActions", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAdaptationActions_Name(), theTypesPackage.getString(), "Name", null, 1, 1, AdaptationActions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getAdaptationActions_Source(), this.getSender(), null, "Source", null, 1, 1, AdaptationActions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getAdaptationActions_Destinataire(), this.getReceiver(), null, "Destinataire", null, 1, 1, AdaptationActions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getAdaptationActions__PublishPlan(), null, "PublishPlan", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(rfcEClass, CoordinatedControlProfile.RFC.class, "RFC", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRFC_Name(), theTypesPackage.getString(), "Name", null, 1, 1, CoordinatedControlProfile.RFC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getRFC_Source(), this.getSender(), null, "Source", null, 1, 1, CoordinatedControlProfile.RFC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getRFC_Destinataire(), this.getReceiver(), null, "Destinataire", null, 1, 1, CoordinatedControlProfile.RFC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getRFC__SendRFC(), null, "SendRFC", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(symptomEClass, Symptom.class, "Symptom", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSymptom_Name(), theTypesPackage.getString(), "Name", null, 1, 1, Symptom.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getSymptom_Source(), this.getSender(), null, "Source", null, 1, 1, Symptom.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getSymptom_Destinataire(), this.getReceiver(), null, "Destinataire", null, 1, 1, Symptom.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getSymptom__PublishSymptom(), null, "PublishSymptom", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(eventPortEClass, EventPort.class, "EventPort", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(agregationEClass, Agregation.class, "Agregation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(managedElementEClass, ManagedElement.class, "ManagedElement", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getManagedElement_Name(), theTypesPackage.getString(), "Name", null, 1, 1, ManagedElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManagedElement_Probes(), this.getProbes(), null, "probes", null, 1, 1, ManagedElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManagedElement_Effector(), this.getEffector(), null, "effector", null, 1, 1, ManagedElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManagedElement_ContextElement(), this.getContextElement(), null, "contextElement", null, 1, 1, ManagedElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManagedElement_EventPort(), this.getEventPort(), null, "eventPort", null, 0, -1, ManagedElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManagedElement_Agregation(), this.getAgregation(), null, "agregation", null, 0, -1, ManagedElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManagedElement_ObservedProperty(), this.getObservedProperty(), null, "observedProperty", null, 0, -1, ManagedElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getManagedElement_Manager(), this.getManager(), null, "Manager", null, 1, 1, ManagedElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(probesEClass, Probes.class, "Probes", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getProbes_Name(), theTypesPackage.getString(), "Name", null, 1, 1, Probes.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getProbes_ProbeState(), this.getProbesState(), "ProbeState", null, 1, 1, Probes.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(effectorEClass, Effector.class, "Effector", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEffector_Name(), theTypesPackage.getString(), "Name", null, 1, 1, Effector.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getEffector_EffState(), this.getEffectorstate(), "EffState", null, 1, 1, Effector.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(contextElementEClass, ContextElement.class, "ContextElement", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getContextElement_Name(), theTypesPackage.getString(), "Name", null, 1, 1, ContextElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getContextElement_ID(), theTypesPackage.getInteger(), "ID", null, 1, 1, ContextElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getContextElement_Value(), theTypesPackage.getReal(), "Value", null, 1, 1, ContextElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(observedPropertyEClass, ObservedProperty.class, "ObservedProperty", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getObservedProperty_Name(), theTypesPackage.getString(), "Name", null, 1, 1, ObservedProperty.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getObservedProperty_Source(), this.getContextElement(), null, "Source", null, 1, 1, ObservedProperty.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getObservedProperty_Destinataire(), this.getProbes(), null, "Destinataire", null, 1, 1, ObservedProperty.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getObservedProperty__CarryingProperty(), null, "CarryingProperty", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(intracmpInteractionEClass, IntracmpInteraction.class, "IntracmpInteraction", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getIntracmpInteraction_Name(), theTypesPackage.getString(), "Name", null, 1, 1, IntracmpInteraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getIntracmpInteraction_SourceM(), this.getMonitor(), null, "SourceM", null, 1, 1, IntracmpInteraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getIntracmpInteraction_DestinataireM(), this.getMonitor(), null, "DestinataireM", null, 1, 1, IntracmpInteraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getIntracmpInteraction_SourceA(), this.getAnalyzer(), null, "SourceA", null, 1, 1, IntracmpInteraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getIntracmpInteraction_DestinataireA(), this.getAnalyzer(), null, "DestinataireA", null, 1, 1, IntracmpInteraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getIntracmpInteraction_SourceP(), this.getPlanner(), null, "SourceP", null, 1, 1, IntracmpInteraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getIntracmpInteraction_DestinataireP(), this.getPlanner(), null, "DestinataireP", null, 1, 1, IntracmpInteraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getIntracmpInteraction_SourceE(), this.getExecutor(), null, "SourceE", null, 1, 1, IntracmpInteraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getIntracmpInteraction_DestinataireE(), this.getExecutor(), null, "DestinataireE", null, 1, 1, IntracmpInteraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(psEClass, CoordinatedControlProfile.PS.class, "PS", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPS_Sender(), this.getSender(), null, "sender", null, 1, 1, CoordinatedControlProfile.PS.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getPS_Processor(), this.getProcessor(), null, "processor", null, 1, 1, CoordinatedControlProfile.PS.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getPS_Name(), theTypesPackage.getString(), "Name", null, 1, 1, CoordinatedControlProfile.PS.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(rpEClass, CoordinatedControlProfile.RP.class, "RP", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRP_Receiver(), this.getReceiver(), null, "receiver", null, 1, 1, CoordinatedControlProfile.RP.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getRP_Processor(), this.getProcessor(), null, "processor", null, 1, 1, CoordinatedControlProfile.RP.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getRP_Name(), theTypesPackage.getString(), "Name", null, 1, 1, CoordinatedControlProfile.RP.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(monitoringDataEClass, MonitoringData.class, "MonitoringData", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMonitoringData_Name(), theTypesPackage.getString(), "Name", null, 1, 1, MonitoringData.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getMonitoringData_Source(), this.getProbes(), null, "Source", null, 1, 1, MonitoringData.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getMonitoringData_Destinataire(), this.getReceiver(), null, "Destinataire", null, 1, 1, MonitoringData.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getMonitoringData__SendMonitoringData(), null, "SendMonitoringData", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(commandsEClass, Commands.class, "Commands", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCommands_Name(), theTypesPackage.getString(), "Name", null, 1, 1, Commands.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCommands_Source(), this.getSender(), null, "Source", null, 1, 1, Commands.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCommands_Destinataire(), this.getEffector(), null, "Destinataire", null, 1, 1, Commands.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getCommands__MakeChange(), null, "MakeChange", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(requiredInterfaceEClass, RequiredInterface.class, "RequiredInterface", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRequiredInterface_Agregation(), this.getAgregation(), null, "agregation", null, 1, 1, RequiredInterface.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getRequiredInterface_EventPort(), this.getEventPort(), null, "eventPort", null, 1, 1, RequiredInterface.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(providedInterfaceEClass, ProvidedInterface.class, "ProvidedInterface", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getProvidedInterface_Agregation(), this.getAgregation(), null, "agregation", null, 1, 1, ProvidedInterface.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getProvidedInterface_EventPort(), this.getEventPort(), null, "eventPort", null, 1, 1, ProvidedInterface.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(symptomAnalysisEEnum, SymptomAnalysis.class, "SymptomAnalysis");
		addEEnumLiteral(symptomAnalysisEEnum, SymptomAnalysis.DEGRADATION);
		addEEnumLiteral(symptomAnalysisEEnum, SymptomAnalysis.NO_DEGRADATION);

		initEEnum(adaptationActionTypeEEnum, AdaptationActionType.class, "AdaptationActionType");
		addEEnumLiteral(adaptationActionTypeEEnum, AdaptationActionType.PARAMERETRIC);
		addEEnumLiteral(adaptationActionTypeEEnum, AdaptationActionType.STRUCTURED);

		initEEnum(probesStateEEnum, ProbesState.class, "ProbesState");
		addEEnumLiteral(probesStateEEnum, ProbesState.ENABLED);
		addEEnumLiteral(probesStateEEnum, ProbesState.DISABLED);

		initEEnum(effectorstateEEnum, Effectorstate.class, "Effectorstate");
		addEEnumLiteral(effectorstateEEnum, Effectorstate.ACTIVE);
		addEEnumLiteral(effectorstateEEnum, Effectorstate.INACTIVE);

		// Create resource
		createResource(eNS_URI);
	}

} //CoordinatedControlProfilePackageImpl
