/**
 */
package CoordinatedControlProfile.impl;

import CoordinatedControlProfile.Agregation;
import CoordinatedControlProfile.ContextElement;
import CoordinatedControlProfile.CoordinatedControlProfilePackage;
import CoordinatedControlProfile.Effector;
import CoordinatedControlProfile.EventPort;
import CoordinatedControlProfile.ManagedElement;
import CoordinatedControlProfile.Manager;
import CoordinatedControlProfile.ObservedProperty;
import CoordinatedControlProfile.Probes;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Managed Element</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.impl.ManagedElementImpl#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagedElementImpl#getProbes <em>Probes</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagedElementImpl#getEffector <em>Effector</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagedElementImpl#getContextElement <em>Context Element</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagedElementImpl#getEventPort <em>Event Port</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagedElementImpl#getAgregation <em>Agregation</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagedElementImpl#getObservedProperty <em>Observed Property</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagedElementImpl#getManager <em>Manager</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ManagedElementImpl extends MinimalEObjectImpl.Container implements ManagedElement {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getProbes() <em>Probes</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProbes()
	 * @generated
	 * @ordered
	 */
	protected Probes probes;

	/**
	 * The cached value of the '{@link #getEffector() <em>Effector</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEffector()
	 * @generated
	 * @ordered
	 */
	protected Effector effector;

	/**
	 * The cached value of the '{@link #getContextElement() <em>Context Element</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContextElement()
	 * @generated
	 * @ordered
	 */
	protected ContextElement contextElement;

	/**
	 * The cached value of the '{@link #getEventPort() <em>Event Port</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEventPort()
	 * @generated
	 * @ordered
	 */
	protected EList<EventPort> eventPort;

	/**
	 * The cached value of the '{@link #getAgregation() <em>Agregation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgregation()
	 * @generated
	 * @ordered
	 */
	protected EList<Agregation> agregation;

	/**
	 * The cached value of the '{@link #getObservedProperty() <em>Observed Property</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObservedProperty()
	 * @generated
	 * @ordered
	 */
	protected EList<ObservedProperty> observedProperty;

	/**
	 * The cached value of the '{@link #getManager() <em>Manager</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getManager()
	 * @generated
	 * @ordered
	 */
	protected Manager manager;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ManagedElementImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CoordinatedControlProfilePackage.Literals.MANAGED_ELEMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGED_ELEMENT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Probes getProbes() {
		return probes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetProbes(Probes newProbes, NotificationChain msgs) {
		Probes oldProbes = probes;
		probes = newProbes;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGED_ELEMENT__PROBES, oldProbes, newProbes);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProbes(Probes newProbes) {
		if (newProbes != probes) {
			NotificationChain msgs = null;
			if (probes != null)
				msgs = ((InternalEObject)probes).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.MANAGED_ELEMENT__PROBES, null, msgs);
			if (newProbes != null)
				msgs = ((InternalEObject)newProbes).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.MANAGED_ELEMENT__PROBES, null, msgs);
			msgs = basicSetProbes(newProbes, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGED_ELEMENT__PROBES, newProbes, newProbes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Effector getEffector() {
		return effector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetEffector(Effector newEffector, NotificationChain msgs) {
		Effector oldEffector = effector;
		effector = newEffector;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGED_ELEMENT__EFFECTOR, oldEffector, newEffector);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEffector(Effector newEffector) {
		if (newEffector != effector) {
			NotificationChain msgs = null;
			if (effector != null)
				msgs = ((InternalEObject)effector).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.MANAGED_ELEMENT__EFFECTOR, null, msgs);
			if (newEffector != null)
				msgs = ((InternalEObject)newEffector).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.MANAGED_ELEMENT__EFFECTOR, null, msgs);
			msgs = basicSetEffector(newEffector, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGED_ELEMENT__EFFECTOR, newEffector, newEffector));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContextElement getContextElement() {
		return contextElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetContextElement(ContextElement newContextElement, NotificationChain msgs) {
		ContextElement oldContextElement = contextElement;
		contextElement = newContextElement;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGED_ELEMENT__CONTEXT_ELEMENT, oldContextElement, newContextElement);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setContextElement(ContextElement newContextElement) {
		if (newContextElement != contextElement) {
			NotificationChain msgs = null;
			if (contextElement != null)
				msgs = ((InternalEObject)contextElement).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.MANAGED_ELEMENT__CONTEXT_ELEMENT, null, msgs);
			if (newContextElement != null)
				msgs = ((InternalEObject)newContextElement).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.MANAGED_ELEMENT__CONTEXT_ELEMENT, null, msgs);
			msgs = basicSetContextElement(newContextElement, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGED_ELEMENT__CONTEXT_ELEMENT, newContextElement, newContextElement));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EventPort> getEventPort() {
		if (eventPort == null) {
			eventPort = new EObjectContainmentEList<EventPort>(EventPort.class, this, CoordinatedControlProfilePackage.MANAGED_ELEMENT__EVENT_PORT);
		}
		return eventPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Agregation> getAgregation() {
		if (agregation == null) {
			agregation = new EObjectContainmentEList<Agregation>(Agregation.class, this, CoordinatedControlProfilePackage.MANAGED_ELEMENT__AGREGATION);
		}
		return agregation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ObservedProperty> getObservedProperty() {
		if (observedProperty == null) {
			observedProperty = new EObjectContainmentEList<ObservedProperty>(ObservedProperty.class, this, CoordinatedControlProfilePackage.MANAGED_ELEMENT__OBSERVED_PROPERTY);
		}
		return observedProperty;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Manager getManager() {
		if (manager != null && manager.eIsProxy()) {
			InternalEObject oldManager = (InternalEObject)manager;
			manager = (Manager)eResolveProxy(oldManager);
			if (manager != oldManager) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CoordinatedControlProfilePackage.MANAGED_ELEMENT__MANAGER, oldManager, manager));
			}
		}
		return manager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Manager basicGetManager() {
		return manager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setManager(Manager newManager) {
		Manager oldManager = manager;
		manager = newManager;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGED_ELEMENT__MANAGER, oldManager, manager));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__PROBES:
				return basicSetProbes(null, msgs);
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__EFFECTOR:
				return basicSetEffector(null, msgs);
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__CONTEXT_ELEMENT:
				return basicSetContextElement(null, msgs);
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__EVENT_PORT:
				return ((InternalEList<?>)getEventPort()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__AGREGATION:
				return ((InternalEList<?>)getAgregation()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__OBSERVED_PROPERTY:
				return ((InternalEList<?>)getObservedProperty()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__NAME:
				return getName();
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__PROBES:
				return getProbes();
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__EFFECTOR:
				return getEffector();
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__CONTEXT_ELEMENT:
				return getContextElement();
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__EVENT_PORT:
				return getEventPort();
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__AGREGATION:
				return getAgregation();
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__OBSERVED_PROPERTY:
				return getObservedProperty();
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__MANAGER:
				if (resolve) return getManager();
				return basicGetManager();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__NAME:
				setName((String)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__PROBES:
				setProbes((Probes)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__EFFECTOR:
				setEffector((Effector)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__CONTEXT_ELEMENT:
				setContextElement((ContextElement)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__EVENT_PORT:
				getEventPort().clear();
				getEventPort().addAll((Collection<? extends EventPort>)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__AGREGATION:
				getAgregation().clear();
				getAgregation().addAll((Collection<? extends Agregation>)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__OBSERVED_PROPERTY:
				getObservedProperty().clear();
				getObservedProperty().addAll((Collection<? extends ObservedProperty>)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__MANAGER:
				setManager((Manager)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__NAME:
				setName(NAME_EDEFAULT);
				return;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__PROBES:
				setProbes((Probes)null);
				return;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__EFFECTOR:
				setEffector((Effector)null);
				return;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__CONTEXT_ELEMENT:
				setContextElement((ContextElement)null);
				return;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__EVENT_PORT:
				getEventPort().clear();
				return;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__AGREGATION:
				getAgregation().clear();
				return;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__OBSERVED_PROPERTY:
				getObservedProperty().clear();
				return;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__MANAGER:
				setManager((Manager)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__PROBES:
				return probes != null;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__EFFECTOR:
				return effector != null;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__CONTEXT_ELEMENT:
				return contextElement != null;
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__EVENT_PORT:
				return eventPort != null && !eventPort.isEmpty();
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__AGREGATION:
				return agregation != null && !agregation.isEmpty();
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__OBSERVED_PROPERTY:
				return observedProperty != null && !observedProperty.isEmpty();
			case CoordinatedControlProfilePackage.MANAGED_ELEMENT__MANAGER:
				return manager != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //ManagedElementImpl
