/**
 */
package CoordinatedControlProfile.impl;

import CoordinatedControlProfile.AdaptationActions;
import CoordinatedControlProfile.Agregation;
import CoordinatedControlProfile.Analyzer;
import CoordinatedControlProfile.CoordinatedControlProfilePackage;
import CoordinatedControlProfile.EventPort;
import CoordinatedControlProfile.Executor;
import CoordinatedControlProfile.Manager;
import CoordinatedControlProfile.Monitor;
import CoordinatedControlProfile.Planner;
import CoordinatedControlProfile.RFC;
import CoordinatedControlProfile.Symptom;
import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Manager</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.impl.ManagerImpl#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagerImpl#getMonitor <em>Monitor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagerImpl#getAnalyzer <em>Analyzer</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagerImpl#getPlanner <em>Planner</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagerImpl#getExecutor <em>Executor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagerImpl#getAdaptationActions <em>Adaptation Actions</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagerImpl#getRFC <em>RFC</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagerImpl#getSymptom <em>Symptom</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagerImpl#getEventPort <em>Event Port</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ManagerImpl#getAgregation <em>Agregation</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ManagerImpl extends MinimalEObjectImpl.Container implements Manager {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getMonitor() <em>Monitor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitor()
	 * @generated
	 * @ordered
	 */
	protected Monitor monitor;

	/**
	 * The cached value of the '{@link #getAnalyzer() <em>Analyzer</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnalyzer()
	 * @generated
	 * @ordered
	 */
	protected Analyzer analyzer;

	/**
	 * The cached value of the '{@link #getPlanner() <em>Planner</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlanner()
	 * @generated
	 * @ordered
	 */
	protected Planner planner;

	/**
	 * The cached value of the '{@link #getExecutor() <em>Executor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExecutor()
	 * @generated
	 * @ordered
	 */
	protected Executor executor;

	/**
	 * The cached value of the '{@link #getAdaptationActions() <em>Adaptation Actions</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAdaptationActions()
	 * @generated
	 * @ordered
	 */
	protected EList<AdaptationActions> adaptationActions;

	/**
	 * The cached value of the '{@link #getRFC() <em>RFC</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRFC()
	 * @generated
	 * @ordered
	 */
	protected EList<RFC> rFC;

	/**
	 * The cached value of the '{@link #getSymptom() <em>Symptom</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSymptom()
	 * @generated
	 * @ordered
	 */
	protected EList<Symptom> symptom;

	/**
	 * The cached value of the '{@link #getEventPort() <em>Event Port</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEventPort()
	 * @generated
	 * @ordered
	 */
	protected EList<EventPort> eventPort;

	/**
	 * The cached value of the '{@link #getAgregation() <em>Agregation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgregation()
	 * @generated
	 * @ordered
	 */
	protected EList<Agregation> agregation;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ManagerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CoordinatedControlProfilePackage.Literals.MANAGER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGER__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Monitor getMonitor() {
		return monitor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetMonitor(Monitor newMonitor, NotificationChain msgs) {
		Monitor oldMonitor = monitor;
		monitor = newMonitor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGER__MONITOR, oldMonitor, newMonitor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMonitor(Monitor newMonitor) {
		if (newMonitor != monitor) {
			NotificationChain msgs = null;
			if (monitor != null)
				msgs = ((InternalEObject)monitor).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.MANAGER__MONITOR, null, msgs);
			if (newMonitor != null)
				msgs = ((InternalEObject)newMonitor).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.MANAGER__MONITOR, null, msgs);
			msgs = basicSetMonitor(newMonitor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGER__MONITOR, newMonitor, newMonitor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Analyzer getAnalyzer() {
		return analyzer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAnalyzer(Analyzer newAnalyzer, NotificationChain msgs) {
		Analyzer oldAnalyzer = analyzer;
		analyzer = newAnalyzer;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGER__ANALYZER, oldAnalyzer, newAnalyzer);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAnalyzer(Analyzer newAnalyzer) {
		if (newAnalyzer != analyzer) {
			NotificationChain msgs = null;
			if (analyzer != null)
				msgs = ((InternalEObject)analyzer).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.MANAGER__ANALYZER, null, msgs);
			if (newAnalyzer != null)
				msgs = ((InternalEObject)newAnalyzer).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.MANAGER__ANALYZER, null, msgs);
			msgs = basicSetAnalyzer(newAnalyzer, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGER__ANALYZER, newAnalyzer, newAnalyzer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Planner getPlanner() {
		return planner;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPlanner(Planner newPlanner, NotificationChain msgs) {
		Planner oldPlanner = planner;
		planner = newPlanner;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGER__PLANNER, oldPlanner, newPlanner);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlanner(Planner newPlanner) {
		if (newPlanner != planner) {
			NotificationChain msgs = null;
			if (planner != null)
				msgs = ((InternalEObject)planner).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.MANAGER__PLANNER, null, msgs);
			if (newPlanner != null)
				msgs = ((InternalEObject)newPlanner).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.MANAGER__PLANNER, null, msgs);
			msgs = basicSetPlanner(newPlanner, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGER__PLANNER, newPlanner, newPlanner));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Executor getExecutor() {
		return executor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetExecutor(Executor newExecutor, NotificationChain msgs) {
		Executor oldExecutor = executor;
		executor = newExecutor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGER__EXECUTOR, oldExecutor, newExecutor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setExecutor(Executor newExecutor) {
		if (newExecutor != executor) {
			NotificationChain msgs = null;
			if (executor != null)
				msgs = ((InternalEObject)executor).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.MANAGER__EXECUTOR, null, msgs);
			if (newExecutor != null)
				msgs = ((InternalEObject)newExecutor).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.MANAGER__EXECUTOR, null, msgs);
			msgs = basicSetExecutor(newExecutor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.MANAGER__EXECUTOR, newExecutor, newExecutor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AdaptationActions> getAdaptationActions() {
		if (adaptationActions == null) {
			adaptationActions = new EObjectContainmentEList<AdaptationActions>(AdaptationActions.class, this, CoordinatedControlProfilePackage.MANAGER__ADAPTATION_ACTIONS);
		}
		return adaptationActions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RFC> getRFC() {
		if (rFC == null) {
			rFC = new EObjectContainmentEList<RFC>(RFC.class, this, CoordinatedControlProfilePackage.MANAGER__RFC);
		}
		return rFC;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Symptom> getSymptom() {
		if (symptom == null) {
			symptom = new EObjectContainmentEList<Symptom>(Symptom.class, this, CoordinatedControlProfilePackage.MANAGER__SYMPTOM);
		}
		return symptom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EventPort> getEventPort() {
		if (eventPort == null) {
			eventPort = new EObjectContainmentEList<EventPort>(EventPort.class, this, CoordinatedControlProfilePackage.MANAGER__EVENT_PORT);
		}
		return eventPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Agregation> getAgregation() {
		if (agregation == null) {
			agregation = new EObjectContainmentEList<Agregation>(Agregation.class, this, CoordinatedControlProfilePackage.MANAGER__AGREGATION);
		}
		return agregation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.MANAGER__MONITOR:
				return basicSetMonitor(null, msgs);
			case CoordinatedControlProfilePackage.MANAGER__ANALYZER:
				return basicSetAnalyzer(null, msgs);
			case CoordinatedControlProfilePackage.MANAGER__PLANNER:
				return basicSetPlanner(null, msgs);
			case CoordinatedControlProfilePackage.MANAGER__EXECUTOR:
				return basicSetExecutor(null, msgs);
			case CoordinatedControlProfilePackage.MANAGER__ADAPTATION_ACTIONS:
				return ((InternalEList<?>)getAdaptationActions()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.MANAGER__RFC:
				return ((InternalEList<?>)getRFC()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.MANAGER__SYMPTOM:
				return ((InternalEList<?>)getSymptom()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.MANAGER__EVENT_PORT:
				return ((InternalEList<?>)getEventPort()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.MANAGER__AGREGATION:
				return ((InternalEList<?>)getAgregation()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.MANAGER__NAME:
				return getName();
			case CoordinatedControlProfilePackage.MANAGER__MONITOR:
				return getMonitor();
			case CoordinatedControlProfilePackage.MANAGER__ANALYZER:
				return getAnalyzer();
			case CoordinatedControlProfilePackage.MANAGER__PLANNER:
				return getPlanner();
			case CoordinatedControlProfilePackage.MANAGER__EXECUTOR:
				return getExecutor();
			case CoordinatedControlProfilePackage.MANAGER__ADAPTATION_ACTIONS:
				return getAdaptationActions();
			case CoordinatedControlProfilePackage.MANAGER__RFC:
				return getRFC();
			case CoordinatedControlProfilePackage.MANAGER__SYMPTOM:
				return getSymptom();
			case CoordinatedControlProfilePackage.MANAGER__EVENT_PORT:
				return getEventPort();
			case CoordinatedControlProfilePackage.MANAGER__AGREGATION:
				return getAgregation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.MANAGER__NAME:
				setName((String)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGER__MONITOR:
				setMonitor((Monitor)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGER__ANALYZER:
				setAnalyzer((Analyzer)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGER__PLANNER:
				setPlanner((Planner)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGER__EXECUTOR:
				setExecutor((Executor)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGER__ADAPTATION_ACTIONS:
				getAdaptationActions().clear();
				getAdaptationActions().addAll((Collection<? extends AdaptationActions>)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGER__RFC:
				getRFC().clear();
				getRFC().addAll((Collection<? extends RFC>)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGER__SYMPTOM:
				getSymptom().clear();
				getSymptom().addAll((Collection<? extends Symptom>)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGER__EVENT_PORT:
				getEventPort().clear();
				getEventPort().addAll((Collection<? extends EventPort>)newValue);
				return;
			case CoordinatedControlProfilePackage.MANAGER__AGREGATION:
				getAgregation().clear();
				getAgregation().addAll((Collection<? extends Agregation>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.MANAGER__NAME:
				setName(NAME_EDEFAULT);
				return;
			case CoordinatedControlProfilePackage.MANAGER__MONITOR:
				setMonitor((Monitor)null);
				return;
			case CoordinatedControlProfilePackage.MANAGER__ANALYZER:
				setAnalyzer((Analyzer)null);
				return;
			case CoordinatedControlProfilePackage.MANAGER__PLANNER:
				setPlanner((Planner)null);
				return;
			case CoordinatedControlProfilePackage.MANAGER__EXECUTOR:
				setExecutor((Executor)null);
				return;
			case CoordinatedControlProfilePackage.MANAGER__ADAPTATION_ACTIONS:
				getAdaptationActions().clear();
				return;
			case CoordinatedControlProfilePackage.MANAGER__RFC:
				getRFC().clear();
				return;
			case CoordinatedControlProfilePackage.MANAGER__SYMPTOM:
				getSymptom().clear();
				return;
			case CoordinatedControlProfilePackage.MANAGER__EVENT_PORT:
				getEventPort().clear();
				return;
			case CoordinatedControlProfilePackage.MANAGER__AGREGATION:
				getAgregation().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.MANAGER__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case CoordinatedControlProfilePackage.MANAGER__MONITOR:
				return monitor != null;
			case CoordinatedControlProfilePackage.MANAGER__ANALYZER:
				return analyzer != null;
			case CoordinatedControlProfilePackage.MANAGER__PLANNER:
				return planner != null;
			case CoordinatedControlProfilePackage.MANAGER__EXECUTOR:
				return executor != null;
			case CoordinatedControlProfilePackage.MANAGER__ADAPTATION_ACTIONS:
				return adaptationActions != null && !adaptationActions.isEmpty();
			case CoordinatedControlProfilePackage.MANAGER__RFC:
				return rFC != null && !rFC.isEmpty();
			case CoordinatedControlProfilePackage.MANAGER__SYMPTOM:
				return symptom != null && !symptom.isEmpty();
			case CoordinatedControlProfilePackage.MANAGER__EVENT_PORT:
				return eventPort != null && !eventPort.isEmpty();
			case CoordinatedControlProfilePackage.MANAGER__AGREGATION:
				return agregation != null && !agregation.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //ManagerImpl
