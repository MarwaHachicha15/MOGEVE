/**
 */
package CoordinatedControlProfile.impl;

import CoordinatedControlProfile.AdaptationActions;
import CoordinatedControlProfile.Agregation;
import CoordinatedControlProfile.Analyzer;
import CoordinatedControlProfile.Commands;
import CoordinatedControlProfile.ContextElement;
import CoordinatedControlProfile.CoordinatedControl;
import CoordinatedControlProfile.CoordinatedControlProfilePackage;
import CoordinatedControlProfile.Effector;
import CoordinatedControlProfile.EventPort;
import CoordinatedControlProfile.Executor;
import CoordinatedControlProfile.IntracmpInteraction;
import CoordinatedControlProfile.ManagedElement;
import CoordinatedControlProfile.Manager;
import CoordinatedControlProfile.Monitor;
import CoordinatedControlProfile.MonitoringData;
import CoordinatedControlProfile.ObservedProperty;
import CoordinatedControlProfile.PS;
import CoordinatedControlProfile.Planner;
import CoordinatedControlProfile.Probes;
import CoordinatedControlProfile.Processor;
import CoordinatedControlProfile.ProvidedInterface;
import CoordinatedControlProfile.RFC;
import CoordinatedControlProfile.RP;
import CoordinatedControlProfile.Receiver;
import CoordinatedControlProfile.RequiredInterface;
import CoordinatedControlProfile.Sender;
import CoordinatedControlProfile.Symptom;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Coordinated Control</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getManager <em>Manager</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getManagedElement <em>Managed Element</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getProbes <em>Probes</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getContextElement <em>Context Element</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getEffector <em>Effector</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getMonitor <em>Monitor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getAnalyzer <em>Analyzer</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getPlanner <em>Planner</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getExecutor <em>Executor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getIntracmpInteraction <em>Intracmp Interaction</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getReceiver <em>Receiver</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getProcessor <em>Processor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getSender <em>Sender</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getPS <em>PS</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getRP <em>RP</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getMonitoringData <em>Monitoring Data</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getAdaptationActions <em>Adaptation Actions</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getCommands <em>Commands</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getRFC <em>RFC</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getObservedProperty <em>Observed Property</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getSymptom <em>Symptom</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getAgregation <em>Agregation</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getRequiredInterface <em>Required Interface</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getProvidedInterface <em>Provided Interface</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.CoordinatedControlImpl#getEventPort <em>Event Port</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class CoordinatedControlImpl extends MinimalEObjectImpl.Container implements CoordinatedControl {
	/**
	 * The cached value of the '{@link #getManager() <em>Manager</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getManager()
	 * @generated
	 * @ordered
	 */
	protected EList<Manager> manager;

	/**
	 * The cached value of the '{@link #getManagedElement() <em>Managed Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getManagedElement()
	 * @generated
	 * @ordered
	 */
	protected EList<ManagedElement> managedElement;

	/**
	 * The cached value of the '{@link #getProbes() <em>Probes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProbes()
	 * @generated
	 * @ordered
	 */
	protected EList<Probes> probes;

	/**
	 * The cached value of the '{@link #getContextElement() <em>Context Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContextElement()
	 * @generated
	 * @ordered
	 */
	protected EList<ContextElement> contextElement;

	/**
	 * The cached value of the '{@link #getEffector() <em>Effector</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEffector()
	 * @generated
	 * @ordered
	 */
	protected EList<Effector> effector;

	/**
	 * The cached value of the '{@link #getMonitor() <em>Monitor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitor()
	 * @generated
	 * @ordered
	 */
	protected Monitor monitor;

	/**
	 * The cached value of the '{@link #getAnalyzer() <em>Analyzer</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnalyzer()
	 * @generated
	 * @ordered
	 */
	protected Analyzer analyzer;

	/**
	 * The cached value of the '{@link #getPlanner() <em>Planner</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlanner()
	 * @generated
	 * @ordered
	 */
	protected Planner planner;

	/**
	 * The cached value of the '{@link #getExecutor() <em>Executor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExecutor()
	 * @generated
	 * @ordered
	 */
	protected Executor executor;

	/**
	 * The cached value of the '{@link #getIntracmpInteraction() <em>Intracmp Interaction</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIntracmpInteraction()
	 * @generated
	 * @ordered
	 */
	protected EList<IntracmpInteraction> intracmpInteraction;

	/**
	 * The cached value of the '{@link #getReceiver() <em>Receiver</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReceiver()
	 * @generated
	 * @ordered
	 */
	protected Receiver receiver;

	/**
	 * The cached value of the '{@link #getProcessor() <em>Processor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProcessor()
	 * @generated
	 * @ordered
	 */
	protected Processor processor;

	/**
	 * The cached value of the '{@link #getSender() <em>Sender</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSender()
	 * @generated
	 * @ordered
	 */
	protected Sender sender;

	/**
	 * The cached value of the '{@link #getPS() <em>PS</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPS()
	 * @generated
	 * @ordered
	 */
	protected EList<PS> pS;

	/**
	 * The cached value of the '{@link #getRP() <em>RP</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRP()
	 * @generated
	 * @ordered
	 */
	protected EList<RP> rP;

	/**
	 * The cached value of the '{@link #getMonitoringData() <em>Monitoring Data</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitoringData()
	 * @generated
	 * @ordered
	 */
	protected EList<MonitoringData> monitoringData;

	/**
	 * The cached value of the '{@link #getAdaptationActions() <em>Adaptation Actions</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAdaptationActions()
	 * @generated
	 * @ordered
	 */
	protected EList<AdaptationActions> adaptationActions;

	/**
	 * The cached value of the '{@link #getCommands() <em>Commands</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCommands()
	 * @generated
	 * @ordered
	 */
	protected EList<Commands> commands;

	/**
	 * The cached value of the '{@link #getRFC() <em>RFC</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRFC()
	 * @generated
	 * @ordered
	 */
	protected EList<RFC> rFC;

	/**
	 * The cached value of the '{@link #getObservedProperty() <em>Observed Property</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObservedProperty()
	 * @generated
	 * @ordered
	 */
	protected EList<ObservedProperty> observedProperty;

	/**
	 * The cached value of the '{@link #getSymptom() <em>Symptom</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSymptom()
	 * @generated
	 * @ordered
	 */
	protected EList<Symptom> symptom;

	/**
	 * The cached value of the '{@link #getAgregation() <em>Agregation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgregation()
	 * @generated
	 * @ordered
	 */
	protected EList<Agregation> agregation;

	/**
	 * The cached value of the '{@link #getRequiredInterface() <em>Required Interface</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRequiredInterface()
	 * @generated
	 * @ordered
	 */
	protected EList<RequiredInterface> requiredInterface;

	/**
	 * The cached value of the '{@link #getProvidedInterface() <em>Provided Interface</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProvidedInterface()
	 * @generated
	 * @ordered
	 */
	protected EList<ProvidedInterface> providedInterface;

	/**
	 * The cached value of the '{@link #getEventPort() <em>Event Port</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEventPort()
	 * @generated
	 * @ordered
	 */
	protected EList<EventPort> eventPort;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CoordinatedControlImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CoordinatedControlProfilePackage.Literals.COORDINATED_CONTROL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Manager> getManager() {
		if (manager == null) {
			manager = new EObjectContainmentEList<Manager>(Manager.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__MANAGER);
		}
		return manager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ManagedElement> getManagedElement() {
		if (managedElement == null) {
			managedElement = new EObjectContainmentEList<ManagedElement>(ManagedElement.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__MANAGED_ELEMENT);
		}
		return managedElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Probes> getProbes() {
		if (probes == null) {
			probes = new EObjectContainmentEList<Probes>(Probes.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROBES);
		}
		return probes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ContextElement> getContextElement() {
		if (contextElement == null) {
			contextElement = new EObjectContainmentEList<ContextElement>(ContextElement.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__CONTEXT_ELEMENT);
		}
		return contextElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Effector> getEffector() {
		if (effector == null) {
			effector = new EObjectContainmentEList<Effector>(Effector.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__EFFECTOR);
		}
		return effector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Monitor getMonitor() {
		return monitor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetMonitor(Monitor newMonitor, NotificationChain msgs) {
		Monitor oldMonitor = monitor;
		monitor = newMonitor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITOR, oldMonitor, newMonitor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMonitor(Monitor newMonitor) {
		if (newMonitor != monitor) {
			NotificationChain msgs = null;
			if (monitor != null)
				msgs = ((InternalEObject)monitor).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITOR, null, msgs);
			if (newMonitor != null)
				msgs = ((InternalEObject)newMonitor).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITOR, null, msgs);
			msgs = basicSetMonitor(newMonitor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITOR, newMonitor, newMonitor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Analyzer getAnalyzer() {
		return analyzer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAnalyzer(Analyzer newAnalyzer, NotificationChain msgs) {
		Analyzer oldAnalyzer = analyzer;
		analyzer = newAnalyzer;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.COORDINATED_CONTROL__ANALYZER, oldAnalyzer, newAnalyzer);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAnalyzer(Analyzer newAnalyzer) {
		if (newAnalyzer != analyzer) {
			NotificationChain msgs = null;
			if (analyzer != null)
				msgs = ((InternalEObject)analyzer).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.COORDINATED_CONTROL__ANALYZER, null, msgs);
			if (newAnalyzer != null)
				msgs = ((InternalEObject)newAnalyzer).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.COORDINATED_CONTROL__ANALYZER, null, msgs);
			msgs = basicSetAnalyzer(newAnalyzer, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.COORDINATED_CONTROL__ANALYZER, newAnalyzer, newAnalyzer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Planner getPlanner() {
		return planner;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPlanner(Planner newPlanner, NotificationChain msgs) {
		Planner oldPlanner = planner;
		planner = newPlanner;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.COORDINATED_CONTROL__PLANNER, oldPlanner, newPlanner);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlanner(Planner newPlanner) {
		if (newPlanner != planner) {
			NotificationChain msgs = null;
			if (planner != null)
				msgs = ((InternalEObject)planner).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.COORDINATED_CONTROL__PLANNER, null, msgs);
			if (newPlanner != null)
				msgs = ((InternalEObject)newPlanner).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.COORDINATED_CONTROL__PLANNER, null, msgs);
			msgs = basicSetPlanner(newPlanner, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.COORDINATED_CONTROL__PLANNER, newPlanner, newPlanner));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Executor getExecutor() {
		return executor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetExecutor(Executor newExecutor, NotificationChain msgs) {
		Executor oldExecutor = executor;
		executor = newExecutor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.COORDINATED_CONTROL__EXECUTOR, oldExecutor, newExecutor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setExecutor(Executor newExecutor) {
		if (newExecutor != executor) {
			NotificationChain msgs = null;
			if (executor != null)
				msgs = ((InternalEObject)executor).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.COORDINATED_CONTROL__EXECUTOR, null, msgs);
			if (newExecutor != null)
				msgs = ((InternalEObject)newExecutor).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.COORDINATED_CONTROL__EXECUTOR, null, msgs);
			msgs = basicSetExecutor(newExecutor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.COORDINATED_CONTROL__EXECUTOR, newExecutor, newExecutor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<IntracmpInteraction> getIntracmpInteraction() {
		if (intracmpInteraction == null) {
			intracmpInteraction = new EObjectContainmentEList<IntracmpInteraction>(IntracmpInteraction.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__INTRACMP_INTERACTION);
		}
		return intracmpInteraction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Receiver getReceiver() {
		return receiver;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetReceiver(Receiver newReceiver, NotificationChain msgs) {
		Receiver oldReceiver = receiver;
		receiver = newReceiver;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.COORDINATED_CONTROL__RECEIVER, oldReceiver, newReceiver);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReceiver(Receiver newReceiver) {
		if (newReceiver != receiver) {
			NotificationChain msgs = null;
			if (receiver != null)
				msgs = ((InternalEObject)receiver).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.COORDINATED_CONTROL__RECEIVER, null, msgs);
			if (newReceiver != null)
				msgs = ((InternalEObject)newReceiver).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.COORDINATED_CONTROL__RECEIVER, null, msgs);
			msgs = basicSetReceiver(newReceiver, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.COORDINATED_CONTROL__RECEIVER, newReceiver, newReceiver));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Processor getProcessor() {
		return processor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetProcessor(Processor newProcessor, NotificationChain msgs) {
		Processor oldProcessor = processor;
		processor = newProcessor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROCESSOR, oldProcessor, newProcessor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProcessor(Processor newProcessor) {
		if (newProcessor != processor) {
			NotificationChain msgs = null;
			if (processor != null)
				msgs = ((InternalEObject)processor).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROCESSOR, null, msgs);
			if (newProcessor != null)
				msgs = ((InternalEObject)newProcessor).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROCESSOR, null, msgs);
			msgs = basicSetProcessor(newProcessor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROCESSOR, newProcessor, newProcessor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Sender getSender() {
		return sender;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSender(Sender newSender, NotificationChain msgs) {
		Sender oldSender = sender;
		sender = newSender;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.COORDINATED_CONTROL__SENDER, oldSender, newSender);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSender(Sender newSender) {
		if (newSender != sender) {
			NotificationChain msgs = null;
			if (sender != null)
				msgs = ((InternalEObject)sender).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.COORDINATED_CONTROL__SENDER, null, msgs);
			if (newSender != null)
				msgs = ((InternalEObject)newSender).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.COORDINATED_CONTROL__SENDER, null, msgs);
			msgs = basicSetSender(newSender, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.COORDINATED_CONTROL__SENDER, newSender, newSender));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PS> getPS() {
		if (pS == null) {
			pS = new EObjectContainmentEList<PS>(PS.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__PS);
		}
		return pS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RP> getRP() {
		if (rP == null) {
			rP = new EObjectContainmentEList<RP>(RP.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__RP);
		}
		return rP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<MonitoringData> getMonitoringData() {
		if (monitoringData == null) {
			monitoringData = new EObjectContainmentEList<MonitoringData>(MonitoringData.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITORING_DATA);
		}
		return monitoringData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AdaptationActions> getAdaptationActions() {
		if (adaptationActions == null) {
			adaptationActions = new EObjectContainmentEList<AdaptationActions>(AdaptationActions.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__ADAPTATION_ACTIONS);
		}
		return adaptationActions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Commands> getCommands() {
		if (commands == null) {
			commands = new EObjectContainmentEList<Commands>(Commands.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__COMMANDS);
		}
		return commands;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RFC> getRFC() {
		if (rFC == null) {
			rFC = new EObjectContainmentEList<RFC>(RFC.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__RFC);
		}
		return rFC;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ObservedProperty> getObservedProperty() {
		if (observedProperty == null) {
			observedProperty = new EObjectContainmentEList<ObservedProperty>(ObservedProperty.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__OBSERVED_PROPERTY);
		}
		return observedProperty;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Symptom> getSymptom() {
		if (symptom == null) {
			symptom = new EObjectContainmentEList<Symptom>(Symptom.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__SYMPTOM);
		}
		return symptom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Agregation> getAgregation() {
		if (agregation == null) {
			agregation = new EObjectContainmentEList<Agregation>(Agregation.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__AGREGATION);
		}
		return agregation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RequiredInterface> getRequiredInterface() {
		if (requiredInterface == null) {
			requiredInterface = new EObjectContainmentEList<RequiredInterface>(RequiredInterface.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__REQUIRED_INTERFACE);
		}
		return requiredInterface;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ProvidedInterface> getProvidedInterface() {
		if (providedInterface == null) {
			providedInterface = new EObjectContainmentEList<ProvidedInterface>(ProvidedInterface.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROVIDED_INTERFACE);
		}
		return providedInterface;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EventPort> getEventPort() {
		if (eventPort == null) {
			eventPort = new EObjectContainmentEList<EventPort>(EventPort.class, this, CoordinatedControlProfilePackage.COORDINATED_CONTROL__EVENT_PORT);
		}
		return eventPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MANAGER:
				return ((InternalEList<?>)getManager()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MANAGED_ELEMENT:
				return ((InternalEList<?>)getManagedElement()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROBES:
				return ((InternalEList<?>)getProbes()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__CONTEXT_ELEMENT:
				return ((InternalEList<?>)getContextElement()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EFFECTOR:
				return ((InternalEList<?>)getEffector()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITOR:
				return basicSetMonitor(null, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__ANALYZER:
				return basicSetAnalyzer(null, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PLANNER:
				return basicSetPlanner(null, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EXECUTOR:
				return basicSetExecutor(null, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__INTRACMP_INTERACTION:
				return ((InternalEList<?>)getIntracmpInteraction()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RECEIVER:
				return basicSetReceiver(null, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROCESSOR:
				return basicSetProcessor(null, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__SENDER:
				return basicSetSender(null, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PS:
				return ((InternalEList<?>)getPS()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RP:
				return ((InternalEList<?>)getRP()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITORING_DATA:
				return ((InternalEList<?>)getMonitoringData()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__ADAPTATION_ACTIONS:
				return ((InternalEList<?>)getAdaptationActions()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__COMMANDS:
				return ((InternalEList<?>)getCommands()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RFC:
				return ((InternalEList<?>)getRFC()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__OBSERVED_PROPERTY:
				return ((InternalEList<?>)getObservedProperty()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__SYMPTOM:
				return ((InternalEList<?>)getSymptom()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__AGREGATION:
				return ((InternalEList<?>)getAgregation()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__REQUIRED_INTERFACE:
				return ((InternalEList<?>)getRequiredInterface()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROVIDED_INTERFACE:
				return ((InternalEList<?>)getProvidedInterface()).basicRemove(otherEnd, msgs);
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EVENT_PORT:
				return ((InternalEList<?>)getEventPort()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MANAGER:
				return getManager();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MANAGED_ELEMENT:
				return getManagedElement();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROBES:
				return getProbes();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__CONTEXT_ELEMENT:
				return getContextElement();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EFFECTOR:
				return getEffector();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITOR:
				return getMonitor();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__ANALYZER:
				return getAnalyzer();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PLANNER:
				return getPlanner();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EXECUTOR:
				return getExecutor();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__INTRACMP_INTERACTION:
				return getIntracmpInteraction();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RECEIVER:
				return getReceiver();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROCESSOR:
				return getProcessor();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__SENDER:
				return getSender();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PS:
				return getPS();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RP:
				return getRP();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITORING_DATA:
				return getMonitoringData();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__ADAPTATION_ACTIONS:
				return getAdaptationActions();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__COMMANDS:
				return getCommands();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RFC:
				return getRFC();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__OBSERVED_PROPERTY:
				return getObservedProperty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__SYMPTOM:
				return getSymptom();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__AGREGATION:
				return getAgregation();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__REQUIRED_INTERFACE:
				return getRequiredInterface();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROVIDED_INTERFACE:
				return getProvidedInterface();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EVENT_PORT:
				return getEventPort();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MANAGER:
				getManager().clear();
				getManager().addAll((Collection<? extends Manager>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MANAGED_ELEMENT:
				getManagedElement().clear();
				getManagedElement().addAll((Collection<? extends ManagedElement>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROBES:
				getProbes().clear();
				getProbes().addAll((Collection<? extends Probes>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__CONTEXT_ELEMENT:
				getContextElement().clear();
				getContextElement().addAll((Collection<? extends ContextElement>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EFFECTOR:
				getEffector().clear();
				getEffector().addAll((Collection<? extends Effector>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITOR:
				setMonitor((Monitor)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__ANALYZER:
				setAnalyzer((Analyzer)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PLANNER:
				setPlanner((Planner)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EXECUTOR:
				setExecutor((Executor)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__INTRACMP_INTERACTION:
				getIntracmpInteraction().clear();
				getIntracmpInteraction().addAll((Collection<? extends IntracmpInteraction>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RECEIVER:
				setReceiver((Receiver)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROCESSOR:
				setProcessor((Processor)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__SENDER:
				setSender((Sender)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PS:
				getPS().clear();
				getPS().addAll((Collection<? extends PS>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RP:
				getRP().clear();
				getRP().addAll((Collection<? extends RP>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITORING_DATA:
				getMonitoringData().clear();
				getMonitoringData().addAll((Collection<? extends MonitoringData>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__ADAPTATION_ACTIONS:
				getAdaptationActions().clear();
				getAdaptationActions().addAll((Collection<? extends AdaptationActions>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__COMMANDS:
				getCommands().clear();
				getCommands().addAll((Collection<? extends Commands>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RFC:
				getRFC().clear();
				getRFC().addAll((Collection<? extends RFC>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__OBSERVED_PROPERTY:
				getObservedProperty().clear();
				getObservedProperty().addAll((Collection<? extends ObservedProperty>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__SYMPTOM:
				getSymptom().clear();
				getSymptom().addAll((Collection<? extends Symptom>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__AGREGATION:
				getAgregation().clear();
				getAgregation().addAll((Collection<? extends Agregation>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__REQUIRED_INTERFACE:
				getRequiredInterface().clear();
				getRequiredInterface().addAll((Collection<? extends RequiredInterface>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROVIDED_INTERFACE:
				getProvidedInterface().clear();
				getProvidedInterface().addAll((Collection<? extends ProvidedInterface>)newValue);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EVENT_PORT:
				getEventPort().clear();
				getEventPort().addAll((Collection<? extends EventPort>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MANAGER:
				getManager().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MANAGED_ELEMENT:
				getManagedElement().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROBES:
				getProbes().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__CONTEXT_ELEMENT:
				getContextElement().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EFFECTOR:
				getEffector().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITOR:
				setMonitor((Monitor)null);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__ANALYZER:
				setAnalyzer((Analyzer)null);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PLANNER:
				setPlanner((Planner)null);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EXECUTOR:
				setExecutor((Executor)null);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__INTRACMP_INTERACTION:
				getIntracmpInteraction().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RECEIVER:
				setReceiver((Receiver)null);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROCESSOR:
				setProcessor((Processor)null);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__SENDER:
				setSender((Sender)null);
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PS:
				getPS().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RP:
				getRP().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITORING_DATA:
				getMonitoringData().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__ADAPTATION_ACTIONS:
				getAdaptationActions().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__COMMANDS:
				getCommands().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RFC:
				getRFC().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__OBSERVED_PROPERTY:
				getObservedProperty().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__SYMPTOM:
				getSymptom().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__AGREGATION:
				getAgregation().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__REQUIRED_INTERFACE:
				getRequiredInterface().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROVIDED_INTERFACE:
				getProvidedInterface().clear();
				return;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EVENT_PORT:
				getEventPort().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MANAGER:
				return manager != null && !manager.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MANAGED_ELEMENT:
				return managedElement != null && !managedElement.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROBES:
				return probes != null && !probes.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__CONTEXT_ELEMENT:
				return contextElement != null && !contextElement.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EFFECTOR:
				return effector != null && !effector.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITOR:
				return monitor != null;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__ANALYZER:
				return analyzer != null;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PLANNER:
				return planner != null;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EXECUTOR:
				return executor != null;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__INTRACMP_INTERACTION:
				return intracmpInteraction != null && !intracmpInteraction.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RECEIVER:
				return receiver != null;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROCESSOR:
				return processor != null;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__SENDER:
				return sender != null;
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PS:
				return pS != null && !pS.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RP:
				return rP != null && !rP.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__MONITORING_DATA:
				return monitoringData != null && !monitoringData.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__ADAPTATION_ACTIONS:
				return adaptationActions != null && !adaptationActions.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__COMMANDS:
				return commands != null && !commands.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__RFC:
				return rFC != null && !rFC.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__OBSERVED_PROPERTY:
				return observedProperty != null && !observedProperty.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__SYMPTOM:
				return symptom != null && !symptom.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__AGREGATION:
				return agregation != null && !agregation.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__REQUIRED_INTERFACE:
				return requiredInterface != null && !requiredInterface.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__PROVIDED_INTERFACE:
				return providedInterface != null && !providedInterface.isEmpty();
			case CoordinatedControlProfilePackage.COORDINATED_CONTROL__EVENT_PORT:
				return eventPort != null && !eventPort.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //CoordinatedControlImpl
