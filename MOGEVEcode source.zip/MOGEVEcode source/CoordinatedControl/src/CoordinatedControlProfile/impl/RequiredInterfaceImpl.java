/**
 */
package CoordinatedControlProfile.impl;

import CoordinatedControlProfile.Agregation;
import CoordinatedControlProfile.CoordinatedControlProfilePackage;
import CoordinatedControlProfile.EventPort;
import CoordinatedControlProfile.RequiredInterface;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Required Interface</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.impl.RequiredInterfaceImpl#getAgregation <em>Agregation</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.RequiredInterfaceImpl#getEventPort <em>Event Port</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class RequiredInterfaceImpl extends MinimalEObjectImpl.Container implements RequiredInterface {
	/**
	 * The cached value of the '{@link #getAgregation() <em>Agregation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgregation()
	 * @generated
	 * @ordered
	 */
	protected Agregation agregation;

	/**
	 * The cached value of the '{@link #getEventPort() <em>Event Port</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEventPort()
	 * @generated
	 * @ordered
	 */
	protected EventPort eventPort;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RequiredInterfaceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CoordinatedControlProfilePackage.Literals.REQUIRED_INTERFACE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Agregation getAgregation() {
		if (agregation != null && agregation.eIsProxy()) {
			InternalEObject oldAgregation = (InternalEObject)agregation;
			agregation = (Agregation)eResolveProxy(oldAgregation);
			if (agregation != oldAgregation) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CoordinatedControlProfilePackage.REQUIRED_INTERFACE__AGREGATION, oldAgregation, agregation));
			}
		}
		return agregation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Agregation basicGetAgregation() {
		return agregation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAgregation(Agregation newAgregation) {
		Agregation oldAgregation = agregation;
		agregation = newAgregation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.REQUIRED_INTERFACE__AGREGATION, oldAgregation, agregation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EventPort getEventPort() {
		if (eventPort != null && eventPort.eIsProxy()) {
			InternalEObject oldEventPort = (InternalEObject)eventPort;
			eventPort = (EventPort)eResolveProxy(oldEventPort);
			if (eventPort != oldEventPort) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CoordinatedControlProfilePackage.REQUIRED_INTERFACE__EVENT_PORT, oldEventPort, eventPort));
			}
		}
		return eventPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EventPort basicGetEventPort() {
		return eventPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEventPort(EventPort newEventPort) {
		EventPort oldEventPort = eventPort;
		eventPort = newEventPort;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.REQUIRED_INTERFACE__EVENT_PORT, oldEventPort, eventPort));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.REQUIRED_INTERFACE__AGREGATION:
				if (resolve) return getAgregation();
				return basicGetAgregation();
			case CoordinatedControlProfilePackage.REQUIRED_INTERFACE__EVENT_PORT:
				if (resolve) return getEventPort();
				return basicGetEventPort();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.REQUIRED_INTERFACE__AGREGATION:
				setAgregation((Agregation)newValue);
				return;
			case CoordinatedControlProfilePackage.REQUIRED_INTERFACE__EVENT_PORT:
				setEventPort((EventPort)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.REQUIRED_INTERFACE__AGREGATION:
				setAgregation((Agregation)null);
				return;
			case CoordinatedControlProfilePackage.REQUIRED_INTERFACE__EVENT_PORT:
				setEventPort((EventPort)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.REQUIRED_INTERFACE__AGREGATION:
				return agregation != null;
			case CoordinatedControlProfilePackage.REQUIRED_INTERFACE__EVENT_PORT:
				return eventPort != null;
		}
		return super.eIsSet(featureID);
	}

} //RequiredInterfaceImpl
