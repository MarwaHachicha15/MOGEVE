/**
 */
package CoordinatedControlProfile.impl;

import CoordinatedControlProfile.Analyzer;
import CoordinatedControlProfile.CoordinatedControlProfilePackage;
import CoordinatedControlProfile.Processor;
import CoordinatedControlProfile.Receiver;
import CoordinatedControlProfile.Sender;
import CoordinatedControlProfile.SymptomAnalysis;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Analyzer</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.impl.AnalyzerImpl#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.AnalyzerImpl#getSymptomAnalysis <em>Symptom Analysis</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.AnalyzerImpl#getThersholdMIN <em>Thershold MIN</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.AnalyzerImpl#getThersholdMAX <em>Thershold MAX</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.AnalyzerImpl#getReceiver <em>Receiver</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.AnalyzerImpl#getProcessor <em>Processor</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.AnalyzerImpl#getSender <em>Sender</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AnalyzerImpl extends MinimalEObjectImpl.Container implements Analyzer {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getSymptomAnalysis() <em>Symptom Analysis</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSymptomAnalysis()
	 * @generated
	 * @ordered
	 */
	protected static final SymptomAnalysis SYMPTOM_ANALYSIS_EDEFAULT = SymptomAnalysis.DEGRADATION;

	/**
	 * The cached value of the '{@link #getSymptomAnalysis() <em>Symptom Analysis</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSymptomAnalysis()
	 * @generated
	 * @ordered
	 */
	protected SymptomAnalysis symptomAnalysis = SYMPTOM_ANALYSIS_EDEFAULT;

	/**
	 * The default value of the '{@link #getThersholdMIN() <em>Thershold MIN</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThersholdMIN()
	 * @generated
	 * @ordered
	 */
	protected static final int THERSHOLD_MIN_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getThersholdMIN() <em>Thershold MIN</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThersholdMIN()
	 * @generated
	 * @ordered
	 */
	protected int thersholdMIN = THERSHOLD_MIN_EDEFAULT;

	/**
	 * The default value of the '{@link #getThersholdMAX() <em>Thershold MAX</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThersholdMAX()
	 * @generated
	 * @ordered
	 */
	protected static final int THERSHOLD_MAX_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getThersholdMAX() <em>Thershold MAX</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThersholdMAX()
	 * @generated
	 * @ordered
	 */
	protected int thersholdMAX = THERSHOLD_MAX_EDEFAULT;

	/**
	 * The cached value of the '{@link #getReceiver() <em>Receiver</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReceiver()
	 * @generated
	 * @ordered
	 */
	protected Receiver receiver;

	/**
	 * The cached value of the '{@link #getProcessor() <em>Processor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProcessor()
	 * @generated
	 * @ordered
	 */
	protected Processor processor;

	/**
	 * The cached value of the '{@link #getSender() <em>Sender</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSender()
	 * @generated
	 * @ordered
	 */
	protected Sender sender;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AnalyzerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CoordinatedControlProfilePackage.Literals.ANALYZER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.ANALYZER__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SymptomAnalysis getSymptomAnalysis() {
		return symptomAnalysis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSymptomAnalysis(SymptomAnalysis newSymptomAnalysis) {
		SymptomAnalysis oldSymptomAnalysis = symptomAnalysis;
		symptomAnalysis = newSymptomAnalysis == null ? SYMPTOM_ANALYSIS_EDEFAULT : newSymptomAnalysis;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.ANALYZER__SYMPTOM_ANALYSIS, oldSymptomAnalysis, symptomAnalysis));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getThersholdMIN() {
		return thersholdMIN;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setThersholdMIN(int newThersholdMIN) {
		int oldThersholdMIN = thersholdMIN;
		thersholdMIN = newThersholdMIN;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.ANALYZER__THERSHOLD_MIN, oldThersholdMIN, thersholdMIN));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getThersholdMAX() {
		return thersholdMAX;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setThersholdMAX(int newThersholdMAX) {
		int oldThersholdMAX = thersholdMAX;
		thersholdMAX = newThersholdMAX;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.ANALYZER__THERSHOLD_MAX, oldThersholdMAX, thersholdMAX));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Receiver getReceiver() {
		return receiver;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetReceiver(Receiver newReceiver, NotificationChain msgs) {
		Receiver oldReceiver = receiver;
		receiver = newReceiver;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.ANALYZER__RECEIVER, oldReceiver, newReceiver);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReceiver(Receiver newReceiver) {
		if (newReceiver != receiver) {
			NotificationChain msgs = null;
			if (receiver != null)
				msgs = ((InternalEObject)receiver).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.ANALYZER__RECEIVER, null, msgs);
			if (newReceiver != null)
				msgs = ((InternalEObject)newReceiver).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.ANALYZER__RECEIVER, null, msgs);
			msgs = basicSetReceiver(newReceiver, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.ANALYZER__RECEIVER, newReceiver, newReceiver));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Processor getProcessor() {
		return processor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetProcessor(Processor newProcessor, NotificationChain msgs) {
		Processor oldProcessor = processor;
		processor = newProcessor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.ANALYZER__PROCESSOR, oldProcessor, newProcessor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProcessor(Processor newProcessor) {
		if (newProcessor != processor) {
			NotificationChain msgs = null;
			if (processor != null)
				msgs = ((InternalEObject)processor).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.ANALYZER__PROCESSOR, null, msgs);
			if (newProcessor != null)
				msgs = ((InternalEObject)newProcessor).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.ANALYZER__PROCESSOR, null, msgs);
			msgs = basicSetProcessor(newProcessor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.ANALYZER__PROCESSOR, newProcessor, newProcessor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Sender getSender() {
		return sender;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSender(Sender newSender, NotificationChain msgs) {
		Sender oldSender = sender;
		sender = newSender;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.ANALYZER__SENDER, oldSender, newSender);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSender(Sender newSender) {
		if (newSender != sender) {
			NotificationChain msgs = null;
			if (sender != null)
				msgs = ((InternalEObject)sender).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.ANALYZER__SENDER, null, msgs);
			if (newSender != null)
				msgs = ((InternalEObject)newSender).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CoordinatedControlProfilePackage.ANALYZER__SENDER, null, msgs);
			msgs = basicSetSender(newSender, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.ANALYZER__SENDER, newSender, newSender));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.ANALYZER__RECEIVER:
				return basicSetReceiver(null, msgs);
			case CoordinatedControlProfilePackage.ANALYZER__PROCESSOR:
				return basicSetProcessor(null, msgs);
			case CoordinatedControlProfilePackage.ANALYZER__SENDER:
				return basicSetSender(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.ANALYZER__NAME:
				return getName();
			case CoordinatedControlProfilePackage.ANALYZER__SYMPTOM_ANALYSIS:
				return getSymptomAnalysis();
			case CoordinatedControlProfilePackage.ANALYZER__THERSHOLD_MIN:
				return getThersholdMIN();
			case CoordinatedControlProfilePackage.ANALYZER__THERSHOLD_MAX:
				return getThersholdMAX();
			case CoordinatedControlProfilePackage.ANALYZER__RECEIVER:
				return getReceiver();
			case CoordinatedControlProfilePackage.ANALYZER__PROCESSOR:
				return getProcessor();
			case CoordinatedControlProfilePackage.ANALYZER__SENDER:
				return getSender();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.ANALYZER__NAME:
				setName((String)newValue);
				return;
			case CoordinatedControlProfilePackage.ANALYZER__SYMPTOM_ANALYSIS:
				setSymptomAnalysis((SymptomAnalysis)newValue);
				return;
			case CoordinatedControlProfilePackage.ANALYZER__THERSHOLD_MIN:
				setThersholdMIN((Integer)newValue);
				return;
			case CoordinatedControlProfilePackage.ANALYZER__THERSHOLD_MAX:
				setThersholdMAX((Integer)newValue);
				return;
			case CoordinatedControlProfilePackage.ANALYZER__RECEIVER:
				setReceiver((Receiver)newValue);
				return;
			case CoordinatedControlProfilePackage.ANALYZER__PROCESSOR:
				setProcessor((Processor)newValue);
				return;
			case CoordinatedControlProfilePackage.ANALYZER__SENDER:
				setSender((Sender)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.ANALYZER__NAME:
				setName(NAME_EDEFAULT);
				return;
			case CoordinatedControlProfilePackage.ANALYZER__SYMPTOM_ANALYSIS:
				setSymptomAnalysis(SYMPTOM_ANALYSIS_EDEFAULT);
				return;
			case CoordinatedControlProfilePackage.ANALYZER__THERSHOLD_MIN:
				setThersholdMIN(THERSHOLD_MIN_EDEFAULT);
				return;
			case CoordinatedControlProfilePackage.ANALYZER__THERSHOLD_MAX:
				setThersholdMAX(THERSHOLD_MAX_EDEFAULT);
				return;
			case CoordinatedControlProfilePackage.ANALYZER__RECEIVER:
				setReceiver((Receiver)null);
				return;
			case CoordinatedControlProfilePackage.ANALYZER__PROCESSOR:
				setProcessor((Processor)null);
				return;
			case CoordinatedControlProfilePackage.ANALYZER__SENDER:
				setSender((Sender)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.ANALYZER__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case CoordinatedControlProfilePackage.ANALYZER__SYMPTOM_ANALYSIS:
				return symptomAnalysis != SYMPTOM_ANALYSIS_EDEFAULT;
			case CoordinatedControlProfilePackage.ANALYZER__THERSHOLD_MIN:
				return thersholdMIN != THERSHOLD_MIN_EDEFAULT;
			case CoordinatedControlProfilePackage.ANALYZER__THERSHOLD_MAX:
				return thersholdMAX != THERSHOLD_MAX_EDEFAULT;
			case CoordinatedControlProfilePackage.ANALYZER__RECEIVER:
				return receiver != null;
			case CoordinatedControlProfilePackage.ANALYZER__PROCESSOR:
				return processor != null;
			case CoordinatedControlProfilePackage.ANALYZER__SENDER:
				return sender != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", SymptomAnalysis: ");
		result.append(symptomAnalysis);
		result.append(", ThersholdMIN: ");
		result.append(thersholdMIN);
		result.append(", ThersholdMAX: ");
		result.append(thersholdMAX);
		result.append(')');
		return result.toString();
	}

} //AnalyzerImpl
