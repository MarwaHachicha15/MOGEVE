/**
 */
package CoordinatedControlProfile.impl;

import CoordinatedControlProfile.ContextElement;
import CoordinatedControlProfile.CoordinatedControlProfilePackage;
import CoordinatedControlProfile.ObservedProperty;
import CoordinatedControlProfile.Probes;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Observed Property</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.impl.ObservedPropertyImpl#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ObservedPropertyImpl#getSource <em>Source</em>}</li>
 *   <li>{@link CoordinatedControlProfile.impl.ObservedPropertyImpl#getDestinataire <em>Destinataire</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ObservedPropertyImpl extends MinimalEObjectImpl.Container implements ObservedProperty {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSource() <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSource()
	 * @generated
	 * @ordered
	 */
	protected ContextElement source;

	/**
	 * The cached value of the '{@link #getDestinataire() <em>Destinataire</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDestinataire()
	 * @generated
	 * @ordered
	 */
	protected Probes destinataire;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ObservedPropertyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CoordinatedControlProfilePackage.Literals.OBSERVED_PROPERTY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.OBSERVED_PROPERTY__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContextElement getSource() {
		if (source != null && source.eIsProxy()) {
			InternalEObject oldSource = (InternalEObject)source;
			source = (ContextElement)eResolveProxy(oldSource);
			if (source != oldSource) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CoordinatedControlProfilePackage.OBSERVED_PROPERTY__SOURCE, oldSource, source));
			}
		}
		return source;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContextElement basicGetSource() {
		return source;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSource(ContextElement newSource) {
		ContextElement oldSource = source;
		source = newSource;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.OBSERVED_PROPERTY__SOURCE, oldSource, source));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Probes getDestinataire() {
		if (destinataire != null && destinataire.eIsProxy()) {
			InternalEObject oldDestinataire = (InternalEObject)destinataire;
			destinataire = (Probes)eResolveProxy(oldDestinataire);
			if (destinataire != oldDestinataire) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CoordinatedControlProfilePackage.OBSERVED_PROPERTY__DESTINATAIRE, oldDestinataire, destinataire));
			}
		}
		return destinataire;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Probes basicGetDestinataire() {
		return destinataire;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDestinataire(Probes newDestinataire) {
		Probes oldDestinataire = destinataire;
		destinataire = newDestinataire;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CoordinatedControlProfilePackage.OBSERVED_PROPERTY__DESTINATAIRE, oldDestinataire, destinataire));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void CarryingProperty() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.OBSERVED_PROPERTY__NAME:
				return getName();
			case CoordinatedControlProfilePackage.OBSERVED_PROPERTY__SOURCE:
				if (resolve) return getSource();
				return basicGetSource();
			case CoordinatedControlProfilePackage.OBSERVED_PROPERTY__DESTINATAIRE:
				if (resolve) return getDestinataire();
				return basicGetDestinataire();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.OBSERVED_PROPERTY__NAME:
				setName((String)newValue);
				return;
			case CoordinatedControlProfilePackage.OBSERVED_PROPERTY__SOURCE:
				setSource((ContextElement)newValue);
				return;
			case CoordinatedControlProfilePackage.OBSERVED_PROPERTY__DESTINATAIRE:
				setDestinataire((Probes)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.OBSERVED_PROPERTY__NAME:
				setName(NAME_EDEFAULT);
				return;
			case CoordinatedControlProfilePackage.OBSERVED_PROPERTY__SOURCE:
				setSource((ContextElement)null);
				return;
			case CoordinatedControlProfilePackage.OBSERVED_PROPERTY__DESTINATAIRE:
				setDestinataire((Probes)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CoordinatedControlProfilePackage.OBSERVED_PROPERTY__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case CoordinatedControlProfilePackage.OBSERVED_PROPERTY__SOURCE:
				return source != null;
			case CoordinatedControlProfilePackage.OBSERVED_PROPERTY__DESTINATAIRE:
				return destinataire != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case CoordinatedControlProfilePackage.OBSERVED_PROPERTY___CARRYING_PROPERTY:
				CarryingProperty();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //ObservedPropertyImpl
