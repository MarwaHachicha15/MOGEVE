/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Provided Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.ProvidedInterface#getAgregation <em>Agregation</em>}</li>
 *   <li>{@link CoordinatedControlProfile.ProvidedInterface#getEventPort <em>Event Port</em>}</li>
 * </ul>
 * </p>
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getProvidedInterface()
 * @model
 * @generated
 */
public interface ProvidedInterface extends EObject {
	/**
	 * Returns the value of the '<em><b>Agregation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agregation</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agregation</em>' reference.
	 * @see #setAgregation(Agregation)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getProvidedInterface_Agregation()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Agregation getAgregation();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.ProvidedInterface#getAgregation <em>Agregation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Agregation</em>' reference.
	 * @see #getAgregation()
	 * @generated
	 */
	void setAgregation(Agregation value);

	/**
	 * Returns the value of the '<em><b>Event Port</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event Port</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event Port</em>' reference.
	 * @see #setEventPort(EventPort)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getProvidedInterface_EventPort()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	EventPort getEventPort();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.ProvidedInterface#getEventPort <em>Event Port</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Event Port</em>' reference.
	 * @see #getEventPort()
	 * @generated
	 */
	void setEventPort(EventPort value);

} // ProvidedInterface
