/**
 */
package CoordinatedControlProfile.util;

import CoordinatedControlProfile.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage
 * @generated
 */
public class CoordinatedControlProfileAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static CoordinatedControlProfilePackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CoordinatedControlProfileAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = CoordinatedControlProfilePackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CoordinatedControlProfileSwitch<Adapter> modelSwitch =
		new CoordinatedControlProfileSwitch<Adapter>() {
			@Override
			public Adapter caseCoordinatedControl(CoordinatedControl object) {
				return createCoordinatedControlAdapter();
			}
			@Override
			public Adapter caseManager(Manager object) {
				return createManagerAdapter();
			}
			@Override
			public Adapter caseMonitor(Monitor object) {
				return createMonitorAdapter();
			}
			@Override
			public Adapter caseReceiver(Receiver object) {
				return createReceiverAdapter();
			}
			@Override
			public Adapter caseProcessor(Processor object) {
				return createProcessorAdapter();
			}
			@Override
			public Adapter caseSender(Sender object) {
				return createSenderAdapter();
			}
			@Override
			public Adapter caseAnalyzer(Analyzer object) {
				return createAnalyzerAdapter();
			}
			@Override
			public Adapter casePlanner(Planner object) {
				return createPlannerAdapter();
			}
			@Override
			public Adapter caseExecutor(Executor object) {
				return createExecutorAdapter();
			}
			@Override
			public Adapter caseAdaptationActions(AdaptationActions object) {
				return createAdaptationActionsAdapter();
			}
			@Override
			public Adapter caseRFC(RFC object) {
				return createRFCAdapter();
			}
			@Override
			public Adapter caseSymptom(Symptom object) {
				return createSymptomAdapter();
			}
			@Override
			public Adapter caseEventPort(EventPort object) {
				return createEventPortAdapter();
			}
			@Override
			public Adapter caseAgregation(Agregation object) {
				return createAgregationAdapter();
			}
			@Override
			public Adapter caseManagedElement(ManagedElement object) {
				return createManagedElementAdapter();
			}
			@Override
			public Adapter caseProbes(Probes object) {
				return createProbesAdapter();
			}
			@Override
			public Adapter caseEffector(Effector object) {
				return createEffectorAdapter();
			}
			@Override
			public Adapter caseContextElement(ContextElement object) {
				return createContextElementAdapter();
			}
			@Override
			public Adapter caseObservedProperty(ObservedProperty object) {
				return createObservedPropertyAdapter();
			}
			@Override
			public Adapter caseIntracmpInteraction(IntracmpInteraction object) {
				return createIntracmpInteractionAdapter();
			}
			@Override
			public Adapter casePS(PS object) {
				return createPSAdapter();
			}
			@Override
			public Adapter caseRP(RP object) {
				return createRPAdapter();
			}
			@Override
			public Adapter caseMonitoringData(MonitoringData object) {
				return createMonitoringDataAdapter();
			}
			@Override
			public Adapter caseCommands(Commands object) {
				return createCommandsAdapter();
			}
			@Override
			public Adapter caseRequiredInterface(RequiredInterface object) {
				return createRequiredInterfaceAdapter();
			}
			@Override
			public Adapter caseProvidedInterface(ProvidedInterface object) {
				return createProvidedInterfaceAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.CoordinatedControl <em>Coordinated Control</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.CoordinatedControl
	 * @generated
	 */
	public Adapter createCoordinatedControlAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.Manager <em>Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.Manager
	 * @generated
	 */
	public Adapter createManagerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.Monitor <em>Monitor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.Monitor
	 * @generated
	 */
	public Adapter createMonitorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.Receiver <em>Receiver</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.Receiver
	 * @generated
	 */
	public Adapter createReceiverAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.Processor <em>Processor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.Processor
	 * @generated
	 */
	public Adapter createProcessorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.Sender <em>Sender</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.Sender
	 * @generated
	 */
	public Adapter createSenderAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.Analyzer <em>Analyzer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.Analyzer
	 * @generated
	 */
	public Adapter createAnalyzerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.Planner <em>Planner</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.Planner
	 * @generated
	 */
	public Adapter createPlannerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.Executor <em>Executor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.Executor
	 * @generated
	 */
	public Adapter createExecutorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.ManagedElement <em>Managed Element</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.ManagedElement
	 * @generated
	 */
	public Adapter createManagedElementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.Probes <em>Probes</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.Probes
	 * @generated
	 */
	public Adapter createProbesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.Effector <em>Effector</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.Effector
	 * @generated
	 */
	public Adapter createEffectorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.ContextElement <em>Context Element</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.ContextElement
	 * @generated
	 */
	public Adapter createContextElementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.EventPort <em>Event Port</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.EventPort
	 * @generated
	 */
	public Adapter createEventPortAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.Agregation <em>Agregation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.Agregation
	 * @generated
	 */
	public Adapter createAgregationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.ObservedProperty <em>Observed Property</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.ObservedProperty
	 * @generated
	 */
	public Adapter createObservedPropertyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.AdaptationActions <em>Adaptation Actions</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.AdaptationActions
	 * @generated
	 */
	public Adapter createAdaptationActionsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.RFC <em>RFC</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.RFC
	 * @generated
	 */
	public Adapter createRFCAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.Symptom <em>Symptom</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.Symptom
	 * @generated
	 */
	public Adapter createSymptomAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.IntracmpInteraction <em>Intracmp Interaction</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.IntracmpInteraction
	 * @generated
	 */
	public Adapter createIntracmpInteractionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.PS <em>PS</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.PS
	 * @generated
	 */
	public Adapter createPSAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.RP <em>RP</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.RP
	 * @generated
	 */
	public Adapter createRPAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.MonitoringData <em>Monitoring Data</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.MonitoringData
	 * @generated
	 */
	public Adapter createMonitoringDataAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.Commands <em>Commands</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.Commands
	 * @generated
	 */
	public Adapter createCommandsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.RequiredInterface <em>Required Interface</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.RequiredInterface
	 * @generated
	 */
	public Adapter createRequiredInterfaceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CoordinatedControlProfile.ProvidedInterface <em>Provided Interface</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CoordinatedControlProfile.ProvidedInterface
	 * @generated
	 */
	public Adapter createProvidedInterfaceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //CoordinatedControlProfileAdapterFactory
