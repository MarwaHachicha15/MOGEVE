/**
 */
package CoordinatedControlProfile;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Intracmp Interaction</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CoordinatedControlProfile.IntracmpInteraction#getName <em>Name</em>}</li>
 *   <li>{@link CoordinatedControlProfile.IntracmpInteraction#getSourceM <em>Source M</em>}</li>
 *   <li>{@link CoordinatedControlProfile.IntracmpInteraction#getDestinataireM <em>Destinataire M</em>}</li>
 *   <li>{@link CoordinatedControlProfile.IntracmpInteraction#getSourceA <em>Source A</em>}</li>
 *   <li>{@link CoordinatedControlProfile.IntracmpInteraction#getDestinataireA <em>Destinataire A</em>}</li>
 *   <li>{@link CoordinatedControlProfile.IntracmpInteraction#getSourceP <em>Source P</em>}</li>
 *   <li>{@link CoordinatedControlProfile.IntracmpInteraction#getDestinataireP <em>Destinataire P</em>}</li>
 *   <li>{@link CoordinatedControlProfile.IntracmpInteraction#getSourceE <em>Source E</em>}</li>
 *   <li>{@link CoordinatedControlProfile.IntracmpInteraction#getDestinataireE <em>Destinataire E</em>}</li>
 * </ul>
 * </p>
 *
 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getIntracmpInteraction()
 * @model
 * @generated
 */
public interface IntracmpInteraction extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getIntracmpInteraction_Name()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.IntracmpInteraction#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Source M</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source M</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source M</em>' reference.
	 * @see #setSourceM(Monitor)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getIntracmpInteraction_SourceM()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Monitor getSourceM();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.IntracmpInteraction#getSourceM <em>Source M</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source M</em>' reference.
	 * @see #getSourceM()
	 * @generated
	 */
	void setSourceM(Monitor value);

	/**
	 * Returns the value of the '<em><b>Destinataire M</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Destinataire M</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destinataire M</em>' reference.
	 * @see #setDestinataireM(Monitor)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getIntracmpInteraction_DestinataireM()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Monitor getDestinataireM();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.IntracmpInteraction#getDestinataireM <em>Destinataire M</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Destinataire M</em>' reference.
	 * @see #getDestinataireM()
	 * @generated
	 */
	void setDestinataireM(Monitor value);

	/**
	 * Returns the value of the '<em><b>Source A</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source A</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source A</em>' reference.
	 * @see #setSourceA(Analyzer)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getIntracmpInteraction_SourceA()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Analyzer getSourceA();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.IntracmpInteraction#getSourceA <em>Source A</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source A</em>' reference.
	 * @see #getSourceA()
	 * @generated
	 */
	void setSourceA(Analyzer value);

	/**
	 * Returns the value of the '<em><b>Destinataire A</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Destinataire A</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destinataire A</em>' reference.
	 * @see #setDestinataireA(Analyzer)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getIntracmpInteraction_DestinataireA()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Analyzer getDestinataireA();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.IntracmpInteraction#getDestinataireA <em>Destinataire A</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Destinataire A</em>' reference.
	 * @see #getDestinataireA()
	 * @generated
	 */
	void setDestinataireA(Analyzer value);

	/**
	 * Returns the value of the '<em><b>Source P</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source P</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source P</em>' reference.
	 * @see #setSourceP(Planner)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getIntracmpInteraction_SourceP()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Planner getSourceP();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.IntracmpInteraction#getSourceP <em>Source P</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source P</em>' reference.
	 * @see #getSourceP()
	 * @generated
	 */
	void setSourceP(Planner value);

	/**
	 * Returns the value of the '<em><b>Destinataire P</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Destinataire P</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destinataire P</em>' reference.
	 * @see #setDestinataireP(Planner)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getIntracmpInteraction_DestinataireP()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Planner getDestinataireP();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.IntracmpInteraction#getDestinataireP <em>Destinataire P</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Destinataire P</em>' reference.
	 * @see #getDestinataireP()
	 * @generated
	 */
	void setDestinataireP(Planner value);

	/**
	 * Returns the value of the '<em><b>Source E</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source E</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source E</em>' reference.
	 * @see #setSourceE(Executor)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getIntracmpInteraction_SourceE()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Executor getSourceE();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.IntracmpInteraction#getSourceE <em>Source E</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source E</em>' reference.
	 * @see #getSourceE()
	 * @generated
	 */
	void setSourceE(Executor value);

	/**
	 * Returns the value of the '<em><b>Destinataire E</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Destinataire E</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destinataire E</em>' reference.
	 * @see #setDestinataireE(Executor)
	 * @see CoordinatedControlProfile.CoordinatedControlProfilePackage#getIntracmpInteraction_DestinataireE()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Executor getDestinataireE();

	/**
	 * Sets the value of the '{@link CoordinatedControlProfile.IntracmpInteraction#getDestinataireE <em>Destinataire E</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Destinataire E</em>' reference.
	 * @see #getDestinataireE()
	 * @generated
	 */
	void setDestinataireE(Executor value);

} // IntracmpInteraction
